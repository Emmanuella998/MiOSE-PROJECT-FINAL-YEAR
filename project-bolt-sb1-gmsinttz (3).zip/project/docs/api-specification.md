# MiOse API Specification

## Base URL
```
Production: https://api.miose.sl/v1
Development: http://localhost:3000/api/v1
```

## Authentication
All authenticated endpoints require a Bearer token in the Authorization header:
```
Authorization: Bearer <jwt_token>
```

## Response Format
All API responses follow this structure:
```json
{
  "success": boolean,
  "data": object | array,
  "message": string,
  "pagination": {
    "page": number,
    "limit": number,
    "total": number,
    "totalPages": number
  }
}
```

## Endpoints

### Authentication

#### POST /auth/register
Register a new user account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+23276123456",
  "userType": "buyer" // buyer, renter, agent, landlord
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "userType": "buyer",
      "isVerified": false
    },
    "token": "jwt_token"
  },
  "message": "User registered successfully"
}
```

#### POST /auth/login
Authenticate existing user.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

#### POST /auth/logout
Logout current user (invalidate token).

#### POST /auth/refresh-token
Refresh JWT token.

#### POST /auth/forgot-password
Request password reset email.

#### POST /auth/reset-password
Reset password with token.

### Properties

#### GET /properties
List properties with optional filters.

**Query Parameters:**
- `page` (number): Page number (default: 1)
- `limit` (number): Items per page (default: 20)
- `district` (string): Filter by district
- `propertyType` (string): apartment, house, villa, land, commercial
- `listingType` (string): rent, sale
- `minPrice` (number): Minimum price
- `maxPrice` (number): Maximum price
- `bedrooms` (number): Number of bedrooms
- `bathrooms` (number): Number of bathrooms
- `amenities` (array): Array of amenity filters
- `featured` (boolean): Show only featured properties
- `sortBy` (string): price, date, views (default: date)
- `sortOrder` (string): asc, desc (default: desc)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "title": "Modern 3BR Apartment",
      "description": "Beautiful apartment...",
      "propertyType": "apartment",
      "listingType": "rent",
      "price": 2500000,
      "currency": "SLL",
      "address": "15 Siaka Stevens Street",
      "district": "Central Freetown",
      "latitude": 8.4840,
      "longitude": -13.2299,
      "bedrooms": 3,
      "bathrooms": 2,
      "squareMeters": 120,
      "amenities": ["parking", "generator", "security"],
      "images": [
        {
          "url": "https://...",
          "caption": "Living room",
          "isPrimary": true
        }
      ],
      "status": "active",
      "featured": true,
      "viewsCount": 124,
      "owner": {
        "id": "uuid",
        "firstName": "Jane",
        "lastName": "Smith",
        "phone": "+23276123456",
        "isVerified": true
      },
      "createdAt": "2024-01-15T10:30:00Z",
      "updatedAt": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "totalPages": 8
  }
}
```

#### GET /properties/:id
Get single property details.

#### POST /properties
Create new property listing (requires authentication).

**Request Body:**
```json
{
  "title": "Modern 3BR Apartment",
  "description": "Beautiful apartment in Central Freetown...",
  "propertyType": "apartment",
  "listingType": "rent",
  "price": 2500000,
  "currency": "SLL",
  "address": "15 Siaka Stevens Street",
  "district": "Central Freetown",
  "latitude": 8.4840,
  "longitude": -13.2299,
  "bedrooms": 3,
  "bathrooms": 2,
  "squareMeters": 120,
  "amenities": ["parking", "generator", "security"],
  "images": [
    {
      "url": "https://...",
      "caption": "Living room",
      "isPrimary": true
    }
  ]
}
```

#### PUT /properties/:id
Update property listing (owner only).

#### DELETE /properties/:id
Delete property listing (owner only).

#### POST /properties/:id/favorite
Add property to user favorites.

#### DELETE /properties/:id/favorite
Remove property from user favorites.

#### POST /properties/:id/view
Record property view (for analytics).

### Search and Recommendations

#### GET /properties/search
Advanced property search with AI-powered ranking.

**Query Parameters:**
- All property filter parameters
- `query` (string): Text search query
- `useAI` (boolean): Enable AI-powered ranking (default: true)

#### GET /recommendations/:userId
Get personalized property recommendations.

**Query Parameters:**
- `limit` (number): Number of recommendations (default: 10)
- `type` (string): similar, trending, new (default: similar)

#### POST /price-prediction
Get AI-powered price prediction for property.

**Request Body:**
```json
{
  "propertyType": "apartment",
  "district": "Central Freetown",
  "bedrooms": 3,
  "bathrooms": 2,
  "squareMeters": 120,
  "amenities": ["parking", "generator"]
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "predictedPrice": 2350000,
    "priceRange": {
      "min": 2100000,
      "max": 2600000
    },
    "confidenceScore": 0.92,
    "marketAnalysis": {
      "areaAverage": 2100000,
      "pricePerSqm": 19583,
      "marketTrend": "increasing",
      "trendPercentage": 5.2
    },
    "modelVersion": "v1.2.0"
  }
}
```

### Market Analysis

#### GET /market-analysis
Get market trends and analysis.

**Query Parameters:**
- `district` (string): Specific district analysis
- `propertyType` (string): Property type filter
- `timeframe` (string): 1m, 3m, 6m, 1y (default: 3m)

### User Management

#### GET /users/profile
Get current user profile.

#### PUT /users/profile
Update user profile.

#### GET /users/:id/properties
Get user's property listings.

#### GET /users/favorites
Get user's favorite properties.

### Payments

#### POST /payments/orange-money
Process Orange Money payment.

**Request Body:**
```json
{
  "amount": 50000,
  "currency": "SLL",
  "phoneNumber": "+23276123456",
  "propertyId": "uuid",
  "paymentType": "listing_fee"
}
```

#### POST /payments/afrimoney
Process Afrimoney payment.

#### POST /payments/card
Process credit/debit card payment.

#### GET /payments/status/:transactionId
Check payment status.

### Analytics

#### GET /analytics/property/:id
Get property analytics (owner only).

**Response:**
```json
{
  "success": true,
  "data": {
    "totalViews": 124,
    "dailyViews": [
      { "date": "2024-01-15", "views": 12 },
      { "date": "2024-01-16", "views": 8 }
    ],
    "inquiries": 5,
    "favorites": 18,
    "demographics": {
      "topDistricts": ["Central Freetown", "East End"],
      "ageGroups": {
        "25-34": 45,
        "35-44": 30,
        "45-54": 25
      }
    }
  }
}
```

#### GET /analytics/market
Get market analytics and trends.

### Notifications

#### GET /notifications
Get user notifications.

#### PUT /notifications/:id/read
Mark notification as read.

#### POST /notifications/subscribe
Subscribe to push notifications.

### File Upload

#### POST /upload/image
Upload property image.

**Request:** Multipart form data with image file.

**Response:**
```json
{
  "success": true,
  "data": {
    "url": "https://cdn.miose.sl/images/uuid.jpg",
    "thumbnailUrl": "https://cdn.miose.sl/thumbnails/uuid.jpg",
    "fileSize": 1024000,
    "dimensions": {
      "width": 1920,
      "height": 1080
    }
  }
}
```

## Error Responses

All error responses follow this format:
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Validation failed",
    "details": [
      {
        "field": "email",
        "message": "Invalid email format"
      }
    ]
  }
}
```

### Error Codes
- `VALIDATION_ERROR` (400): Request validation failed
- `AUTHENTICATION_ERROR` (401): Invalid or missing authentication
- `AUTHORIZATION_ERROR` (403): Insufficient permissions
- `NOT_FOUND` (404): Resource not found
- `CONFLICT` (409): Resource conflict (e.g., duplicate email)
- `RATE_LIMIT_EXCEEDED` (429): Too many requests
- `INTERNAL_ERROR` (500): Server error

## Rate Limiting
- Authentication endpoints: 5 requests per minute
- Search endpoints: 60 requests per minute
- Other endpoints: 100 requests per minute

## Webhooks

### Payment Webhooks
MiOse supports webhooks for payment status updates:

#### POST /webhooks/orange-money
Orange Money payment status webhook.

#### POST /webhooks/afrimoney
Afrimoney payment status webhook.

All webhooks include signature verification for security.