# MiOse ML Algorithms Specification

## Overview

MiOse uses machine learning algorithms to provide intelligent property recommendations, accurate price predictions, and market analysis. The ML system is designed to understand the unique characteristics of Sierra Leone's real estate market.

## 1. Price Prediction Algorithm

### 1.1 Model Architecture

**Primary Model: Gradient Boosting Regressor**
```python
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np

class PropertyPricePredictionModel:
    def __init__(self):
        self.model = GradientBoostingRegressor(
            n_estimators=200,
            learning_rate=0.1,
            max_depth=6,
            min_samples_split=20,
            min_samples_leaf=10,
            subsample=0.8,
            random_state=42
        )
        self.scaler = StandardScaler()
        self.feature_columns = [
            'property_type_encoded',
            'district_encoded', 
            'bedrooms',
            'bathrooms',
            'square_meters',
            'amenities_count',
            'distance_to_city_center',
            'local_market_index',
            'property_age',
            'infrastructure_score',
            'security_score',
            'accessibility_score'
        ]
        
    def preprocess_features(self, raw_data):
        """Convert raw property data to ML features"""
        features = pd.DataFrame()
        
        # Property type encoding
        property_type_map = {
            'apartment': 1, 'house': 2, 'villa': 3, 
            'land': 4, 'commercial': 5
        }
        features['property_type_encoded'] = raw_data['property_type'].map(property_type_map)
        
        # District encoding (based on average property values)
        district_values = {
            'Hill Station': 10, 'West End': 9, 'Central Freetown': 8,
            'East End': 7, 'Murray Town': 6, 'Lumley': 5,
            'Wellington': 4, 'Kissy': 3
        }
        features['district_encoded'] = raw_data['district'].map(district_values)
        
        # Direct numerical features
        features['bedrooms'] = raw_data['bedrooms'].fillna(0)
        features['bathrooms'] = raw_data['bathrooms'].fillna(0)
        features['square_meters'] = raw_data['square_meters'].fillna(0)
        
        # Amenities score
        amenity_weights = {
            'parking': 2, 'generator': 3, 'security': 2,
            'water_tank': 2, 'furnished': 3, 'air_conditioning': 3,
            'internet': 1, 'kitchen_appliances': 2, 'balcony': 1,
            'garden': 2, 'swimming_pool': 5, 'garage': 2
        }
        features['amenities_count'] = raw_data['amenities'].apply(
            lambda x: sum(amenity_weights.get(amenity, 1) for amenity in x) if x else 0
        )
        
        # Calculate distance to city center (Freetown)
        city_center = (8.4840, -13.2299)  # Freetown coordinates
        features['distance_to_city_center'] = raw_data.apply(
            lambda row: self.calculate_distance(
                (row['latitude'], row['longitude']), city_center
            ) if pd.notna(row['latitude']) else 5.0, axis=1
        )
        
        # Local market index (based on recent sales in the area)
        features['local_market_index'] = raw_data['district'].map(
            self.get_local_market_index()
        )
        
        # Property age
        current_year = pd.Timestamp.now().year
        features['property_age'] = raw_data['year_built'].apply(
            lambda x: current_year - x if pd.notna(x) else 10
        )
        
        # Infrastructure scores
        features['infrastructure_score'] = raw_data['district'].map(
            self.get_infrastructure_scores()
        )
        features['security_score'] = raw_data['district'].map(
            self.get_security_scores()
        )
        features['accessibility_score'] = raw_data['district'].map(
            self.get_accessibility_scores()
        )
        
        return features
    
    def calculate_distance(self, point1, point2):
        """Calculate distance between two coordinates in km"""
        from math import radians, sin, cos, sqrt, atan2
        
        lat1, lon1 = radians(point1[0]), radians(point1[1])
        lat2, lon2 = radians(point2[0]), radians(point2[1])
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        
        return 6371 * c  # Earth's radius in km
    
    def get_local_market_index(self):
        """District-based market strength indicators"""
        return {
            'Hill Station': 1.3, 'West End': 1.2, 'Central Freetown': 1.1,
            'East End': 1.0, 'Murray Town': 0.95, 'Lumley': 0.9,
            'Wellington': 0.85, 'Kissy': 0.8
        }
    
    def get_infrastructure_scores(self):
        """Infrastructure quality by district (0-10)"""
        return {
            'Hill Station': 9, 'West End': 8, 'Central Freetown': 7,
            'East End': 6, 'Murray Town': 7, 'Lumley': 8,
            'Wellington': 5, 'Kissy': 4
        }
    
    def get_security_scores(self):
        """Security level by district (0-10)"""
        return {
            'Hill Station': 9, 'West End': 8, 'Central Freetown': 6,
            'East End': 5, 'Murray Town': 7, 'Lumley': 8,
            'Wellington': 5, 'Kissy': 4
        }
    
    def get_accessibility_scores(self):
        """Transportation accessibility by district (0-10)"""
        return {
            'Hill Station': 7, 'West End': 8, 'Central Freetown': 10,
            'East End': 8, 'Murray Town': 7, 'Lumley': 6,
            'Wellington': 5, 'Kissy': 6
        }
    
    def train(self, training_data):
        """Train the price prediction model"""
        features = self.preprocess_features(training_data)
        X = features[self.feature_columns]
        y = training_data['price']
        
        # Handle missing values
        X = X.fillna(X.median())
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train model
        self.model.fit(X_scaled, y)
        
        # Calculate feature importance
        feature_importance = pd.DataFrame({
            'feature': self.feature_columns,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        return {
            'model_score': self.model.score(X_scaled, y),
            'feature_importance': feature_importance
        }
    
    def predict(self, property_data):
        """Predict property price"""
        features = self.preprocess_features(property_data)
        X = features[self.feature_columns].fillna(features.median())
        X_scaled = self.scaler.transform(X)
        
        prediction = self.model.predict(X_scaled)[0]
        
        # Calculate confidence intervals
        confidence = self.calculate_confidence(X_scaled[0])
        
        return {
            'predicted_price': max(0, prediction),
            'confidence_score': confidence,
            'price_range': {
                'min': max(0, prediction * 0.85),
                'max': prediction * 1.15
            }
        }
    
    def calculate_confidence(self, features):
        """Calculate prediction confidence based on feature similarity to training data"""
        # Simplified confidence calculation
        # In production, this would use more sophisticated methods
        return min(0.95, 0.75 + np.random.uniform(0, 0.2))
```

### 1.2 Model Training Pipeline

```python
class ModelTrainingPipeline:
    def __init__(self):
        self.model = PropertyPricePredictionModel()
        
    def collect_training_data(self):
        """Collect and clean training data from database"""
        # Query historical property sales and current listings
        query = """
        SELECT p.*, pt.transaction_price, pt.transaction_date
        FROM properties p
        LEFT JOIN property_transactions pt ON p.id = pt.property_id
        WHERE p.status IN ('sold', 'rented', 'active')
        AND p.price > 0
        AND p.created_at >= NOW() - INTERVAL '2 years'
        """
        return pd.read_sql(query, self.db_connection)
    
    def validate_model(self, X, y):
        """Cross-validation and performance metrics"""
        from sklearn.model_selection import cross_val_score
        from sklearn.metrics import mean_absolute_error, mean_squared_error
        
        # Cross-validation
        cv_scores = cross_val_score(self.model.model, X, y, cv=5, scoring='r2')
        
        # Test set predictions
        y_pred = self.model.model.predict(X)
        
        metrics = {
            'r2_score': cv_scores.mean(),
            'r2_std': cv_scores.std(),
            'mae': mean_absolute_error(y, y_pred),
            'rmse': np.sqrt(mean_squared_error(y, y_pred))
        }
        
        return metrics
    
    def retrain_model(self):
        """Full model retraining process"""
        # Collect new data
        training_data = self.collect_training_data()
        
        # Train model
        results = self.model.train(training_data)
        
        # Validate model
        features = self.model.preprocess_features(training_data)
        X = features[self.model.feature_columns].fillna(features.median())
        X_scaled = self.model.scaler.transform(X)
        y = training_data['price']
        
        validation_results = self.validate_model(X_scaled, y)
        
        # Save model if performance is acceptable
        if validation_results['r2_score'] > 0.8:
            self.save_model()
            return {
                'status': 'success',
                'training_results': results,
                'validation_results': validation_results
            }
        else:
            return {
                'status': 'failed',
                'reason': 'Model performance below threshold',
                'validation_results': validation_results
            }
```

## 2. Property Recommendation Algorithm

### 2.1 Hybrid Recommendation System

```python
class PropertyRecommendationEngine:
    def __init__(self):
        self.collaborative_model = None
        self.content_model = None
        self.hybrid_weights = {'collaborative': 0.6, 'content': 0.4}
    
    def collaborative_filtering(self, user_id, n_recommendations=10):
        """Collaborative filtering based on user behavior patterns"""
        from sklearn.neighbors import NearestNeighbors
        from scipy.sparse import csr_matrix
        
        # Create user-property interaction matrix
        interactions = self.get_user_interactions()
        
        # User-item matrix (users x properties)
        user_item_matrix = interactions.pivot_table(
            index='user_id',
            columns='property_id', 
            values='interaction_score',
            fill_value=0
        )
        
        # Convert to sparse matrix for efficiency
        sparse_matrix = csr_matrix(user_item_matrix.values)
        
        # Train KNN model
        model = NearestNeighbors(
            n_neighbors=20,
            metric='cosine',
            algorithm='brute'
        )
        model.fit(sparse_matrix)
        
        # Find similar users
        if user_id in user_item_matrix.index:
            user_index = user_item_matrix.index.get_loc(user_id)
            distances, indices = model.kneighbors(
                sparse_matrix[user_index], 
                n_neighbors=21
            )
            
            # Get recommendations from similar users
            similar_users = [user_item_matrix.index[i] for i in indices.flatten()[1:]]
            recommendations = self.get_recommendations_from_similar_users(
                user_id, similar_users, n_recommendations
            )
        else:
            # Cold start: recommend popular properties
            recommendations = self.get_popular_properties(n_recommendations)
        
        return recommendations
    
    def content_based_filtering(self, user_id, n_recommendations=10):
        """Content-based filtering using property features and user preferences"""
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity
        
        # Get user preferences
        user_prefs = self.get_user_preferences(user_id)
        user_history = self.get_user_property_history(user_id)
        
        # Create property feature vectors
        properties = self.get_all_properties()
        
        # Combine textual features
        property_features = properties.apply(lambda x: f"""
            {x['property_type']} {x['district']} 
            {' '.join(x['amenities']) if x['amenities'] else ''}
            {x['bedrooms']}bed {x['bathrooms']}bath
        """, axis=1)
        
        # TF-IDF vectorization
        tfidf = TfidfVectorizer(stop_words='english', max_features=1000)
        tfidf_matrix = tfidf.fit_transform(property_features)
        
        # Create user profile based on preferences and history
        user_profile = self.create_user_profile(user_prefs, user_history)
        user_profile_vector = tfidf.transform([user_profile])
        
        # Calculate similarity scores
        similarity_scores = cosine_similarity(user_profile_vector, tfidf_matrix).flatten()
        
        # Filter out already viewed properties
        viewed_properties = set(user_history['property_id'].tolist())
        available_properties = properties[~properties['id'].isin(viewed_properties)]
        
        # Get top recommendations
        property_scores = list(zip(
            available_properties['id'].tolist(),
            similarity_scores[available_properties.index]
        ))
        property_scores.sort(key=lambda x: x[1], reverse=True)
        
        return [prop_id for prop_id, score in property_scores[:n_recommendations]]
    
    def hybrid_recommendations(self, user_id, n_recommendations=10):
        """Combine collaborative and content-based recommendations"""
        
        # Get recommendations from both methods
        collab_recs = self.collaborative_filtering(user_id, n_recommendations * 2)
        content_recs = self.content_based_filtering(user_id, n_recommendations * 2)
        
        # Score and combine recommendations
        final_scores = {}
        
        # Add collaborative scores
        for i, prop_id in enumerate(collab_recs):
            score = (len(collab_recs) - i) / len(collab_recs)
            final_scores[prop_id] = final_scores.get(prop_id, 0) + \
                                  score * self.hybrid_weights['collaborative']
        
        # Add content-based scores
        for i, prop_id in enumerate(content_recs):
            score = (len(content_recs) - i) / len(content_recs)
            final_scores[prop_id] = final_scores.get(prop_id, 0) + \
                                  score * self.hybrid_weights['content']
        
        # Apply business rules and filters
        final_scores = self.apply_business_rules(user_id, final_scores)
        
        # Sort by final score
        sorted_recommendations = sorted(
            final_scores.items(), 
            key=lambda x: x[1], 
            reverse=True
        )
        
        return [prop_id for prop_id, score in sorted_recommendations[:n_recommendations]]
    
    def apply_business_rules(self, user_id, property_scores):
        """Apply business rules to recommendations"""
        user_prefs = self.get_user_preferences(user_id)
        
        filtered_scores = {}
        for prop_id, score in property_scores.items():
            property_data = self.get_property_data(prop_id)
            
            # Price range filter
            if user_prefs.get('min_price') and property_data['price'] < user_prefs['min_price']:
                continue
            if user_prefs.get('max_price') and property_data['price'] > user_prefs['max_price']:
                continue
            
            # Location filter
            if user_prefs.get('preferred_districts'):
                if property_data['district'] not in user_prefs['preferred_districts']:
                    score *= 0.5  # Reduce score but don't eliminate
            
            # Property type filter
            if user_prefs.get('property_types'):
                if property_data['property_type'] not in user_prefs['property_types']:
                    score *= 0.7
            
            # Boost featured properties
            if property_data.get('featured'):
                score *= 1.1
            
            # Boost recently listed properties
            days_since_listed = (datetime.now() - property_data['created_at']).days
            if days_since_listed <= 7:
                score *= 1.05
            
            filtered_scores[prop_id] = score
        
        return filtered_scores
    
    def get_user_interactions(self):
        """Get user interaction data with scoring"""
        # Interaction types and their weights
        interaction_weights = {
            'view': 1,
            'favorite': 3,
            'inquiry': 5,
            'contact': 4,
            'share': 2
        }
        
        query = """
        SELECT user_id, property_id, interaction_type, created_at
        FROM user_property_interactions
        WHERE created_at >= NOW() - INTERVAL '6 months'
        """
        
        interactions = pd.read_sql(query, self.db_connection)
        interactions['interaction_score'] = interactions['interaction_type'].map(
            interaction_weights
        )
        
        # Aggregate scores per user-property pair
        user_property_scores = interactions.groupby(['user_id', 'property_id']).agg({
            'interaction_score': 'sum',
            'created_at': 'max'
        }).reset_index()
        
        # Apply time decay
        days_since = (datetime.now() - user_property_scores['created_at']).dt.days
        time_decay = np.exp(-days_since / 30)  # 30-day half-life
        user_property_scores['interaction_score'] *= time_decay
        
        return user_property_scores
```

## 3. Market Analysis Algorithm

### 3.1 Market Trend Analysis

```python
class MarketAnalysisEngine:
    def __init__(self):
        self.trend_models = {}
    
    def calculate_market_trends(self, district=None, property_type=None, timeframe='3m'):
        """Calculate market trends for specified parameters"""
        
        # Get historical price data
        price_data = self.get_historical_prices(district, property_type, timeframe)
        
        # Calculate trend metrics
        trends = {}
        
        # Price trend
        if len(price_data) > 1:
            price_change = (price_data['price'].iloc[-1] - price_data['price'].iloc[0]) / price_data['price'].iloc[0] * 100
            trends['price_change_percent'] = price_change
            trends['trend_direction'] = 'increasing' if price_change > 0 else 'decreasing'
        
        # Volume trend (number of listings)
        listing_counts = self.get_listing_volume(district, property_type, timeframe)
        volume_change = (listing_counts.iloc[-1] - listing_counts.iloc[0]) / listing_counts.iloc[0] * 100
        trends['volume_change_percent'] = volume_change
        
        # Average time on market
        time_on_market = self.calculate_average_time_on_market(district, property_type)
        trends['avg_time_on_market_days'] = time_on_market
        
        # Price per square meter
        avg_price_per_sqm = self.calculate_price_per_sqm(district, property_type)
        trends['avg_price_per_sqm'] = avg_price_per_sqm
        
        # Market heat score (0-100)
        heat_score = self.calculate_market_heat(district, property_type)
        trends['market_heat_score'] = heat_score
        
        return trends
    
    def calculate_market_heat(self, district, property_type):
        """Calculate market activity heat score"""
        
        # Factors for market heat calculation
        factors = {}
        
        # Recent listing activity
        recent_listings = self.get_recent_listing_count(district, property_type, days=30)
        factors['listing_activity'] = min(100, recent_listings * 2)
        
        # Price velocity (rate of price change)
        price_velocity = abs(self.get_price_velocity(district, property_type))
        factors['price_velocity'] = min(100, price_velocity * 10)
        
        # User interest (views, favorites, inquiries)
        user_interest = self.get_user_interest_score(district, property_type)
        factors['user_interest'] = user_interest
        
        # Days on market (lower is hotter)
        avg_dom = self.calculate_average_time_on_market(district, property_type)
        factors['market_speed'] = max(0, 100 - (avg_dom / 365 * 100))
        
        # Weighted average
        weights = {
            'listing_activity': 0.3,
            'price_velocity': 0.2,
            'user_interest': 0.3,
            'market_speed': 0.2
        }
        
        heat_score = sum(factors[factor] * weight for factor, weight in weights.items())
        return min(100, max(0, heat_score))
    
    def predict_future_trends(self, district, property_type, forecast_months=6):
        """Predict future market trends using time series analysis"""
        from statsmodels.tsa.holtwinters import ExponentialSmoothing
        
        # Get historical data
        historical_data = self.get_historical_prices(district, property_type, '2y')
        
        if len(historical_data) < 12:  # Need at least 1 year of data
            return {'error': 'Insufficient historical data for prediction'}
        
        # Prepare time series
        ts_data = historical_data.set_index('date')['avg_price'].resample('M').mean()
        
        # Fit exponential smoothing model
        model = ExponentialSmoothing(
            ts_data,
            trend='add',
            seasonal='add' if len(ts_data) >= 24 else None,
            seasonal_periods=12 if len(ts_data) >= 24 else None
        )
        
        fitted_model = model.fit()
        
        # Generate forecast
        forecast = fitted_model.forecast(steps=forecast_months)
        
        # Calculate confidence intervals (simplified)
        forecast_variance = fitted_model.fittedvalues.var()
        confidence_interval = 1.96 * np.sqrt(forecast_variance)
        
        return {
            'forecast': forecast.tolist(),
            'confidence_interval': confidence_interval,
            'forecast_months': forecast_months,
            'model_performance': {
                'aic': fitted_model.aic,
                'bic': fitted_model.bic
            }
        }
```

## 4. Model Deployment and Monitoring

### 4.1 Model Serving Infrastructure

```python
class MLModelServer:
    def __init__(self):
        self.models = {
            'price_prediction': None,
            'recommendation': None,
            'market_analysis': None
        }
        self.model_versions = {}
        self.performance_metrics = {}
    
    def load_models(self):
        """Load trained models from storage"""
        import joblib
        
        for model_name in self.models.keys():
            try:
                model_path = f"models/{model_name}_latest.pkl"
                self.models[model_name] = joblib.load(model_path)
                
                # Load model metadata
                metadata_path = f"models/{model_name}_metadata.json"
                with open(metadata_path, 'r') as f:
                    metadata = json.load(f)
                    self.model_versions[model_name] = metadata['version']
                    
            except Exception as e:
                print(f"Error loading {model_name}: {e}")
    
    def predict_price(self, property_data):
        """Price prediction endpoint"""
        try:
            model = self.models['price_prediction']
            if model is None:
                return {'error': 'Price prediction model not available'}
            
            # Log prediction request
            self.log_prediction_request('price_prediction', property_data)
            
            # Make prediction
            result = model.predict(property_data)
            
            # Add model version to response
            result['model_version'] = self.model_versions.get('price_prediction', 'unknown')
            
            return result
            
        except Exception as e:
            self.log_prediction_error('price_prediction', str(e))
            return {'error': 'Prediction failed'}
    
    def get_recommendations(self, user_id, n_recommendations=10):
        """Recommendation endpoint"""
        try:
            model = self.models['recommendation']
            if model is None:
                return {'error': 'Recommendation model not available'}
            
            recommendations = model.hybrid_recommendations(user_id, n_recommendations)
            
            return {
                'recommendations': recommendations,
                'model_version': self.model_versions.get('recommendation', 'unknown')
            }
            
        except Exception as e:
            return {'error': 'Recommendation failed'}
    
    def monitor_model_performance(self):
        """Monitor model performance and trigger retraining if needed"""
        
        for model_name, model in self.models.items():
            if model is None:
                continue
            
            # Calculate current performance metrics
            current_metrics = self.calculate_current_performance(model_name)
            
            # Compare with baseline metrics
            baseline_metrics = self.get_baseline_metrics(model_name)
            
            # Check for performance degradation
            performance_threshold = 0.05  # 5% degradation threshold
            
            if model_name == 'price_prediction':
                if current_metrics['mae'] > baseline_metrics['mae'] * (1 + performance_threshold):
                    self.trigger_model_retraining(model_name)
            
            elif model_name == 'recommendation':
                if current_metrics['click_through_rate'] < baseline_metrics['click_through_rate'] * (1 - performance_threshold):
                    self.trigger_model_retraining(model_name)
    
    def trigger_model_retraining(self, model_name):
        """Trigger model retraining process"""
        # Add to retraining queue
        retraining_request = {
            'model_name': model_name,
            'requested_at': datetime.now(),
            'reason': 'performance_degradation'
        }
        
        # In production, this would trigger a background job
        print(f"Triggering retraining for {model_name}")
```

## 5. A/B Testing Framework

### 5.1 Recommendation A/B Testing

```python
class RecommendationABTest:
    def __init__(self):
        self.experiments = {}
        self.user_assignments = {}
    
    def create_experiment(self, experiment_name, variants, traffic_split):
        """Create new A/B test experiment"""
        self.experiments[experiment_name] = {
            'variants': variants,
            'traffic_split': traffic_split,
            'created_at': datetime.now(),
            'metrics': {variant: [] for variant in variants}
        }
    
    def assign_user_to_variant(self, user_id, experiment_name):
        """Assign user to experiment variant"""
        if experiment_name not in self.experiments:
            return 'control'
        
        # Use consistent hashing for user assignment
        import hashlib
        user_hash = int(hashlib.md5(f"{user_id}_{experiment_name}".encode()).hexdigest(), 16)
        
        variants = self.experiments[experiment_name]['variants']
        traffic_split = self.experiments[experiment_name]['traffic_split']
        
        # Determine variant based on hash
        cumulative_split = 0
        for i, (variant, split) in enumerate(zip(variants, traffic_split)):
            cumulative_split += split
            if (user_hash % 100) < cumulative_split * 100:
                self.user_assignments[f"{user_id}_{experiment_name}"] = variant
                return variant
        
        return variants[-1]  # Fallback to last variant
    
    def track_conversion(self, user_id, experiment_name, conversion_type):
        """Track conversion events for A/B testing"""
        assignment_key = f"{user_id}_{experiment_name}"
        
        if assignment_key in self.user_assignments:
            variant = self.user_assignments[assignment_key]
            
            conversion_data = {
                'user_id': user_id,
                'variant': variant,
                'conversion_type': conversion_type,
                'timestamp': datetime.now()
            }
            
            self.experiments[experiment_name]['metrics'][variant].append(conversion_data)
    
    def analyze_experiment_results(self, experiment_name):
        """Analyze A/B test results"""
        if experiment_name not in self.experiments:
            return {'error': 'Experiment not found'}
        
        experiment = self.experiments[experiment_name]
        results = {}
        
        for variant in experiment['variants']:
            conversions = experiment['metrics'][variant]
            
            # Calculate conversion metrics
            total_users = len(set(c['user_id'] for c in conversions))
            total_conversions = len(conversions)
            conversion_rate = total_conversions / total_users if total_users > 0 else 0
            
            results[variant] = {
                'total_users': total_users,
                'total_conversions': total_conversions,
                'conversion_rate': conversion_rate
            }
        
        # Statistical significance testing
        control_variant = experiment['variants'][0]
        
        for variant in experiment['variants'][1:]:
            significance = self.calculate_statistical_significance(
                results[control_variant],
                results[variant]
            )
            results[variant]['statistical_significance'] = significance
        
        return results
    
    def calculate_statistical_significance(self, control_metrics, variant_metrics):
        """Calculate statistical significance using z-test"""
        from scipy import stats
        
        # Sample sizes
        n1 = control_metrics['total_users']
        n2 = variant_metrics['total_users']
        
        # Conversion rates
        p1 = control_metrics['conversion_rate']
        p2 = variant_metrics['conversion_rate']
        
        if n1 == 0 or n2 == 0:
            return {'p_value': 1.0, 'significant': False}
        
        # Pooled proportion
        p_pool = (control_metrics['total_conversions'] + variant_metrics['total_conversions']) / (n1 + n2)
        
        # Standard error
        se = np.sqrt(p_pool * (1 - p_pool) * (1/n1 + 1/n2))
        
        if se == 0:
            return {'p_value': 1.0, 'significant': False}
        
        # Z-score
        z_score = (p2 - p1) / se
        
        # P-value (two-tailed test)
        p_value = 2 * (1 - stats.norm.cdf(abs(z_score)))
        
        return {
            'z_score': z_score,
            'p_value': p_value,
            'significant': p_value < 0.05
        }
```

This comprehensive ML specification provides the foundation for MiOse's intelligent features, including accurate price predictions, personalized recommendations, and market analysis tailored specifically for Sierra Leone's real estate market.