# MiOse - Sierra Leone Real Estate Platform

## 🏠 Overview

MiOse is a comprehensive real estate platform designed specifically for the Sierra Leone market. It connects property buyers, renters, landlords, and real estate agents through an intuitive, modern web application with AI-powered features and local payment integration.

## ✨ Features

### 🔐 Authentication & User Management
- Secure user registration and login
- Role-based access (Buyer, Renter, Landlord, Agent)
- Profile management with image upload
- JWT-based authentication with automatic token refresh

### 🏘️ Property Management
- Advanced property search and filtering
- Interactive property listings with high-quality images
- Detailed property pages with virtual tours
- Property analytics and insights
- Favorites and watchlist functionality

### 💳 Payment Integration
- **Stripe** - International card payments
- **Orange Money** - Local mobile money
- **Afrimoney** - Local mobile money
- Secure payment processing with PCI compliance
- Subscription management for premium features

### 📊 Dashboard & Analytics
- Comprehensive user dashboard
- Property performance analytics
- Market insights and trends
- Real-time notifications
- Lead management tools

### 🤖 AI-Powered Features
- Property price predictions
- Personalized recommendations
- Market analysis and trends
- Smart property matching

### 📱 Mobile-First Design
- Responsive design for all devices
- Progressive Web App (PWA) capabilities
- Touch-friendly interfaces
- Optimized for Sierra Leone's mobile-first market

## 🛠️ Technology Stack

### Frontend
- **React 18** - Modern UI library
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first styling
- **Framer Motion** - Smooth animations
- **Zustand** - State management
- **React Hook Form** - Form handling
- **React Query** - Data fetching

### Backend Integration
- **Axios** - HTTP client
- **Stripe SDK** - Payment processing
- **JWT** - Authentication tokens
- **Local Storage** - Data persistence

### Development Tools
- **Vite** - Fast build tool
- **ESLint** - Code linting
- **Prettier** - Code formatting
- **TypeScript** - Static typing

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Modern web browser

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/miose/platform.git
   cd miose-platform
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   Create a `.env` file in the root directory:
   ```env
   VITE_API_URL=http://localhost:3000/api/v1
   VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_stripe_key
   VITE_APP_NAME=MiOse
   VITE_APP_URL=http://localhost:5173
   ```

4. **Start development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to `http://localhost:5173`

### Building for Production

```bash
npm run build
npm run preview
```

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── ui/             # Base UI components (Button, Input, Modal)
│   ├── payment/        # Payment-related components
│   └── ...
├── pages/              # Page components
├── store/              # Zustand stores
├── services/           # API services and utilities
├── types/              # TypeScript type definitions
├── config/             # Configuration and constants
├── hooks/              # Custom React hooks
└── utils/              # Utility functions
```

## 🔧 Configuration

### Payment Methods

The platform supports multiple payment methods configured in `src/config/constants.ts`:

- **Stripe**: International card payments
- **Orange Money**: Sierra Leone mobile money
- **Afrimoney**: Sierra Leone mobile money

### Subscription Plans

Two subscription tiers are available:

1. **Basic Listing** (Le 50/month)
   - Up to 5 properties
   - Basic analytics
   - Standard support

2. **Pro Listing** (Le 150/month)
   - Unlimited properties
   - Advanced analytics
   - Priority support
   - Featured listings

## 🌍 Localization

The platform is designed for the Sierra Leone market with:

- **Currency**: Sierra Leone Leone (SLL) and USD
- **Districts**: All major Freetown districts
- **Phone Format**: +232 format validation
- **Local Payment Methods**: Orange Money and Afrimoney

## 🔒 Security Features

- JWT token authentication with refresh
- Input validation and sanitization
- XSS protection
- CSRF protection
- Secure payment processing
- Data encryption in transit

## 📊 Analytics & Monitoring

- Property view tracking
- User engagement metrics
- Payment transaction monitoring
- Error logging and reporting
- Performance monitoring

## 🧪 Testing

```bash
# Run unit tests
npm run test

# Run tests with coverage
npm run test:coverage

# Run E2E tests
npm run test:e2e
```

## 🚀 Deployment

### Environment Variables for Production

```env
VITE_API_URL=https://api.miose.sl/v1
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_your_live_stripe_key
VITE_APP_NAME=MiOse
VITE_APP_URL=https://miose.sl
```

### Build and Deploy

```bash
# Build for production
npm run build

# Deploy to your hosting provider
# (Netlify, Vercel, AWS S3, etc.)
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 API Documentation

The platform integrates with a RESTful API. Key endpoints include:

- `POST /auth/login` - User authentication
- `GET /properties` - Property listings
- `POST /properties` - Create property
- `POST /payments/stripe` - Process Stripe payment
- `POST /payments/orange-money` - Process Orange Money payment

## 🐛 Troubleshooting

### Common Issues

1. **Payment Processing Fails**
   - Check API keys in environment variables
   - Verify payment method configuration
   - Check network connectivity

2. **Images Not Loading**
   - Verify image URLs are accessible
   - Check CORS configuration
   - Ensure proper file permissions

3. **Authentication Issues**
   - Clear browser storage
   - Check JWT token expiration
   - Verify API endpoint configuration

## 📞 Support

For technical support or questions:

- **Email**: support@miose.sl
- **Phone**: +232 76 123 456
- **Website**: https://miose.sl

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Sierra Leone real estate community
- Open source contributors
- Local payment providers (Orange Money, Afrimoney)
- Beta testers and early adopters

---

**Made with ❤️ in Sierra Leone for Sierra Leone** 🇸🇱