// Core Types for MiOse Platform
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  userType: UserType;
  profileImage?: string;
  isVerified: boolean;
  isPremium: boolean;
  createdAt: string;
  updatedAt: string;
}

export type UserType = 'buyer' | 'renter' | 'agent' | 'landlord';

export interface Property {
  id: string;
  ownerId: string;
  title: string;
  description: string;
  propertyType: PropertyType;
  listingType: ListingType;
  price: number;
  currency: Currency;
  address: string;
  district: District;
  latitude?: number;
  longitude?: number;
  bedrooms: number;
  bathrooms: number;
  squareMeters: number;
  amenities: string[];
  images: PropertyImage[];
  status: PropertyStatus;
  featured: boolean;
  viewsCount: number;
  owner: PropertyOwner;
  createdAt: string;
  updatedAt: string;
}

export type PropertyType = 'apartment' | 'house' | 'villa' | 'land' | 'commercial';
export type ListingType = 'rent' | 'sale';
export type Currency = 'SLL' | 'USD';
export type PropertyStatus = 'active' | 'pending' | 'sold' | 'rented';

export type District = 
  | 'Central Freetown'
  | 'East End'
  | 'West End'
  | 'Hill Station'
  | 'Murray Town'
  | 'Kissy'
  | 'Wellington'
  | 'Lumley';

export interface PropertyImage {
  id: string;
  url: string;
  caption?: string;
  isPrimary: boolean;
  order: number;
}

export interface PropertyOwner {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  profileImage?: string;
  isVerified: boolean;
  rating: number;
  reviewCount: number;
}

export interface PropertyFilters {
  page?: number;
  limit?: number;
  district?: District;
  propertyType?: PropertyType;
  listingType?: ListingType;
  minPrice?: number;
  maxPrice?: number;
  bedrooms?: number;
  bathrooms?: number;
  amenities?: string[];
  featured?: boolean;
  sortBy?: SortBy;
  sortOrder?: SortOrder;
  search?: string;
}

export type SortBy = 'price' | 'date' | 'views' | 'bedrooms';
export type SortOrder = 'asc' | 'desc';

export interface PaginationInfo {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  pagination?: PaginationInfo;
}

// Payment Types
export interface PaymentMethod {
  id: string;
  type: PaymentType;
  name: string;
  icon: string;
  description: string;
  isActive: boolean;
}

export type PaymentType = 'stripe' | 'orange_money' | 'afrimoney';

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: Currency;
  status: PaymentStatus;
  paymentMethod: PaymentType;
  propertyId?: string;
  subscriptionId?: string;
  createdAt: string;
}

export type PaymentStatus = 'pending' | 'processing' | 'succeeded' | 'failed' | 'canceled';

export interface Subscription {
  id: string;
  userId: string;
  planId: string;
  status: SubscriptionStatus;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  amount: number;
  currency: Currency;
}

export type SubscriptionStatus = 'active' | 'canceled' | 'past_due' | 'unpaid';

export interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: Currency;
  interval: 'month' | 'year';
  features: string[];
  isPopular: boolean;
  maxProperties: number;
  maxImages: number;
}

// Analytics Types
export interface PropertyAnalytics {
  propertyId: string;
  totalViews: number;
  dailyViews: DailyView[];
  inquiries: number;
  favorites: number;
  demographics: Demographics;
  conversionRate: number;
}

export interface DailyView {
  date: string;
  views: number;
  uniqueViews: number;
}

export interface Demographics {
  ageGroups: Record<string, number>;
  topDistricts: string[];
  deviceTypes: Record<string, number>;
}

export interface MarketAnalytics {
  district: District;
  averagePrice: number;
  priceChange: number;
  totalListings: number;
  soldThisMonth: number;
  averageDaysOnMarket: number;
  marketTrend: 'increasing' | 'decreasing' | 'stable';
}

// Form Types
export interface LoginForm {
  email: string;
  password: string;
}

export interface RegisterForm {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
  userType: UserType;
}

export interface PropertyForm {
  title: string;
  description: string;
  propertyType: PropertyType;
  listingType: ListingType;
  price: number;
  currency: Currency;
  address: string;
  district: District;
  bedrooms: number;
  bathrooms: number;
  squareMeters: number;
  amenities: string[];
  images: File[];
}

export interface ContactForm {
  name: string;
  email: string;
  phone: string;
  message: string;
  propertyId?: string;
}

// Error Types
export interface AppError {
  code: string;
  message: string;
  details?: Record<string, any>;
}

export interface ValidationError {
  field: string;
  message: string;
}

// State Types
export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export interface PropertyState {
  properties: Property[];
  currentProperty: Property | null;
  filters: PropertyFilters;
  pagination: PaginationInfo;
  isLoading: boolean;
  error: string | null;
}

export interface PaymentState {
  paymentMethods: PaymentMethod[];
  currentPayment: PaymentIntent | null;
  isProcessing: boolean;
  error: string | null;
}