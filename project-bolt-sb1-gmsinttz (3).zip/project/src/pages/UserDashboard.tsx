import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Home, Heart, Bell, Settings, Plus, TrendingUp, Users, Eye, Star, Camera, Save, MapPin, BarChart3 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import FavoritesSystem from '../components/FavoritesSystem';
import MarketAnalysis from '../components/MarketAnalysis';
import InteractiveOverview from '../components/InteractiveOverview';
import PricePrediction from '../components/PricePrediction';
import { ResponsiveAd } from '../components/GoogleAds';
import { useSubscription } from '../hooks/useSubscription';

const UserDashboard: React.FC = () => {
  const { subscription, shouldShowAds } = useSubscription();
  const [activeTab, setActiveTab] = useState('overview');
  const { user, updateUser } = useAuth();
  const [profileData, setProfileData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    userType: 'buyer',
    profileImage: ''
  });
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  React.useEffect(() => {
    if (user) {
      setProfileData({
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        email: user.email || '',
        phone: user.phone || '',
        userType: user.userType || 'buyer',
        profileImage: user.profileImage || ''
      });
    }
  }, [user]);

  const tabs = [
    { id: 'overview', name: 'Overview', icon: Home },
    { id: 'properties', name: 'My Properties', icon: Home },
    { id: 'analytics', name: 'Market Analytics', icon: TrendingUp },
    { id: 'favorites', name: 'Favorites', icon: Heart },
    { id: 'notifications', name: 'Notifications', icon: Bell },
    { id: 'settings', name: 'Settings', icon: Settings }
  ];

  const handlePropertySelect = (property: any) => {
    // Navigate to property detail page or show modal
    window.location.href = `/property/${property.id}`;
  };

  const handleOverviewCardClick = (cardId: string, data: any) => {
    console.log('Dashboard overview card clicked:', cardId, data);
    
    switch (cardId) {
      case 'favorites':
      case 'saved-properties':
        setActiveTab('favorites');
        break;
      case 'market-analysis':
      case 'market-value':
      case 'market-trend':
        setActiveTab('analytics');
        break;
      case 'total-properties':
      case 'my-properties':
        setActiveTab('properties');
        break;
      case 'quick-search':
        // Could open a search modal or navigate to properties page
        window.location.href = '/properties';
        break;
      case 'map-view':
        // Could open map view or navigate to properties with map
        window.location.href = '/properties?view=map';
        break;
      default:
        if (data.category === 'market') {
          setActiveTab('analytics');
        } else if (data.category === 'properties') {
          setActiveTab('properties');
        } else if (data.category === 'activity') {
          setActiveTab('overview');
        }
    }
  };

  const myProperties = [
    {
      id: '1',
      title: 'Luxury 4BR Villa with Ornate Gates',
      location: 'Hill Station, Freetown',
      price: 4500000,
      status: 'active',
      views: 156,
      inquiries: 12,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg'
    },
    {
      id: '2',
      title: 'Modern 3BR House with Balcony',
      location: 'Murray Town, Freetown',
      price: 3200000,
      status: 'active',
      views: 134,
      inquiries: 9,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_49a9c835.jpg'
    }
  ];

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setProfileData(prev => ({ ...prev, profileImage: e.target!.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      updateUser(profileData);
      setIsEditing(false);
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Profile update error:', error);
      alert('An error occurred while updating profile');
    } finally {
      setIsSaving(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Please Log In</h2>
          <p className="text-gray-600 mb-6">You need to be logged in to access the dashboard.</p>
          <Link 
            to="/auth"
            className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700"
          >
            Go to Login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-2">Welcome back, {user?.firstName} {user?.lastName}</p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="text-center mb-6">
                <div className="relative inline-block">
                  <img 
                    src={profileData.profileImage || "https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg"}
                    alt="Profile"
                    className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                  />
                  {isEditing && (
                    <label className="absolute bottom-0 right-0 bg-green-600 text-white p-2 rounded-full cursor-pointer hover:bg-green-700 transition-colors">
                      <Camera className="h-4 w-4" />
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
                <div className="mb-4">
                  <img 
                    src="/WhatsApp Image 2025-07-20 at 15.40.21_5a21399f.jpg"
                    alt="MiOse Logo"
                    className="w-8 h-8 object-contain mx-auto opacity-60"
                  />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">{profileData.firstName} {profileData.lastName}</h3>
                <p className="text-sm text-gray-600 mb-4 capitalize">{profileData.userType}</p>
                <Link 
                  to="/add-property"
                  className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center transform hover:scale-105 mb-3"
                >
                  <Plus className="h-5 w-5 mr-2" />
                  Add Property
                </Link>
                <Link 
                  to="/subscription"
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center transform hover:scale-105"
                >
                  <Star className="h-5 w-5 mr-2" />
                  Upgrade Plan
                </Link>
              </div>
              
              <nav className="space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors ${
                      activeTab === tab.id 
                        ? 'bg-green-100 text-green-700' 
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <tab.icon className="h-5 w-5 mr-3" />
                    {tab.name}
                  </button>
                ))}
              </nav>
              
              {/* Ad for free users */}
              {shouldShowAds() && (
                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <div className="text-center mb-3">
                    <span className="text-xs text-gray-500">Advertisement</span>
                  </div>
                  <ResponsiveAd />
                  <div className="mt-3 text-center">
                    <p className="text-xs text-gray-600 mb-2">Remove ads</p>
                    <Link 
                      to="/subscription"
                      className="text-green-600 hover:text-green-700 font-medium text-xs"
                    >
                      Upgrade Plan
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'overview' && (
              <>
                {/* Interactive Overview */}
                <div className="mb-8">
                  <InteractiveOverview onCardClick={handleOverviewCardClick} />
                </div>

                {/* Price Prediction Section */}
                <div className="mb-8">
                  <PricePrediction />
                </div>

                {/* Ad between sections for free users */}
                {shouldShowAds() && (
                  <div className="mb-8 bg-white rounded-xl shadow-lg p-6">
                    <div className="text-center mb-4">
                      <span className="text-xs text-gray-500">Advertisement</span>
                    </div>
                    <ResponsiveAd />
                    <div className="mt-4 text-center">
                      <p className="text-sm text-gray-600 mb-2">
                        You're on the <strong>{subscription.planType}</strong> plan
                      </p>
                      <Link 
                        to="/subscription"
                        className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-green-700 transition-colors"
                      >
                        Upgrade to Remove Ads
                      </Link>
                    </div>
                  </div>
                )}

                {/* User-specific Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-white rounded-xl shadow-lg p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm">Total Properties</p>
                        <p className="text-3xl font-bold text-gray-900">2</p>
                      </div>
                      <Home className="h-12 w-12 text-green-600" />
                    </div>
                  </div>
                  <div className="bg-white rounded-xl shadow-lg p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm">Total Views</p>
                        <p className="text-3xl font-bold text-gray-900">290</p>
                      </div>
                      <Eye className="h-12 w-12 text-blue-600" />
                    </div>
                  </div>
                  <div className="bg-white rounded-xl shadow-lg p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm">Inquiries</p>
                        <p className="text-3xl font-bold text-gray-900">21</p>
                      </div>
                      <Users className="h-12 w-12 text-purple-600" />
                    </div>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-6">Recent Activity</h3>
                  <div className="space-y-4">
                    {[
                      { action: 'New inquiry received', property: 'Modern 3BR House', time: '2 hours ago' },
                      { action: 'Property viewed', property: 'Luxury Villa', time: '4 hours ago' },
                      { action: 'Price updated', property: 'Modern 3BR House', time: '1 day ago' }
                    ].map((activity, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{activity.action}</p>
                          <p className="text-gray-600 text-sm">{activity.property}</p>
                        </div>
                        <span className="text-gray-500 text-sm">{activity.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {activeTab === 'properties' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-900">My Properties</h3>
                  <Link 
                    to="/add-property"
                    className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center transform hover:scale-105"
                  >
                    <Plus className="h-5 w-5 mr-2" />
                    Add Property
                  </Link>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {myProperties.map((property) => (
                    <div key={property.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300 group">
                      <div className="relative h-48 overflow-hidden">
                        <img 
                          src={property.image}
                          alt={`${property.title} - Property in ${property.location}`}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          loading="lazy"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg';
                          }}
                        />
                        
                        <div className="absolute top-3 left-3">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold text-white ${
                            property.status === 'active' 
                              ? 'bg-green-500' 
                              : property.status === 'pending'
                              ? 'bg-yellow-500'
                              : 'bg-gray-500'
                          }`}>
                            {property.status.charAt(0).toUpperCase() + property.status.slice(1)}
                          </span>
                        </div>
                      </div>

                      <div className="p-6">
                        <div className="mb-4">
                          <h4 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">{property.title}</h4>
                          <div className="flex items-center text-gray-600 mb-2">
                            <MapPin className="h-4 w-4 mr-1" />
                            <span className="text-sm">{property.location}</span>
                          </div>
                          <div className="text-2xl font-bold text-green-600">
                            Le {property.price.toLocaleString()}
                            <span className="text-sm text-gray-500 font-normal">/month</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center">
                              <Eye className="h-4 w-4 mr-1" />
                              <span>{property.views}</span>
                            </div>
                            <div className="flex items-center">
                              <Users className="h-4 w-4 mr-1" />
                              <span>{property.inquiries}</span>
                            </div>
                          </div>
                          <div className="text-xs text-gray-500">
                            Listed 2 days ago
                          </div>
                        </div>

                        <div className="flex space-x-3">
                          <Link 
                            to={`/property/${property.id}`}
                            className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 text-center text-sm font-medium"
                          >
                            View Details
                          </Link>
                          <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:border-green-600 hover:text-green-600 transition-colors duration-200 text-sm font-medium">
                            Edit
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Account Settings</h3>
                
                <div className="mb-8 text-center">
                  <div className="relative inline-block">
                    <img 
                      src={profileData.profileImage || "https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg"}
                      alt="Profile"
                      className="w-32 h-32 rounded-full object-cover border-4 border-gray-200"
                    />
                    <label className="absolute bottom-2 right-2 bg-green-600 text-white p-3 rounded-full cursor-pointer hover:bg-green-700 transition-colors shadow-lg">
                      <Camera className="h-5 w-5" />
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">Click the camera icon to change your profile picture</p>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                      <input 
                        type="text"
                        name="firstName"
                        value={profileData.firstName}
                        onChange={handleProfileChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="Enter your first name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                      <input 
                        type="text"
                        name="lastName"
                        value={profileData.lastName}
                        onChange={handleProfileChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="Enter your last name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input 
                      type="email"
                      name="email"
                      value={profileData.email}
                      onChange={handleProfileChange}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      placeholder="Enter your email address"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                    <input 
                      type="tel"
                      name="phone"
                      value={profileData.phone}
                      onChange={handleProfileChange}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      placeholder="+232 76 123 456"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Account Type</label>
                    <select
                      name="userType"
                      value={profileData.userType}
                      onChange={handleProfileChange}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    >
                      <option value="buyer">Property Buyer</option>
                      <option value="renter">Property Renter</option>
                      <option value="landlord">Property Owner/Landlord</option>
                      <option value="agent">Real Estate Agent</option>
                    </select>
                  </div>

                  <div className="flex gap-4 pt-6 border-t border-gray-200">
                    <button 
                      onClick={handleSaveProfile}
                      disabled={isSaving}
                      className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 transform hover:scale-105 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSaving ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="h-5 w-5 mr-2" />
                          Save Changes
                        </>
                      )}
                    </button>
                    
                    <button 
                      onClick={() => {
                        setProfileData({
                          firstName: user?.firstName || '',
                          lastName: user?.lastName || '',
                          email: user?.email || '',
                          phone: user?.phone || '',
                          userType: user?.userType || 'buyer',
                          profileImage: user?.profileImage || ''
                        });
                      }}
                      className="border border-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                    >
                      Reset
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Other tabs content */}
            {activeTab === 'analytics' && (
              <div className="space-y-8">
                <PricePrediction />
                <MarketAnalysis />
              </div>
            )}

            {activeTab === 'favorites' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <FavoritesSystem onPropertySelect={handlePropertySelect} />
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Notifications</h3>
                <div className="space-y-4">
                  {[
                    { message: 'New inquiry for your Modern 3BR House', time: '2 hours ago', unread: true },
                    { message: 'Price alert: Similar properties in your area', time: '1 day ago', unread: false },
                    { message: 'Your property listing has been approved', time: '3 days ago', unread: false }
                  ].map((notification, index) => (
                    <div key={index} className={`p-4 rounded-lg ${notification.unread ? 'bg-blue-50 border-l-4 border-blue-500' : 'bg-gray-50'}`}>
                      <p className="text-gray-900">{notification.message}</p>
                      <p className="text-gray-500 text-sm mt-1">{notification.time}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;