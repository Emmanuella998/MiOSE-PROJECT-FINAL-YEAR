import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, Home, TrendingUp, Users, Award, ArrowRight, Play } from 'lucide-react';
import QuickSearch from '../components/QuickSearch';
import GoogleMap from '../components/GoogleMap';
import MarketAnalysis from '../components/MarketAnalysis';
import InteractiveOverview from '../components/InteractiveOverview';
import PropertyCard from '../components/PropertyCard';
import StatsSection from '../components/StatsSection';
import { BannerAd, ResponsiveAd } from '../components/GoogleAds';
import { useSubscription } from '../hooks/useSubscription';
import { favoritesService } from '../services/favoritesService';

const HomePage: React.FC = () => {
  const { shouldShowAds } = useSubscription();
  const [searchQuery, setSearchQuery] = useState('');
  const [propertyType, setPropertyType] = useState('all');
  const [activeSection, setActiveSection] = useState<string>('overview');
  const [selectedProperty, setSelectedProperty] = useState<any>(null);
  const [featuredProperties, setFeaturedProperties] = useState<any[]>([]);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Load featured properties
  useEffect(() => {
    const featured = favoritesService.getFeaturedProperties();
    const formattedFeatured = featured.map(prop => ({
      id: prop.id,
      title: prop.title,
      price: prop.price,
      currency: prop.currency,
      location: prop.district,
      bedrooms: prop.bedrooms,
      bathrooms: prop.bathrooms,
      area: prop.squareMeters,
      image: prop.image,
      type: prop.listingType,
      featured: prop.featured
    }));
    setFeaturedProperties(formattedFeatured);
  }, []);

  // Mock properties for map
  const mapProperties = featuredProperties.map(prop => ({
    ...prop,
    location: {
      lat: 8.4840 + (Math.random() - 0.5) * 0.1,
      lng: -13.2299 + (Math.random() - 0.5) * 0.1
    },
    district: prop.location,
    type: 'villa'
  }));

  const handleOverviewCardClick = (cardId: string, data: any) => {
    console.log('Overview card clicked:', cardId, data);
    
    switch (cardId) {
      case 'quick-search':
        setActiveSection('search');
        break;
      case 'market-analysis':
        setActiveSection('market');
        break;
      case 'map-view':
        setActiveSection('map');
        break;
      case 'total-properties':
        setActiveSection('search');
        // Pre-fill search with property data
        if (data.breakdown) {
          console.log('Property breakdown:', data.breakdown);
        }
        break;
      case 'market-value':
        setActiveSection('market');
        // Show market analysis with price focus
        if (data.analysis) {
          console.log('Market analysis:', data.analysis);
        }
        break;
      case 'monthly-views':
      case 'active-users':
      case 'favorites':
        // Show activity details
        if (data.recentActivity) {
          console.log('Recent activity:', data.recentActivity);
          // Could open a modal or navigate to analytics
        }
        break;
      default:
        if (data.category === 'location') {
          setActiveSection('map');
          // Focus map on selected district
          if (data.coordinates) {
            console.log('Focusing on district:', data.district, data.coordinates);
          }
        } else if (data.category === 'market') {
          setActiveSection('market');
        } else if (data.category === 'properties') {
          setActiveSection('search');
        }
    }
  };

  const handleQuickSearch = (filters: any) => {
    setIsSearching(true);
    setShowSearchResults(true);
    
    // Simulate search with featured properties
    setTimeout(() => {
      const filtered = featuredProperties.filter(prop => {
        if (filters.propertyType && filters.propertyType !== 'all') {
          return prop.type === filters.propertyType;
        }
        if (filters.district && filters.district !== 'all') {
          return prop.location.toLowerCase().includes(filters.district.toLowerCase());
        }
        return true;
      });
      setSearchResults(filtered);
      setIsSearching(false);
    }, 800);
  };

  const handlePropertySelect = (property: any) => {
    setSelectedProperty(property);
    setShowSearchResults(false);
    // Navigate to property detail
    window.location.href = `/property/${property.id}`;
  };

  const openYouTubeDemo = () => {
    // Replace with your actual YouTube video URL
    window.open('https://www.youtube.com/watch?v=dQw4w9WgXcQ', '_blank');
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-600 via-blue-600 to-green-800 text-white">
        <div className="absolute inset-0 bg-black bg-opacity-30"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-green-900/20 to-blue-900/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
                Discover Premium
                <span className="block text-yellow-300">Properties in Sierra Leone</span>
              </h1>
              <p className="text-xl lg:text-2xl mb-8 text-gray-100">
                Explore luxury villas, modern homes, and prime real estate opportunities across Freetown with our local expertise and advanced property matching technology.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link 
                  to="/properties"
                  className="bg-white text-green-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-200 flex items-center justify-center transform hover:scale-105"
                >
                  Start Searching
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
                <button 
                  onClick={openYouTubeDemo}
                  className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-green-600 transition-colors duration-200 flex items-center justify-center transform hover:scale-105"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Watch Demo
                </button>
              </div>
            </div>
            <div className="relative">
              <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-2xl p-6 lg:p-8 border border-white border-opacity-20">
                <h3 className="text-2xl font-bold mb-6">Quick Property Search</h3>
                <QuickSearch 
                  onPropertySelect={handlePropertySelect} 
                  onFiltersChange={handleQuickSearch} 
                />
                
                {/* Search Results */}
                {showSearchResults && (
                  <div className="mt-6 bg-white bg-opacity-95 backdrop-blur-sm rounded-xl p-4 max-h-80 overflow-y-auto">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-gray-900">
                        {isSearching ? 'Searching...' : `Found ${searchResults.length} properties`}
                      </h4>
                      <button 
                        onClick={() => setShowSearchResults(false)}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        ✕
                      </button>
                    </div>
                    
                    {isSearching ? (
                      <div className="flex justify-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                      </div>
                    ) : searchResults.length > 0 ? (
                      <div className="space-y-3">
                        {searchResults.map((property) => (
                          <div
                            key={property.id}
                            onClick={() => handlePropertySelect(property)}
                            className="flex items-center space-x-4 p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <img
                              src={property.image}
                              alt={property.title}
                              className="w-16 h-16 object-cover rounded-lg"
                            />
                            <div className="flex-1 min-w-0">
                              <h5 className="font-semibold text-gray-900 truncate">{property.title}</h5>
                              <p className="text-sm text-gray-600">{property.location}</p>
                              <p className="text-lg font-bold text-green-600">
                                Le {property.price.toLocaleString()}
                                {property.type === 'rent' && <span className="text-sm">/month</span>}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-600">
                        <p>No properties found matching your criteria.</p>
                        <p className="text-sm mt-2">Try adjusting your search filters.</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Google Ads Banner - Free Users Only */}
      {shouldShowAds() && (
        <section className="py-4 bg-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-2">
              <span className="text-xs text-gray-500">Advertisement</span>
            </div>
            <BannerAd className="mx-auto" />
          </div>
        </section>
      )}

      {/* Stats Section */}
      <StatsSection />

      {/* Interactive Dashboard Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Freetown Real Estate Dashboard</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore interactive insights, market analysis, and property locations across Freetown
            </p>
          </div>

          {/* Section Navigation */}
          <div className="flex justify-center mb-8">
            <div className="bg-white rounded-lg p-1 shadow-lg">
              {[
                { id: 'overview', name: 'Overview', icon: TrendingUp },
                { id: 'search', name: 'Search', icon: Search },
                { id: 'map', name: 'Map View', icon: MapPin },
                { id: 'market', name: 'Market Analysis', icon: Award }
              ].map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`flex items-center px-6 py-3 rounded-md font-medium transition-colors ${
                    activeSection === section.id
                      ? 'bg-green-600 text-white'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <section.icon className="h-5 w-5 mr-2" />
                  {section.name}
                </button>
              ))}
            </div>
          </div>

          {/* Dynamic Content */}
          {activeSection === 'overview' && <InteractiveOverview onCardClick={handleOverviewCardClick} />}
          {activeSection === 'search' && (
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-semibold text-gray-900 mb-6">Advanced Property Search</h3>
              <QuickSearch onPropertySelect={handlePropertySelect} onFiltersChange={handleQuickSearch} />
            </div>
          )}
          {activeSection === 'map' && <GoogleMap properties={mapProperties} onPropertySelect={setSelectedProperty} selectedProperty={selectedProperty} />}
          {activeSection === 'market' && <MarketAnalysis />}
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Properties</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Handpicked premium properties in Freetown's most desirable locations, verified by our local experts.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
            
            {/* Ad between properties for free users */}
            {shouldShowAds() && featuredProperties.length > 2 && (
              <div className="bg-gray-50 rounded-xl shadow-lg p-6 flex flex-col items-center justify-center">
                <span className="text-xs text-gray-500 mb-4">Advertisement</span>
                <ResponsiveAd />
                <div className="mt-4 text-center">
                  <p className="text-sm text-gray-600 mb-2">Remove ads with Pro plan</p>
                  <Link 
                    to="/subscription"
                    className="text-green-600 hover:text-green-700 font-medium text-sm"
                  >
                    Upgrade Now →
                  </Link>
                </div>
              </div>
            )}
          </div>
          <div className="text-center mt-12">
            <Link 
              to="/properties"
              className="bg-green-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-green-700 transition-colors duration-200 inline-block transform hover:scale-105"
            >
              View All Properties
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How MiOse Works</h2>
            <p className="text-xl text-gray-600">Simple steps to find your dream property in Freetown</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="h-10 w-10 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">1. Search & Filter</h3>
              <p className="text-gray-600">
                Use our advanced search with AI-powered filters to find properties that match your exact preferences and budget.
              </p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <MapPin className="h-10 w-10 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">2. Visit & Verify</h3>
              <p className="text-gray-600">
                Schedule visits with verified agents and get detailed property information including neighborhood insights.
              </p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Home className="h-10 w-10 text-yellow-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">3. Secure & Move</h3>
              <p className="text-gray-600">
                Complete transactions securely through our integrated payment system with Orange Money and Afrimoney support.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* AI Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                AI-Powered Property Intelligence
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Our advanced machine learning algorithms analyze market trends, property values, and user preferences to provide personalized recommendations and accurate price predictions.
              </p>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Price Prediction</h4>
                    <p className="text-gray-600">Get accurate property valuations based on location, amenities, and market trends.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Users className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Smart Matching</h4>
                    <p className="text-gray-600">Our AI learns your preferences to suggest properties you'll love.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Award className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Market Analysis</h4>
                    <p className="text-gray-600">Access detailed neighborhood analytics and investment insights.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-8">
                <img 
                  src="https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg" 
                  alt="AI Property Analysis"
                  className="rounded-xl shadow-lg w-full"
                />
                <div className="absolute -bottom-6 -right-6 bg-white rounded-xl p-6 shadow-xl">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">97%</div>
                    <div className="text-sm text-gray-600">Prediction Accuracy</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Find Your Dream Home?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who found their perfect property through MiOse. Start your journey today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              to="/properties"
              className="bg-white text-green-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-200 transform hover:scale-105 inline-block text-center"
            >
              Browse Properties
            </Link>
            <Link 
              to="/dashboard"
              className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-green-600 transition-colors duration-200 transform hover:scale-105 inline-block text-center"
            >
              List Your Property
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;