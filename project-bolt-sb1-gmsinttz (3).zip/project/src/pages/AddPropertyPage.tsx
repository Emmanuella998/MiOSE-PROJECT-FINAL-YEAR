import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Upload, MapPin, Home, DollarSign, Camera, Plus, X, Check, AlertCircle } from 'lucide-react';
import { propertiesAPI, uploadAPI } from '../utils/api';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { VALIDATION_RULES } from '../config/constants';
import PricePrediction from '../components/PricePrediction';

const AddPropertyPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    propertyType: 'apartment',
    listingType: 'rent',
    price: '',
    currency: 'SLL',
    address: '',
    district: '',
    bedrooms: '',
    bathrooms: '',
    squareMeters: '',
    amenities: [] as string[],
    images: [] as File[]
  });

  const [currentStep, setCurrentStep] = useState(1);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number[]>([]);
  const [priceAnalysis, setPriceAnalysis] = useState<any>(null);

  const districts = [
    'Central Freetown', 'East End', 'West End', 'Hill Station',
    'Murray Town', 'Kissy', 'Wellington', 'Lumley'
  ];

  const propertyTypes = [
    { value: 'apartment', label: 'Apartment' },
    { value: 'house', label: 'House' },
    { value: 'villa', label: 'Villa' },
    { value: 'land', label: 'Land' },
    { value: 'commercial', label: 'Commercial' }
  ];

  const availableAmenities = [
    'Air Conditioning', 'Furnished', 'Parking Space', 'Security System',
    'Generator Backup', 'Water Tank', 'High-Speed Internet', 'Kitchen Appliances',
    'Balcony View', 'Swimming Pool', 'Garden', 'Garage'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const toggleAmenity = (amenity: string) => {
    setFormData(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      processFiles(Array.from(files));
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    processFiles(files);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const processFiles = async (files: File[]) => {
    if (files.length === 0) return;

    // Check if adding these files would exceed the limit
    if (uploadedImages.length + files.length > VALIDATION_RULES.MAX_IMAGES_PER_PROPERTY) {
      alert(`Maximum ${VALIDATION_RULES.MAX_IMAGES_PER_PROPERTY} images allowed. You can add ${VALIDATION_RULES.MAX_IMAGES_PER_PROPERTY - uploadedImages.length} more.`);
      return;
    }
    
    const validFiles = files.filter(file => {
      // Validate file size
      if (file.size > VALIDATION_RULES.MAX_FILE_SIZE) {
        alert(`File ${file.name} is too large. Maximum size is ${VALIDATION_RULES.MAX_FILE_SIZE / (1024 * 1024)}MB.`);
        return false;
      }
      
      // Validate file type
      if (!VALIDATION_RULES.ALLOWED_IMAGE_TYPES.includes(file.type)) {
        alert(`File ${file.name} is not a supported image type. Please use JPEG, PNG, or WebP.`);
        return false;
      }
      
      return true;
    });

    // Process valid files
    for (let i = 0; i < validFiles.length; i++) {
      const file = validFiles[i];
      
      try {
        // Simulate upload progress
        const progressIndex = uploadProgress.length + i;
        setUploadProgress(prev => [...prev, 0]);
        
        // Simulate progress updates
        for (let progress = 0; progress <= 100; progress += 20) {
          await new Promise(resolve => setTimeout(resolve, 100));
          setUploadProgress(prev => {
            const newProgress = [...prev];
            newProgress[progressIndex] = progress;
            return newProgress;
          });
        }

        // Upload to server (simulated)
        const uploadResponse = await uploadAPI.uploadImage(file);
        
        if (uploadResponse.success) {
          setFormData(prev => ({
            ...prev,
            images: [...prev.images, file]
          }));
          setUploadedImages(prev => [...prev, uploadResponse.data.url]);
        } else {
          // Fallback to local preview
          const reader = new FileReader();
          reader.onload = (e) => {
            if (e.target?.result) {
              setFormData(prev => ({
                ...prev,
                images: [...prev.images, file]
              }));
              setUploadedImages(prev => [...prev, e.target!.result as string]);
            }
          };
          reader.readAsDataURL(file);
        }
      } catch (error) {
        console.error('Upload error:', error);
        // Fallback to local preview
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result) {
            setFormData(prev => ({
              ...prev,
              images: [...prev.images, file]
            }));
            setUploadedImages(prev => [...prev, e.target!.result as string]);
          }
        };
        reader.readAsDataURL(file);
      }
    }
    
    // Clear progress after completion
    setTimeout(() => {
      setUploadProgress([]);
    }, 1000);
  };

  const removeImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      alert('Please log in to list a property');
      navigate('/auth');
      return;
    }

    setIsSubmitting(true);
    
    const submitProperty = async () => {
      try {
        const propertyData = {
          title: formData.title,
          description: formData.description,
          propertyType: formData.propertyType,
          listingType: formData.listingType,
          price: parseFloat(formData.price),
          currency: formData.currency,
          address: formData.address,
          district: formData.district,
          bedrooms: parseInt(formData.bedrooms) || 0,
          bathrooms: parseInt(formData.bathrooms) || 0,
          squareMeters: parseFloat(formData.squareMeters) || 0,
          amenities: formData.amenities,
          images: uploadedImages.map((url, index) => ({
            url,
            caption: `Property image ${index + 1}`,
            isPrimary: index === 0
          }))
        };

        const response = await propertiesAPI.createProperty(propertyData);
        
        if (response.success) {
          alert('Property listed successfully!');
          navigate('/dashboard');
        } else {
          alert('Failed to list property: ' + response.error);
        }
      } catch (error) {
        console.error('Submit error:', error);
        alert('An error occurred while listing the property');
      } finally {
        setIsSubmitting(false);
      }
    };

    submitProperty();
  };

  const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, 5));
  const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 1));

  const canProceedToNextStep = () => {
    switch (currentStep) {
      case 1:
        return formData.title && formData.description && formData.propertyType && formData.listingType;
      case 2:
        return formData.address && formData.district && formData.price;
      case 3:
        return formData.bedrooms && formData.bathrooms && formData.squareMeters;
      case 4:
        return uploadedImages.length > 0;
      default:
        return true;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link 
            to="/dashboard"
            className="flex items-center text-gray-600 hover:text-green-600 transition-colors duration-200"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Dashboard
          </Link>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-3xl font-bold text-gray-900">List Your Property</h1>
            <span className="text-gray-600">Step {currentStep} of 5</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-green-600 to-blue-600 h-3 rounded-full transition-all duration-500"
              style={{ width: `${(currentStep / 5) * 100}%` }}
            ></div>
          </div>
          
          {/* Step Labels */}
          <div className="flex justify-between mt-3 text-xs">
            <span className={`font-medium ${currentStep >= 1 ? 'text-green-600' : 'text-gray-500'}`}>Basic Info</span>
            <span className={`font-medium ${currentStep >= 2 ? 'text-green-600' : 'text-gray-500'}`}>Location & Price</span>
            <span className={`font-medium ${currentStep >= 3 ? 'text-green-600' : 'text-gray-500'}`}>Property Details</span>
            <span className={`font-medium ${currentStep >= 4 ? 'text-green-600' : 'text-gray-500'}`}>Photos</span>
            <span className={`font-medium ${currentStep >= 5 ? 'text-green-600' : 'text-gray-500'}`}>Review & Publish</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-8">
          {/* Step 1: Basic Information */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <Home className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h2 className="text-2xl font-semibold text-gray-900">Basic Information</h2>
                <p className="text-gray-600">Tell us about your property</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Property Title *</label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="e.g., Modern 3BR Apartment in Central Freetown"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description *</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows={4}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Describe your property in detail..."
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Property Type *</label>
                  <select
                    name="propertyType"
                    value={formData.propertyType}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    {propertyTypes.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Listing Type *</label>
                  <select
                    name="listingType"
                    value={formData.listingType}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="rent">For Rent</option>
                    <option value="sale">For Sale</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Location & Price */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <MapPin className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h2 className="text-2xl font-semibold text-gray-900">Location & Pricing</h2>
                <p className="text-gray-600">Where is your property located?</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Full Address *</label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="e.g., 15 Siaka Stevens Street"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">District *</label>
                <select
                  name="district"
                  value={formData.district}
                  onChange={handleInputChange}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  required
                >
                  <option value="">Select District</option>
                  {districts.map(district => (
                    <option key={district} value={district}>{district}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Price *</label>
                  <input
                    type="number"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="2500000"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Currency</label>
                  <select
                    name="currency"
                    value={formData.currency}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="SLL">Sierra Leone Leone (SLL)</option>
                    <option value="USD">US Dollar (USD)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Property Details */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <Home className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                <h2 className="text-2xl font-semibold text-gray-900">Property Details</h2>
                <p className="text-gray-600">Provide specific details about your property</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Bedrooms *</label>
                  <input
                    type="number"
                    name="bedrooms"
                    value={formData.bedrooms}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="0"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Bathrooms *</label>
                  <input
                    type="number"
                    name="bathrooms"
                    value={formData.bathrooms}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="0"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Square Meters *</label>
                  <input
                    type="number"
                    name="squareMeters"
                    value={formData.squareMeters}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="0"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-4">Amenities</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {availableAmenities.map(amenity => (
                    <label key={amenity} className="flex items-center p-2 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.amenities.includes(amenity)}
                        onChange={() => toggleAmenity(amenity)}
                        className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">{amenity}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Images */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <Camera className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                <h2 className="text-2xl font-semibold text-gray-900">Property Images</h2>
                <p className="text-gray-600">Upload high-quality photos of your property</p>
              </div>
              
              <div 
                className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 ${
                  dragActive 
                    ? 'border-green-500 bg-green-50 scale-105' 
                    : 'border-gray-300 hover:border-green-400 hover:bg-gray-50'
                }`}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
              >
                <div className="space-y-4">
                  <Camera className="h-16 w-16 text-gray-400 mx-auto" />
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Upload Property Images</h3>
                    <p className="text-gray-600 mb-4">
                      Drag & drop images here or click to browse
                      <br />
                      <span className="text-sm">Add up to {VALIDATION_RULES.MAX_IMAGES_PER_PROPERTY} high-quality photos (Max {VALIDATION_RULES.MAX_FILE_SIZE / (1024 * 1024)}MB each)</span>
                    </p>
                  </div>
                  <label
                    htmlFor="image-upload"
                    className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-8 py-3 rounded-lg hover:from-green-700 hover:to-blue-700 transition-all duration-200 inline-flex items-center cursor-pointer transform hover:scale-105"
                  >
                    <Upload className="h-5 w-5 mr-2" />
                    Choose Images
                  </label>
                  <input
                    id="image-upload"
                    type="file"
                    multiple
                    accept=".jpg,.jpeg,.png,.webp"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Upload Progress */}
              {uploadProgress.length > 0 && (
                <div className="space-y-2">
                  {uploadProgress.map((progress, index) => (
                    <div key={index} className="bg-gray-100 rounded-lg p-3">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Uploading image {index + 1}...</span>
                        <span>{progress}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Image Preview Grid */}
              {uploadedImages.length > 0 && (
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Check className="h-5 w-5 text-green-600 mr-2" />
                    Uploaded Images ({uploadedImages.length})
                  </h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {uploadedImages.map((image, index) => (
                      <div key={index} className="relative group">
                        <div className="absolute top-2 left-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded-full z-10">
                          #{index + 1}
                        </div>
                        <img
                          src={image}
                          alt={`Property ${index + 1}`}
                          className="w-full h-32 object-cover rounded-lg border-2 border-gray-200 group-hover:border-green-400 transition-all duration-200"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
                        >
                          <X className="h-4 w-4" />
                        </button>
                        {index === 0 && (
                          <div className="absolute bottom-2 left-2 bg-green-500 text-white px-2 py-1 rounded text-xs font-bold">
                            Main Photo
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Upload Tips */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h4 className="font-semibold text-blue-900 mb-3 flex items-center">
                  <Camera className="h-5 w-5 mr-2" />
                  Photo Tips for Better Listings:
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-blue-800">
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <span className="mr-2">📸</span>
                      Use natural lighting when possible
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">🏠</span>
                      Include photos of all rooms and key features
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">🌳</span>
                      Show the exterior and any outdoor spaces
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">✨</span>
                      Ensure images are clear and well-composed
                    </li>
                  </ul>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <span className="mr-2">🎯</span>
                      The first image will be your main property photo
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">📊</span>
                      Maximum {VALIDATION_RULES.MAX_IMAGES_PER_PROPERTY} photos allowed
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">💾</span>
                      Supported formats: JPEG, PNG, WebP
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">⚡</span>
                      Maximum file size: {VALIDATION_RULES.MAX_FILE_SIZE / (1024 * 1024)}MB per image
                    </li>
                  </ul>
                </div>
              </div>

              {/* Photo Upload Status */}
              {uploadedImages.length > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-green-800 font-medium flex items-center">
                      <Check className="h-4 w-4 mr-2" />
                      {uploadedImages.length} of {VALIDATION_RULES.MAX_IMAGES_PER_PROPERTY} photos uploaded
                    </span>
                    <span className="text-green-600 text-sm">
                      {Math.round((uploadedImages.length / VALIDATION_RULES.MAX_IMAGES_PER_PROPERTY) * 100)}% complete
                    </span>
                  </div>
                  <div className="w-full bg-green-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(uploadedImages.length / VALIDATION_RULES.MAX_IMAGES_PER_PROPERTY) * 100}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {/* Validation Messages */}
              {uploadedImages.length === 0 && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-start">
                    <AlertCircle className="h-5 w-5 text-yellow-600 mr-2 mt-0.5" />
                    <div>
                      <p className="text-yellow-800 text-sm font-medium">
                        At least one photo is recommended
                      </p>
                      <p className="text-yellow-700 text-sm mt-1">
                        Properties with photos get 5x more views and inquiries!
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 5: Price Prediction & Confirmation */}
          {currentStep === 5 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <DollarSign className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h2 className="text-2xl font-semibold text-gray-900">Review & Price Analysis</h2>
                <p className="text-gray-600">Get AI-powered price insights and confirm your listing</p>
              </div>
              
              <PricePrediction 
                initialData={{
                  propertyType: formData.propertyType,
                  district: formData.district,
                  bedrooms: formData.bedrooms,
                  bathrooms: formData.bathrooms,
                  squareMeters: formData.squareMeters,
                  amenities: formData.amenities
                }}
                onPredictionComplete={(prediction) => {
                  setPriceAnalysis(prediction);
                }}
              />

              {/* Listing Summary */}
              <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl p-6 border border-gray-200">
                <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Check className="h-5 w-5 text-green-600 mr-2" />
                  Listing Summary
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div>
                      <span className="font-medium text-gray-700">Title:</span>
                      <p className="text-gray-900">{formData.title}</p>
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Type:</span>
                      <p className="text-gray-900 capitalize">{formData.propertyType} for {formData.listingType}</p>
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Location:</span>
                      <p className="text-gray-900">{formData.address}, {formData.district}</p>
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Price:</span>
                      <p className="text-gray-900 font-semibold">{formData.currency} {parseFloat(formData.price || '0').toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <span className="font-medium text-gray-700">Size:</span>
                      <p className="text-gray-900">{formData.bedrooms} bed, {formData.bathrooms} bath, {formData.squareMeters}m²</p>
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Photos:</span>
                      <p className="text-gray-900">{uploadedImages.length} uploaded</p>
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Amenities:</span>
                      <p className="text-gray-900">{formData.amenities.length} selected</p>
                    </div>
                    {priceAnalysis && (
                      <div>
                        <span className="font-medium text-gray-700">AI Price Analysis:</span>
                        <p className="text-green-600 font-semibold">
                          Le {priceAnalysis.predictedPrice?.toLocaleString()} 
                          <span className="text-sm text-gray-600 ml-1">
                            ({Math.round(priceAnalysis.confidenceScore * 100)}% confidence)
                          </span>
                        </p>
                      </div>
                    )}
                  </div>
                </div>
                
                {formData.amenities.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <span className="font-medium text-gray-700">Selected Amenities:</span>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {formData.amenities.map((amenity, index) => (
                        <span key={index} className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">
                          {amenity}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Final Confirmation */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                  <div>
                    <p className="text-blue-800 text-sm font-medium">
                      Ready to publish your listing?
                    </p>
                    <p className="text-blue-700 text-sm mt-1">
                      Your property will be visible to thousands of potential buyers and renters in Sierra Leone.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={prevStep}
              disabled={currentStep === 1}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Previous
            </button>

            {currentStep < 5 ? (
              <button
                type="button"
                onClick={nextStep}
                disabled={!canProceedToNextStep()}
                className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-blue-700 transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
              >
                Next Step
                <ArrowLeft className="h-4 w-4 ml-2 rotate-180" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={isSubmitting || uploadedImages.length === 0}
                className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-8 py-3 rounded-lg hover:from-green-700 hover:to-blue-700 transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Publishing...
                  </>
                ) : (
                  <>
                    <Check className="h-5 w-5 mr-2" />
                    Publish Property
                  </>
                )}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddPropertyPage;