import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Check, Star, Zap, Smartphone, Crown } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { SUBSCRIPTION_PLANS } from '../config/constants';
import Button from '../components/ui/Button';
import { useSubscription } from '../hooks/useSubscription';
import toast from 'react-hot-toast';

const SubscriptionPage: React.FC = () => {
  const { user } = useAuthStore();
  const { subscription, upgradePlan } = useSubscription();
  const navigate = useNavigate();
  const [selectedPlan, setSelectedPlan] = useState<string>('basic');

  const handlePlanSelect = (planId: string) => {
    setSelectedPlan(planId);
  };

  const handleSubscribe = () => {
    if (!user) {
      toast.error('Please log in to subscribe');
      navigate('/auth');
      return;
    }

    if (selectedPlan !== 'free') {
      upgradePlan(selectedPlan as 'basic' | 'pro');
      toast.success(`Upgraded to ${selectedPlanData.name} plan! Ads have been removed.`);
    }
    
    navigate('/dashboard');
  };

  const selectedPlanData = SUBSCRIPTION_PLANS.find(plan => plan.id === selectedPlan);

  if (!selectedPlanData) {
    return <div>Plan not found</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link 
            to="/dashboard"
            className="flex items-center text-gray-600 hover:text-green-600 transition-colors duration-200"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Dashboard
          </Link>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Plan</h1>
          <p className="text-xl text-gray-600">Select the perfect subscription to showcase your properties in Sierra Leone</p>
        </div>

        {/* Plan Selection */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {SUBSCRIPTION_PLANS.map((plan) => (
            <motion.div
              key={plan.id}
              onClick={() => handlePlanSelect(plan.id)}
              className={`relative bg-white rounded-xl shadow-lg p-8 cursor-pointer transition-all duration-300 ${
                selectedPlan === plan.id 
                  ? 'ring-4 ring-green-500 ring-opacity-50 transform scale-105' 
                  : 'hover:shadow-xl'
              }`}
              whileHover={{ scale: selectedPlan === plan.id ? 1.05 : 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {plan.isPopular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-bold flex items-center">
                    <Star className="h-4 w-4 mr-1" />
                    Most Popular
                  </span>
                </div>
              )}

              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  {plan.id === 'basic' ? (
                    <Smartphone className="h-8 w-8 text-green-600" />
                  ) : (
                    <Zap className="h-8 w-8 text-blue-600" />
                  )}
                </div>
                <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-gray-900">{plan.currency} {plan.price.toLocaleString()}</span>
                  <span className="text-gray-600 ml-2">per {plan.interval}</span>
                </div>
              </div>

              <ul className="space-y-3">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-5 w-5 text-green-600 mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              {selectedPlan === plan.id && (
                <div className="mt-6 text-center">
                  <span className="inline-block bg-green-600 text-white px-4 py-2 rounded-lg font-medium">
                    Selected Plan
                  </span>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Subscribe Button */}
        <div className="text-center">
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-center mb-2">
              <Crown className="h-5 w-5 text-blue-600 mr-2" />
              <span className="text-blue-800 font-medium">Payment Integration Coming Soon</span>
            </div>
            <p className="text-blue-700 text-sm">
              We're working on integrating secure payment options including Orange Money and Afrimoney for Sierra Leone users.
            </p>
          </div>
          
          <Button
            onClick={handleSubscribe}
            variant="primary"
            size="lg"
            className="px-12 py-4 text-xl"
          >
            Select {selectedPlanData.name} Plan
          </Button>
          <p className="text-gray-600 mt-4">
            Choose your plan now and get ready to showcase your properties to thousands of potential buyers and renters in Sierra Leone.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionPage;