import React, { useState } from 'react';
import { Filter, Grid, List, SortAsc, MapPin } from 'lucide-react';
import PropertyCard from '../components/PropertyCard';
import SearchFilters from '../components/SearchFilters';
import QuickSearch from '../components/QuickSearch';
import GoogleMap from '../components/GoogleMap';
import { ResponsiveAd, InFeedAd } from '../components/GoogleAds';
import { useSubscription } from '../hooks/useSubscription';
import { useProperties } from '../hooks/useProperties';

const PropertiesPage: React.FC = () => {
  const { shouldShowAds } = useSubscription();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showMap, setShowMap] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<any>(null);
  const [filters, setFilters] = useState({
    page: 1,
    limit: 20,
    sortBy: 'date',
    sortOrder: 'desc'
  });

  const { properties, loading, error, pagination, refetch } = useProperties(filters);

  // Convert properties for map view
  const mapProperties = properties.map(prop => ({
    ...prop,
    location: {
      lat: 8.4840 + (Math.random() - 0.5) * 0.1,
      lng: -13.2299 + (Math.random() - 0.5) * 0.1
    },
    district: prop.district,
    type: prop.propertyType
  }));

  const handleFilterChange = (newFilters: any) => {
    setFilters(prev => ({ ...prev, ...newFilters, page: 1 }));
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const [sortBy, sortOrder] = e.target.value.split('-');
    setFilters(prev => ({ ...prev, sortBy, sortOrder }));
  };

  const handlePageChange = (page: number) => {
    setFilters(prev => ({ ...prev, page }));
  };

  const handlePropertySelect = (property: any) => {
    setSelectedProperty(property);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Properties in Freetown</h1>
              <p className="text-gray-600 mt-2">
                {properties.length} properties found
                {selectedProperty && (
                  <span className="ml-2 text-green-600">• {selectedProperty.title} selected</span>
                )}
              </p>
            </div>
            
            <div className="flex items-center space-x-4 mt-4 lg:mt-0">
              {/* Sort Dropdown */}
              <select 
                onChange={handleSortChange}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="price-asc">Sort by Price: Low to High</option>
                <option value="price-desc">Sort by Price: High to Low</option>
                <option value="date-desc">Sort by Date: Newest</option>
                <option value="date-asc">Sort by Date: Oldest</option>
              </select>
              
              {/* View Mode Toggle */}
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setShowMap(!showMap)}
                  className={`p-2 rounded ${showMap ? 'bg-white shadow-sm' : ''}`}
                  title="Map View"
                >
                  <MapPin className="h-5 w-5 text-gray-600" />
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded ${viewMode === 'grid' ? 'bg-white shadow-sm' : ''}`}
                >
                  <Grid className="h-5 w-5 text-gray-600" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded ${viewMode === 'list' ? 'bg-white shadow-sm' : ''}`}
                >
                  <List className="h-5 w-5 text-gray-600" />
                </button>
              </div>
              
              {/* Filter Toggle */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="lg:hidden bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center"
              >
                <Filter className="h-5 w-5 mr-2" />
                Filters
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Search Bar */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <QuickSearch 
            onPropertySelect={handlePropertySelect}
            onFiltersChange={handleFilterChange}
          />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          {/* Filters Sidebar */}
          <div className={`lg:col-span-1 ${showFilters ? 'block' : 'hidden lg:block'}`}>
            <div className="bg-white rounded-xl shadow-lg p-6 sticky top-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">Search Filters</h3>
              <SearchFilters onFilterChange={handleFilterChange} />
            </div>
          </div>

          {/* Properties Grid */}
          <div className="lg:col-span-3 mt-8 lg:mt-0">
            {/* Map View */}
            {showMap && (
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Property Locations</h3>
                <GoogleMap 
                  properties={mapProperties} 
                  onPropertySelect={handlePropertySelect}
                  selectedProperty={selectedProperty}
                />
              </div>
            )}

            {loading ? (
              <div className="flex justify-center items-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
              </div>
            ) : error ? (
              <div className="text-center py-12">
                <p className="text-red-600 mb-4">{error}</p>
                <button 
                  onClick={() => refetch()}
                  className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
                >
                  Try Again
                </button>
              </div>
            ) : (
              <>
                <div className={`${
                  viewMode === 'grid' 
                    ? 'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6' 
                    : 'space-y-6'
                }`}>
                  {properties.map((property, index) => (
                    <React.Fragment key={property.id}>
                      <PropertyCard 
                        property={{
                          id: property.id,
                          title: property.title,
                          price: property.price,
                          currency: property.currency,
                          location: property.district,
                          bedrooms: property.bedrooms,
                          bathrooms: property.bathrooms,
                          area: property.squareMeters,
                          image: property.images[0]?.url || '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg',
                          type: property.listingType as 'rent' | 'sale',
                          featured: property.featured
                        }} 
                      />
                      
                      {/* Insert ad every 6 properties for free users */}
                      {shouldShowAds() && (index + 1) % 6 === 0 && (
                        <div className="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center justify-center border-2 border-dashed border-gray-200">
                          <span className="text-xs text-gray-500 mb-4">Advertisement</span>
                          <InFeedAd />
                          <div className="mt-4 text-center">
                            <p className="text-sm text-gray-600 mb-2">Tired of ads?</p>
                            <Link 
                              to="/subscription"
                              className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-green-700 transition-colors"
                            >
                              Go Ad-Free
                            </Link>
                          </div>
                        </div>
                      )}
                    </React.Fragment>
                  ))}
                </div>

                {/* Pagination */}
                {pagination.totalPages > 1 && (
                  <div className="mt-12 flex justify-center">
                    <nav className="flex items-center space-x-2">
                      <button 
                        onClick={() => handlePageChange(pagination.page - 1)}
                        disabled={pagination.page === 1}
                        className="px-3 py-2 text-gray-500 hover:text-gray-700 disabled:opacity-50"
                      >
                        Previous
                      </button>
                      
                      {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                        const page = i + 1;
                        return (
                          <button
                            key={page}
                            onClick={() => handlePageChange(page)}
                            className={`px-4 py-2 rounded-lg ${
                              pagination.page === page
                                ? 'bg-green-600 text-white'
                                : 'text-gray-700 hover:bg-gray-100'
                            }`}
                          >
                            {page}
                          </button>
                        );
                      })}
                      
                      <button 
                        onClick={() => handlePageChange(pagination.page + 1)}
                        disabled={pagination.page === pagination.totalPages}
                        className="px-3 py-2 text-gray-500 hover:text-gray-700 disabled:opacity-50"
                      >
                        Next
                      </button>
                    </nav>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertiesPage;