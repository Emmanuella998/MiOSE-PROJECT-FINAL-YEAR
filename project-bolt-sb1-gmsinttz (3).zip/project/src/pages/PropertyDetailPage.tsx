import { Link } from 'react-router-dom';
import React from 'react';
import { ArrowLeft, Heart, Share2, MapPin, Bed, Bath, Square, Calendar, Eye, Phone, Mail, MessageCircle } from 'lucide-react';
import { useParams } from 'react-router-dom';
import { useProperty } from '../hooks/useProperties';
import { recommendationsAPI } from '../utils/api';

const PropertyDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { property, loading, error } = useProperty(id!);
  const [priceAnalysis, setPriceAnalysis] = React.useState<any>(null);

  React.useEffect(() => {
    if (property) {
      // Get AI price prediction
      recommendationsAPI.getPricePrediction({
        propertyType: property.propertyType,
        district: property.district,
        bedrooms: property.bedrooms,
        bathrooms: property.bathrooms,
        squareMeters: property.squareMeters,
        amenities: property.amenities
      }).then(response => {
        if (response.success) {
          setPriceAnalysis(response.data);
        }
      });
    }
  }, [property]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  if (error || !property) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Property Not Found</h2>
          <p className="text-gray-600 mb-6">{error || 'The property you are looking for does not exist.'}</p>
          <Link 
            to="/properties"
            className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700"
          >
            Back to Properties
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Back Button */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link 
            to="/properties"
            className="flex items-center text-gray-600 hover:text-green-600 transition-colors duration-200"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Properties
          </Link>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Image Gallery */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
              <div className="relative">
                <img 
                  src={property.images[0]?.url || '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg'}
                  alt={`${property.title} - ${property.district}, Freetown`}
                  className="w-full h-96 object-cover"
                />
                <div className="absolute top-4 left-4 flex gap-2">
                  <span className={`text-white px-3 py-1 rounded-full text-sm font-semibold ${
                    property.listingType === 'sale' ? 'bg-blue-600' : 'bg-green-600'
                  }`}>
                    For {property.listingType === 'sale' ? 'Sale' : 'Rent'}
                  </span>
                  {property.featured && (
                    <span className="bg-yellow-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                      Featured
                    </span>
                  )}
                </div>
                <div className="absolute top-4 right-4 flex gap-2">
                  <button className="p-2 bg-white bg-opacity-80 rounded-full hover:bg-opacity-100 transition-all">
                    <Heart className="h-5 w-5 text-gray-600 hover:text-red-500" />
                  </button>
                  <button className="p-2 bg-white bg-opacity-80 rounded-full hover:bg-opacity-100 transition-all">
                    <Share2 className="h-5 w-5 text-gray-600" />
                  </button>
                </div>
              </div>
              
              {/* Image Thumbnails */}
              <div className="p-4 flex gap-2 overflow-x-auto">
                {property.images.map((image, i) => (
                  <img 
                    key={i}
                    src={image.url}
                    alt={image.caption || `Property ${i + 1}`}
                    className="w-20 h-20 object-cover rounded-lg cursor-pointer hover:opacity-75 transition-opacity"
                  />
                ))}
              </div>
            </div>

            {/* Property Details */}
            <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
              <div className="mb-6">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  {property.title}
                </h1>
                <div className="flex items-center text-gray-600 mb-4">
                  <MapPin className="h-5 w-5 mr-2" />
                  <span>{property.address}, {property.district}, Freetown, Sierra Leone</span>
                </div>
                <div className="text-3xl font-bold text-green-600">
                  {property.currency === 'SLL' ? 'Le' : property.currency} {property.price.toLocaleString()}
                  <span className="text-lg text-gray-600 font-normal">
                    {property.listingType === 'rent' ? '/month' : ''} (For {property.listingType === 'sale' ? 'Sale' : 'Rent'})
                  </span>
                </div>
              </div>

              {/* Property Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8 p-6 bg-gray-50 rounded-xl">
                <div className="text-center">
                  <Bed className="h-8 w-8 text-green-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900">{property.bedrooms}</div>
                  <div className="text-gray-600">Bedrooms</div>
                </div>
                <div className="text-center">
                  <Bath className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900">{property.bathrooms}</div>
                  <div className="text-gray-600">Bathrooms</div>
                </div>
                <div className="text-center">
                  <Square className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900">{property.squareMeters}</div>
                  <div className="text-gray-600">Sq Meters</div>
                </div>
                <div className="text-center">
                  <Calendar className="h-8 w-8 text-orange-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900">{new Date(property.createdAt).getFullYear()}</div>
                  <div className="text-gray-600">Year Built</div>
                </div>
              </div>

              {/* Description */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Description</h3>
                <p className="text-gray-600 leading-relaxed">
                  {property.description}
                </p>
              </div>

              {/* Amenities */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Amenities</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {property.amenities.map((amenity) => (
                    <div key={amenity} className="flex items-center text-gray-700">
                      <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                      {amenity}
                    </div>
                  ))}
                </div>
              </div>

              {/* Map */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Location</h3>
                <div className="bg-gray-200 h-64 rounded-xl flex items-center justify-center">
                  <p className="text-gray-600">Interactive Map Coming Soon</p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Contact Agent */}
            <div className="bg-white rounded-xl shadow-lg p-6 mb-6 sticky top-6">
              <div className="text-center mb-6">
                <img 
                  src={property.owner.profileImage || "https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg"}
                  alt="Real Estate Agent"
                  className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                />
                <h4 className="text-lg font-semibold text-gray-900">
                  {property.owner.firstName} {property.owner.lastName}
                </h4>
                <p className="text-gray-600">Licensed Real Estate Agent</p>
                <div className="flex items-center justify-center text-yellow-500 mt-2">
                  {[1,2,3,4,5].map((star) => (
                    <span key={star}>⭐</span>
                  ))}
                  <span className="text-gray-600 ml-2">(4.9)</span>
                </div>
              </div>

              <div className="space-y-3">
                <button className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center justify-center transform hover:scale-105">
                  <Phone className="h-5 w-5 mr-2" />
                  Call Agent
                </button>
                <button className="w-full border border-green-600 text-green-600 py-3 rounded-lg hover:bg-green-50 transition-colors duration-200 flex items-center justify-center transform hover:scale-105">
                  <Mail className="h-5 w-5 mr-2" />
                  Send Email
                </button>
                <button className="w-full border border-blue-600 text-blue-600 py-3 rounded-lg hover:bg-blue-50 transition-colors duration-200 flex items-center justify-center transform hover:scale-105">
                  <MessageCircle className="h-5 w-5 mr-2" />
                  WhatsApp
                </button>
              </div>

              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center text-gray-600 text-sm">
                  <Eye className="h-4 w-4 mr-2" />
                  <span>{property.viewsCount} people viewed this property</span>
                </div>
              </div>
            </div>

            {/* AI Price Analysis */}
            {priceAnalysis && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">AI Price Analysis</h4>
                
                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-600">Market Value</span>
                    <span className="font-semibold">
                      Le {priceAnalysis.priceRange.min.toLocaleString()} - {priceAnalysis.priceRange.max.toLocaleString()}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full" 
                      style={{width: `${priceAnalysis.confidenceScore * 100}%`}}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    {priceAnalysis.confidenceScore > 0.8 ? 'Excellent' : 'Good'} value for {property.district}
                  </p>
                </div>

                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Confidence Score</span>
                    <span className="font-semibold text-green-600">
                      {Math.round(priceAnalysis.confidenceScore * 100)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Area Average</span>
                    <span className="font-semibold">Le {priceAnalysis.marketAnalysis.areaAverage?.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Price Trend</span>
                    <span className={`font-semibold ${
                      priceAnalysis.marketAnalysis.trendPercentage > 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {priceAnalysis.marketAnalysis.trendPercentage > 0 ? '+' : ''}{priceAnalysis.marketAnalysis.trendPercentage}%
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetailPage;