import { create } from 'zustand';
import { Property, PropertyFilters, PropertyState, PaginationInfo } from '../types';
import { apiClient } from '../services/apiClient';

interface PropertyStore extends PropertyState {
  // Actions
  fetchProperties: (filters?: PropertyFilters) => Promise<void>;
  fetchProperty: (id: string) => Promise<void>;
  createProperty: (propertyData: any) => Promise<{ success: boolean; error?: string }>;
  updateProperty: (id: string, propertyData: any) => Promise<{ success: boolean; error?: string }>;
  deleteProperty: (id: string) => Promise<{ success: boolean; error?: string }>;
  setFilters: (filters: Partial<PropertyFilters>) => void;
  clearFilters: () => void;
  clearError: () => void;
  favoriteProperty: (id: string) => Promise<void>;
  unfavoriteProperty: (id: string) => Promise<void>;
  recordView: (id: string) => Promise<void>;
}

const initialFilters: PropertyFilters = {
  page: 1,
  limit: 20,
  sortBy: 'date',
  sortOrder: 'desc'
};

const initialPagination: PaginationInfo = {
  page: 1,
  limit: 20,
  total: 0,
  totalPages: 0,
  hasNext: false,
  hasPrev: false
};

export const usePropertyStore = create<PropertyStore>((set, get) => ({
  // Initial state
  properties: [],
  currentProperty: null,
  filters: initialFilters,
  pagination: initialPagination,
  isLoading: false,
  error: null,

  // Actions
  fetchProperties: async (filters?: PropertyFilters) => {
    set({ isLoading: true, error: null });

    try {
      const currentFilters = { ...get().filters, ...filters };
      const response = await apiClient.get('/properties', {
        params: currentFilters
      });

      if (response.success && response.data) {
        set({
          properties: response.data,
          pagination: response.pagination || initialPagination,
          filters: currentFilters,
          isLoading: false,
          error: null
        });
      } else {
        set({
          isLoading: false,
          error: response.error || 'Failed to fetch properties'
        });
      }
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.message || 'Failed to fetch properties'
      });
    }
  },

  fetchProperty: async (id: string) => {
    set({ isLoading: true, error: null });

    try {
      const response = await apiClient.get(`/properties/${id}`);

      if (response.success && response.data) {
        set({
          currentProperty: response.data,
          isLoading: false,
          error: null
        });

        // Record view
        await get().recordView(id);
      } else {
        set({
          currentProperty: null,
          isLoading: false,
          error: response.error || 'Property not found'
        });
      }
    } catch (error: any) {
      set({
        currentProperty: null,
        isLoading: false,
        error: error.message || 'Failed to fetch property'
      });
    }
  },

  createProperty: async (propertyData: any) => {
    try {
      const response = await apiClient.post('/properties', propertyData);

      if (response.success) {
        // Refresh properties list
        await get().fetchProperties();
        return { success: true };
      } else {
        return { success: false, error: response.error || 'Failed to create property' };
      }
    } catch (error: any) {
      return { success: false, error: error.message || 'Failed to create property' };
    }
  },

  updateProperty: async (id: string, propertyData: any) => {
    try {
      const response = await apiClient.put(`/properties/${id}`, propertyData);

      if (response.success) {
        // Update current property if it's the one being updated
        const currentProperty = get().currentProperty;
        if (currentProperty && currentProperty.id === id) {
          set({ currentProperty: { ...currentProperty, ...propertyData } });
        }

        // Refresh properties list
        await get().fetchProperties();
        return { success: true };
      } else {
        return { success: false, error: response.error || 'Failed to update property' };
      }
    } catch (error: any) {
      return { success: false, error: error.message || 'Failed to update property' };
    }
  },

  deleteProperty: async (id: string) => {
    try {
      const response = await apiClient.delete(`/properties/${id}`);

      if (response.success) {
        // Remove from properties list
        const properties = get().properties.filter(p => p.id !== id);
        set({ properties });

        // Clear current property if it's the one being deleted
        const currentProperty = get().currentProperty;
        if (currentProperty && currentProperty.id === id) {
          set({ currentProperty: null });
        }

        return { success: true };
      } else {
        return { success: false, error: response.error || 'Failed to delete property' };
      }
    } catch (error: any) {
      return { success: false, error: error.message || 'Failed to delete property' };
    }
  },

  setFilters: (filters: Partial<PropertyFilters>) => {
    const newFilters = { ...get().filters, ...filters };
    set({ filters: newFilters });
  },

  clearFilters: () => {
    set({ filters: initialFilters });
  },

  clearError: () => {
    set({ error: null });
  },

  favoriteProperty: async (id: string) => {
    try {
      await apiClient.post(`/properties/${id}/favorite`);
    } catch (error) {
      console.error('Failed to favorite property:', error);
    }
  },

  unfavoriteProperty: async (id: string) => {
    try {
      await apiClient.delete(`/properties/${id}/favorite`);
    } catch (error) {
      console.error('Failed to unfavorite property:', error);
    }
  },

  recordView: async (id: string) => {
    try {
      await apiClient.post(`/properties/${id}/view`);
      
      // Update view count in current property
      const currentProperty = get().currentProperty;
      if (currentProperty && currentProperty.id === id) {
        set({
          currentProperty: {
            ...currentProperty,
            viewsCount: currentProperty.viewsCount + 1
          }
        });
      }
    } catch (error) {
      console.error('Failed to record view:', error);
    }
  }
}));