import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, AuthState, LoginForm, RegisterForm } from '../types';
import { apiClient } from '../services/apiClient';
import { STORAGE_KEYS } from '../config/constants';

interface AuthStore extends AuthState {
  // Actions
  login: (credentials: LoginForm) => Promise<{ success: boolean; error?: string }>;
  register: (userData: RegisterForm) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateUser: (userData: Partial<User>) => void;
  clearError: () => void;
  checkAuth: () => Promise<void>;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      // Initial state
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      // Actions
      login: async (credentials: LoginForm) => {
        set({ isLoading: true, error: null });

        try {
          const response = await apiClient.post('/auth/login', credentials);

          if (response.success && response.data) {
            const { user, token } = response.data;
            
            apiClient.setAuthToken(token);
            set({
              user,
              isAuthenticated: true,
              isLoading: false,
              error: null
            });

            return { success: true };
          } else {
            set({
              isLoading: false,
              error: response.error || 'Login failed'
            });
            return { success: false, error: response.error || 'Login failed' };
          }
        } catch (error: any) {
          const errorMessage = error.message || 'Login failed';
          set({
            isLoading: false,
            error: errorMessage
          });
          return { success: false, error: errorMessage };
        }
      },

      register: async (userData: RegisterForm) => {
        set({ isLoading: true, error: null });

        try {
          const response = await apiClient.post('/auth/register', userData);

          if (response.success && response.data) {
            const { user, token } = response.data;
            
            apiClient.setAuthToken(token);
            set({
              user,
              isAuthenticated: true,
              isLoading: false,
              error: null
            });

            return { success: true };
          } else {
            set({
              isLoading: false,
              error: response.error || 'Registration failed'
            });
            return { success: false, error: response.error || 'Registration failed' };
          }
        } catch (error: any) {
          const errorMessage = error.message || 'Registration failed';
          set({
            isLoading: false,
            error: errorMessage
          });
          return { success: false, error: errorMessage };
        }
      },

      logout: async () => {
        try {
          await apiClient.post('/auth/logout');
        } catch (error) {
          console.error('Logout error:', error);
        } finally {
          apiClient.clearAuthToken();
          localStorage.removeItem(STORAGE_KEYS.USER_DATA);
          set({
            user: null,
            isAuthenticated: false,
            isLoading: false,
            error: null
          });
        }
      },

      updateUser: (userData: Partial<User>) => {
        const currentUser = get().user;
        if (currentUser) {
          const updatedUser = { ...currentUser, ...userData };
          set({ user: updatedUser });
          localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(updatedUser));
        }
      },

      clearError: () => {
        set({ error: null });
      },

      checkAuth: async () => {
        const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
        const userData = localStorage.getItem(STORAGE_KEYS.USER_DATA);

        if (token && userData) {
          try {
            const user = JSON.parse(userData);
            set({
              user,
              isAuthenticated: true,
              isLoading: false
            });
          } catch (error) {
            console.error('Auth check failed:', error);
            apiClient.clearAuthToken();
            localStorage.removeItem(STORAGE_KEYS.USER_DATA);
          }
        } else {
          set({ isLoading: false });
        }
      }
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated
      })
    }
  )
);