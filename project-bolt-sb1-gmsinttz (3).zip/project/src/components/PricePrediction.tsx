import React, { useState } from 'react';
import { TrendingUp, Calculator, MapPin, Home, DollarSign, BarChart3, Brain, Target } from 'lucide-react';
import { recommendationsAPI } from '../utils/api';

interface PricePredictionProps {
  onPredictionComplete?: (prediction: any) => void;
  initialData?: any;
}

const PricePrediction: React.FC<PricePredictionProps> = ({ onPredictionComplete, initialData }) => {
  const [formData, setFormData] = useState({
    propertyType: initialData?.propertyType || 'apartment',
    district: initialData?.district || '',
    bedrooms: initialData?.bedrooms || '',
    bathrooms: initialData?.bathrooms || '',
    squareMeters: initialData?.squareMeters || '',
    amenities: initialData?.amenities || []
  });
  
  const [prediction, setPrediction] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const districts = [
    'Central Freetown', 'East End', 'West End', 'Hill Station',
    'Murray Town', 'Kissy', 'Wellington', 'Lumley'
  ];

  const propertyTypes = [
    { value: 'apartment', label: 'Apartment' },
    { value: 'house', label: 'House' },
    { value: 'villa', label: 'Villa' },
    { value: 'land', label: 'Land' },
    { value: 'commercial', label: 'Commercial' }
  ];

  const availableAmenities = [
    'Air Conditioning', 'Furnished', 'Parking Space', 'Security System',
    'Generator Backup', 'Water Tank', 'High-Speed Internet', 'Kitchen Appliances',
    'Balcony View', 'Swimming Pool', 'Garden', 'Garage'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const toggleAmenity = (amenity: string) => {
    setFormData(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  const handlePredict = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const predictionData = {
        propertyType: formData.propertyType,
        district: formData.district,
        bedrooms: parseInt(formData.bedrooms) || 0,
        bathrooms: parseInt(formData.bathrooms) || 0,
        squareMeters: parseFloat(formData.squareMeters) || 0,
        amenities: formData.amenities
      };

      const response = await recommendationsAPI.getPricePrediction(predictionData);
      
      if (response.success) {
        setPrediction(response.data);
        if (onPredictionComplete) {
          onPredictionComplete(response.data);
        }
      } else {
        setError(response.error || 'Failed to get price prediction');
      }
    } catch (err) {
      setError('An error occurred while getting price prediction');
      console.error('Price prediction error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const formatPrice = (price: number) => {
    return `Le ${price.toLocaleString()}`;
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
      <div className="flex items-center mb-6">
        <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-xl flex items-center justify-center mr-4">
          <Brain className="h-6 w-6 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-semibold text-gray-900">AI Price Prediction</h3>
          <p className="text-gray-600 text-sm">Get accurate property valuations powered by machine learning</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Property Type</label>
          <select
            name="propertyType"
            value={formData.propertyType}
            onChange={handleInputChange}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          >
            {propertyTypes.map(type => (
              <option key={type.value} value={type.value}>{type.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">District</label>
          <select
            name="district"
            value={formData.district}
            onChange={handleInputChange}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          >
            <option value="">Select District</option>
            {districts.map(district => (
              <option key={district} value={district}>{district}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Bedrooms</label>
          <input
            type="number"
            name="bedrooms"
            value={formData.bedrooms}
            onChange={handleInputChange}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            min="0"
            placeholder="Number of bedrooms"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Bathrooms</label>
          <input
            type="number"
            name="bathrooms"
            value={formData.bathrooms}
            onChange={handleInputChange}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            min="0"
            placeholder="Number of bathrooms"
          />
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-2">Square Meters</label>
          <input
            type="number"
            name="squareMeters"
            value={formData.squareMeters}
            onChange={handleInputChange}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            min="0"
            placeholder="Property size in square meters"
          />
        </div>
      </div>

      {/* Amenities */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-4">Amenities</label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {availableAmenities.map(amenity => (
            <label key={amenity} className="flex items-center">
              <input
                type="checkbox"
                checked={formData.amenities.includes(amenity)}
                onChange={() => toggleAmenity(amenity)}
                className="rounded border-gray-300 text-green-600 focus:ring-green-500"
              />
              <span className="ml-2 text-sm text-gray-700">{amenity}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Predict Button */}
      <button
        onClick={handlePredict}
        disabled={isLoading || !formData.district}
        className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white py-3 px-6 rounded-lg hover:from-green-700 hover:to-blue-700 transition-all duration-200 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
      >
        {isLoading ? (
          <>
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
            Analyzing Market Data...
          </>
        ) : (
          <>
            <Target className="h-5 w-5 mr-2" />
            Get AI Price Prediction
          </>
        )}
      </button>

      {/* Error Display */}
      {error && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-700 flex items-center">
            <span className="mr-2">⚠️</span>
            {error}
          </p>
        </div>
      )}

      {/* Prediction Results */}
      {prediction && (
        <div className="mt-6 space-y-4">
          <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 border border-green-200">
            <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-green-600" />
              AI Price Analysis Results
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="text-center bg-white rounded-lg p-4">
                <div className="text-3xl font-bold text-green-600 mb-2">
                  {formatPrice(prediction.predictedPrice)}
                </div>
                <p className="text-gray-600">AI Predicted Value</p>
                <div className="mt-2 text-sm text-gray-500">
                  Based on {formData.district} market data
                </div>
              </div>
              
              <div className="text-center bg-white rounded-lg p-4">
                <div className="text-2xl font-bold text-blue-600 mb-2">
                  {Math.round(prediction.confidenceScore * 100)}%
                </div>
                <p className="text-gray-600">Confidence Score</p>
                <div className="mt-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full transition-all duration-500" 
                      style={{width: `${prediction.confidenceScore * 100}%`}}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-white rounded-lg">
              <h5 className="font-semibold text-gray-900 mb-3 flex items-center">
                <TrendingUp className="h-4 w-4 mr-2 text-green-600" />
                Price Range Analysis
              </h5>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Minimum Value</span>
                  <span className="font-semibold text-green-600">{formatPrice(prediction.priceRange.min)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Maximum Value</span>
                  <span className="font-semibold text-green-600">{formatPrice(prediction.priceRange.max)}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3 mt-3">
                  <div 
                    className="bg-gradient-to-r from-green-500 to-blue-500 h-3 rounded-full transition-all duration-500" 
                    style={{width: `${prediction.confidenceScore * 100}%`}}
                  ></div>
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  {prediction.confidenceScore > 0.8 ? '🎯 Excellent' : prediction.confidenceScore > 0.6 ? '✅ Good' : '⚠️ Fair'} prediction accuracy for {formData.district}
                </p>
              </div>
            </div>

            {prediction.marketAnalysis && (
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg border border-gray-200">
                  <h6 className="font-semibold text-gray-900 mb-3 flex items-center">
                    <MapPin className="h-4 w-4 mr-2 text-blue-600" />
                    Market Analysis
                  </h6>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Area Average</span>
                      <span className="font-semibold">{formatPrice(prediction.marketAnalysis.areaAverage || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Price per m²</span>
                      <span className="font-semibold">Le {prediction.marketAnalysis.pricePerSqm || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Market Trend</span>
                      <span className={`font-semibold flex items-center ${
                        prediction.marketAnalysis.marketTrend === 'increasing' ? 'text-green-600' : 
                        prediction.marketAnalysis.marketTrend === 'decreasing' ? 'text-red-600' : 'text-gray-600'
                      }`}>
                        {prediction.marketAnalysis.marketTrend === 'increasing' ? '📈' : 
                         prediction.marketAnalysis.marketTrend === 'decreasing' ? '📉' : '➡️'}
                        <span className="ml-1">{prediction.marketAnalysis.marketTrend || 'Stable'}</span>
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white p-4 rounded-lg border border-gray-200">
                  <h6 className="font-semibold text-gray-900 mb-3 flex items-center">
                    <DollarSign className="h-4 w-4 mr-2 text-green-600" />
                    Investment Insights
                  </h6>
                  <div className="text-sm text-gray-600 space-y-2">
                    <p className="flex items-start">
                      <span className="mr-2">💡</span>
                      This property is priced {prediction.predictedPrice > (prediction.marketAnalysis.areaAverage || 0) ? 'above' : 'below'} the area average.
                    </p>
                    <p className="flex items-start">
                      <span className="mr-2">📊</span>
                      Market conditions in {formData.district} are currently {prediction.marketAnalysis.marketTrend || 'stable'}.
                    </p>
                    <p className="flex items-start">
                      <span className="mr-2">🎯</span>
                      {prediction.confidenceScore > 0.8 ? 'High confidence in this valuation.' : 'Moderate confidence - consider market factors.'}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* AI Insights */}
            <div className="mt-4 p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border border-blue-200">
              <h6 className="font-semibold text-gray-900 mb-2 flex items-center">
                <Brain className="h-4 w-4 mr-2 text-purple-600" />
                AI Recommendations
              </h6>
              <div className="text-sm text-gray-700">
                <p className="mb-2">
                  Based on current market analysis for {formData.propertyType}s in {formData.district}:
                </p>
                <ul className="space-y-1 ml-4">
                  <li>• Properties with {formData.amenities.length} amenities typically sell {prediction.confidenceScore > 0.8 ? 'quickly' : 'within market average'}</li>
                  <li>• {formData.bedrooms} bedroom properties are {prediction.confidenceScore > 0.7 ? 'in high demand' : 'moderately popular'} in this area</li>
                  <li>• Consider highlighting unique features to stand out in the market</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PricePrediction;