import React from 'react';
import { TrendingUp, TrendingDown, BarChart3, PieChart, Activity } from 'lucide-react';

const LiveCharts: React.FC = () => {
  // Mock data for charts
  const marketData = {
    totalListings: 2547,
    activeListings: 1823,
    soldThisMonth: 156,
    averagePrice: 2850000,
    priceChange: 5.2,
    topDistricts: [
      { name: 'Hill Station', listings: 342, avgPrice: 4200000, change: 8.1 },
      { name: 'Central Freetown', listings: 298, avgPrice: 3100000, change: 3.4 },
      { name: 'West End', listings: 267, avgPrice: 3800000, change: 6.7 },
      { name: 'East End', listings: 234, avgPrice: 2400000, change: 2.1 }
    ],
    propertyTypes: [
      { type: 'Apartments', count: 1245, percentage: 48.9 },
      { type: 'Houses', count: 687, percentage: 27.0 },
      { type: 'Villas', count: 324, percentage: 12.7 },
      { type: 'Commercial', count: 198, percentage: 7.8 },
      { type: 'Land', count: 93, percentage: 3.6 }
    ],
    monthlyTrends: [
      { month: 'Jan', listings: 180, sales: 45 },
      { month: 'Feb', listings: 195, sales: 52 },
      { month: 'Mar', listings: 210, sales: 48 },
      { month: 'Apr', listings: 225, sales: 61 },
      { month: 'May', listings: 240, sales: 58 },
      { month: 'Jun', listings: 255, sales: 67 }
    ]
  };

  return (
    <div className="space-y-8">
      {/* Market Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Total Listings</p>
              <p className="text-3xl font-bold text-gray-900">{marketData.totalListings.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <BarChart3 className="h-6 w-6 text-blue-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-500 text-sm font-medium">+12.5%</span>
            <span className="text-gray-600 text-sm ml-2">vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Active Listings</p>
              <p className="text-3xl font-bold text-gray-900">{marketData.activeListings.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <Activity className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-500 text-sm font-medium">+8.3%</span>
            <span className="text-gray-600 text-sm ml-2">vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Sold This Month</p>
              <p className="text-3xl font-bold text-gray-900">{marketData.soldThisMonth}</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <TrendingUp className="h-6 w-6 text-purple-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-500 text-sm font-medium">+15.2%</span>
            <span className="text-gray-600 text-sm ml-2">vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Avg. Price</p>
              <p className="text-3xl font-bold text-gray-900">Le {(marketData.averagePrice / 1000000).toFixed(1)}M</p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
              <PieChart className="h-6 w-6 text-orange-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-500 text-sm font-medium">+{marketData.priceChange}%</span>
            <span className="text-gray-600 text-sm ml-2">vs last month</span>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Monthly Trends Chart */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Monthly Trends</h3>
          <div className="space-y-4">
            {marketData.monthlyTrends.map((month, index) => (
              <div key={month.month} className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-medium text-gray-700 w-8">{month.month}</span>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${(month.listings / 300) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600">{month.listings} listings</span>
                    </div>
                    <div className="flex items-center space-x-2 mt-1">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${(month.sales / 80) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600">{month.sales} sales</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Districts */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Top Districts</h3>
          <div className="space-y-4">
            {marketData.topDistricts.map((district, index) => (
              <div key={district.name} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{district.name}</h4>
                    <p className="text-sm text-gray-600">{district.listings} listings</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">Le {(district.avgPrice / 1000000).toFixed(1)}M</p>
                  <div className="flex items-center">
                    {district.change > 0 ? (
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                    )}
                    <span className={`text-sm font-medium ${district.change > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {district.change > 0 ? '+' : ''}{district.change}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Property Types Distribution */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Property Types Distribution</h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {marketData.propertyTypes.map((type, index) => (
            <div key={type.type} className="text-center">
              <div className="relative w-24 h-24 mx-auto mb-4">
                <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-gray-200"
                    stroke="currentColor"
                    strokeWidth="3"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    className={`${
                      index === 0 ? 'text-blue-600' :
                      index === 1 ? 'text-green-600' :
                      index === 2 ? 'text-purple-600' :
                      index === 3 ? 'text-orange-600' : 'text-red-600'
                    }`}
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeLinecap="round"
                    fill="none"
                    strokeDasharray={`${type.percentage}, 100`}
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-sm font-bold text-gray-900">{type.percentage}%</span>
                </div>
              </div>
              <h4 className="font-semibold text-gray-900">{type.type}</h4>
              <p className="text-sm text-gray-600">{type.count.toLocaleString()}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Real-time Activity Feed */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Recent Activity</h3>
        <div className="space-y-4">
          {[
            { action: 'New listing added', property: '3BR Apartment in Hill Station', time: '2 minutes ago', type: 'listing' },
            { action: 'Property sold', property: 'Villa in West End', time: '15 minutes ago', type: 'sale' },
            { action: 'Price updated', property: 'House in Central Freetown', time: '32 minutes ago', type: 'update' },
            { action: 'New inquiry received', property: '2BR Apartment in Murray Town', time: '1 hour ago', type: 'inquiry' },
            { action: 'Property rented', property: 'Commercial Space Downtown', time: '2 hours ago', type: 'rental' }
          ].map((activity, index) => (
            <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <div className="flex items-center space-x-4">
                <div className={`w-3 h-3 rounded-full ${
                  activity.type === 'listing' ? 'bg-blue-500' :
                  activity.type === 'sale' ? 'bg-green-500' :
                  activity.type === 'update' ? 'bg-yellow-500' :
                  activity.type === 'inquiry' ? 'bg-purple-500' : 'bg-orange-500'
                }`}></div>
                <div>
                  <p className="font-medium text-gray-900">{activity.action}</p>
                  <p className="text-sm text-gray-600">{activity.property}</p>
                </div>
              </div>
              <span className="text-sm text-gray-500">{activity.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LiveCharts;