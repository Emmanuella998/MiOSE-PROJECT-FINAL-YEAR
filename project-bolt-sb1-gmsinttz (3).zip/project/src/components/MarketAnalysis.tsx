import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, BarChart3, PieChart, DollarSign, Home, MapPin } from 'lucide-react';

interface MarketData {
  district: string;
  averagePrice: number;
  priceChange: number;
  totalListings: number;
  soldThisMonth: number;
  pricePerSqm: number;
  marketTrend: 'increasing' | 'decreasing' | 'stable';
}

interface PriceRange {
  min: number;
  max: number;
}

const MarketAnalysis: React.FC = () => {
  const [priceRange, setPriceRange] = useState<PriceRange>({ min: 40000, max: 150000 });
  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');
  const [timeframe, setTimeframe] = useState<string>('3m');

  // Mock market data for Freetown districts
  const marketData: MarketData[] = [
    {
      district: 'Hill Station',
      averagePrice: 125000,
      priceChange: 8.5,
      totalListings: 45,
      soldThisMonth: 12,
      pricePerSqm: 850,
      marketTrend: 'increasing'
    },
    {
      district: 'West End',
      averagePrice: 110000,
      priceChange: 6.2,
      totalListings: 38,
      soldThisMonth: 9,
      pricePerSqm: 780,
      marketTrend: 'increasing'
    },
    {
      district: 'Central Freetown',
      averagePrice: 95000,
      priceChange: 3.1,
      totalListings: 52,
      soldThisMonth: 15,
      pricePerSqm: 650,
      marketTrend: 'stable'
    },
    {
      district: 'East End',
      averagePrice: 75000,
      priceChange: 2.8,
      totalListings: 41,
      soldThisMonth: 11,
      pricePerSqm: 520,
      marketTrend: 'stable'
    },
    {
      district: 'Murray Town',
      averagePrice: 85000,
      priceChange: 4.5,
      totalListings: 33,
      soldThisMonth: 8,
      pricePerSqm: 580,
      marketTrend: 'increasing'
    },
    {
      district: 'Kissy',
      averagePrice: 55000,
      priceChange: -1.2,
      totalListings: 28,
      soldThisMonth: 6,
      pricePerSqm: 420,
      marketTrend: 'decreasing'
    }
  ];

  const filteredData = selectedDistrict === 'all' 
    ? marketData 
    : marketData.filter(d => d.district === selectedDistrict);

  const handlePriceRangeChange = (type: 'min' | 'max', value: number) => {
    setPriceRange(prev => ({
      ...prev,
      [type]: Math.max(40000, Math.min(150000, value))
    }));
  };

  const getPropertiesInRange = () => {
    return filteredData.filter(d => 
      d.averagePrice >= priceRange.min && d.averagePrice <= priceRange.max
    );
  };

  const calculateMarketStats = () => {
    const propertiesInRange = getPropertiesInRange();
    const totalListings = propertiesInRange.reduce((sum, d) => sum + d.totalListings, 0);
    const totalSold = propertiesInRange.reduce((sum, d) => sum + d.soldThisMonth, 0);
    const avgPrice = propertiesInRange.reduce((sum, d) => sum + d.averagePrice, 0) / propertiesInRange.length;
    
    return {
      totalListings,
      totalSold,
      avgPrice: avgPrice || 0,
      conversionRate: totalListings > 0 ? (totalSold / totalListings) * 100 : 0
    };
  };

  const stats = calculateMarketStats();

  return (
    <div className="space-y-6">
      {/* Market Analysis Header */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
          <BarChart3 className="h-6 w-6 mr-2 text-green-600" />
          Freetown Market Analysis
        </h2>
        
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">District</label>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="all">All Districts</option>
              {marketData.map(d => (
                <option key={d.district} value={d.district}>{d.district}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Timeframe</label>
            <select
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="1m">Last Month</option>
              <option value="3m">Last 3 Months</option>
              <option value="6m">Last 6 Months</option>
              <option value="1y">Last Year</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Property Type</label>
            <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent">
              <option value="all">All Types</option>
              <option value="apartment">Apartments</option>
              <option value="house">Houses</option>
              <option value="villa">Villas</option>
            </select>
          </div>
        </div>

        {/* Price Range Slider */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-4">
            Price Range: Le {priceRange.min.toLocaleString()} - Le {priceRange.max.toLocaleString()}
          </label>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-gray-600 mb-1">Minimum Price</label>
                <input
                  type="range"
                  min="40000"
                  max="150000"
                  step="5000"
                  value={priceRange.min}
                  onChange={(e) => handlePriceRangeChange('min', parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider-green"
                />
                <input
                  type="number"
                  min="40000"
                  max="150000"
                  value={priceRange.min}
                  onChange={(e) => handlePriceRangeChange('min', parseInt(e.target.value))}
                  className="w-full mt-2 p-2 border border-gray-300 rounded text-sm"
                />
              </div>
              
              <div>
                <label className="block text-xs text-gray-600 mb-1">Maximum Price</label>
                <input
                  type="range"
                  min="40000"
                  max="150000"
                  step="5000"
                  value={priceRange.max}
                  onChange={(e) => handlePriceRangeChange('max', parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider-green"
                />
                <input
                  type="number"
                  min="40000"
                  max="150000"
                  value={priceRange.max}
                  onChange={(e) => handlePriceRangeChange('max', parseInt(e.target.value))}
                  className="w-full mt-2 p-2 border border-gray-300 rounded text-sm"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Market Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Total Listings</p>
              <p className="text-3xl font-bold text-gray-900">{stats.totalListings}</p>
            </div>
            <Home className="h-12 w-12 text-blue-600" />
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-500 text-sm font-medium">In selected range</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Sold This Month</p>
              <p className="text-3xl font-bold text-gray-900">{stats.totalSold}</p>
            </div>
            <TrendingUp className="h-12 w-12 text-green-600" />
          </div>
          <div className="mt-4 flex items-center">
            <span className="text-green-500 text-sm font-medium">
              {stats.conversionRate.toFixed(1)}% conversion rate
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Average Price</p>
              <p className="text-3xl font-bold text-gray-900">
                Le {stats.avgPrice.toLocaleString()}
              </p>
            </div>
            <DollarSign className="h-12 w-12 text-purple-600" />
          </div>
          <div className="mt-4 flex items-center">
            <span className="text-blue-500 text-sm font-medium">In price range</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Market Heat</p>
              <p className="text-3xl font-bold text-gray-900">
                {getPropertiesInRange().length > 0 ? 'Hot' : 'Cool'}
              </p>
            </div>
            <PieChart className="h-12 w-12 text-orange-600" />
          </div>
          <div className="mt-4 flex items-center">
            <span className="text-orange-500 text-sm font-medium">
              {getPropertiesInRange().length} districts active
            </span>
          </div>
        </div>
      </div>

      {/* District Analysis */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">District Performance</h3>
        
        <div className="space-y-4">
          {getPropertiesInRange().map((district) => (
            <div key={district.district} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-gray-400 mr-2" />
                  <h4 className="font-semibold text-gray-900">{district.district}</h4>
                </div>
                <div className="flex items-center">
                  {district.marketTrend === 'increasing' ? (
                    <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                  ) : district.marketTrend === 'decreasing' ? (
                    <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                  ) : (
                    <div className="h-4 w-4 bg-gray-400 rounded-full mr-1" />
                  )}
                  <span className={`text-sm font-medium ${
                    district.marketTrend === 'increasing' ? 'text-green-500' :
                    district.marketTrend === 'decreasing' ? 'text-red-500' : 'text-gray-500'
                  }`}>
                    {district.priceChange > 0 ? '+' : ''}{district.priceChange}%
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Avg Price</p>
                  <p className="font-semibold">Le {district.averagePrice.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-600">Listings</p>
                  <p className="font-semibold">{district.totalListings}</p>
                </div>
                <div>
                  <p className="text-gray-600">Sold</p>
                  <p className="font-semibold">{district.soldThisMonth}</p>
                </div>
                <div>
                  <p className="text-gray-600">Price/m²</p>
                  <p className="font-semibold">Le {district.pricePerSqm}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Market Insights */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 border border-green-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Market Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="bg-white rounded-lg p-4">
            <h4 className="font-semibold text-green-700 mb-2">🔥 Hot Districts</h4>
            <p className="text-gray-600">
              Hill Station and West End showing strongest growth with 8.5% and 6.2% price increases respectively.
            </p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <h4 className="font-semibold text-blue-700 mb-2">💡 Investment Tip</h4>
            <p className="text-gray-600">
              Properties in your price range (Le {priceRange.min.toLocaleString()} - Le {priceRange.max.toLocaleString()}) 
              are most active in Central Freetown and East End.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketAnalysis;