import React, { useEffect, useRef, useState } from 'react';
import { Search, ZoomIn, ZoomOut, Layers, Navigation, MapPin } from 'lucide-react';

interface Property {
  id: string;
  title: string;
  price: number;
  location: { lat: number; lng: number };
  district: string;
  type: string;
  bedrooms: number;
  bathrooms: number;
  image: string;
  listingType: 'rent' | 'sale';
}

interface GoogleMapProps {
  properties: Property[];
  onPropertySelect: (property: Property) => void;
  selectedProperty?: Property | null;
  center?: { lat: number; lng: number };
  zoom?: number;
}

const GoogleMap: React.FC<GoogleMapProps> = ({ 
  properties, 
  onPropertySelect, 
  selectedProperty,
  center = { lat: 8.4840, lng: -13.2299 }, // Freetown center
  zoom = 12 
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);
  const [searchLocation, setSearchLocation] = useState('');
  const [mapStyle, setMapStyle] = useState<'roadmap' | 'satellite'>('roadmap');

  // Initialize Google Map
  useEffect(() => {
    if (!mapRef.current) return;
    
    // Check if Google Maps is available
    if (!window.google) {
      console.warn('Google Maps API not loaded. Using fallback map view.');
      // Show fallback message
      if (mapRef.current) {
        mapRef.current.innerHTML = `
          <div class="flex items-center justify-center h-full bg-gray-100 rounded-xl">
            <div class="text-center p-8">
              <div class="text-gray-400 mb-4">
                <svg class="w-16 h-16 mx-auto" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                </svg>
              </div>
              <h3 class="text-lg font-semibold text-gray-900 mb-2">Map View</h3>
              <p class="text-gray-600 text-sm">Interactive map showing property locations in Freetown</p>
              <div class="mt-4 text-xs text-gray-500">
                Google Maps API key required for full functionality
              </div>
            </div>
          </div>
        `;
      }
      return;
    }

    const map = new google.maps.Map(mapRef.current, {
      center,
      zoom,
      mapTypeId: mapStyle,
      styles: [
        {
          featureType: 'poi',
          elementType: 'labels',
          stylers: [{ visibility: 'off' }]
        }
      ],
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: false,
      zoomControl: false
    });

    mapInstanceRef.current = map;
    infoWindowRef.current = new google.maps.InfoWindow();

    // Add custom zoom controls
    const zoomInButton = document.createElement('button');
    zoomInButton.textContent = '+';
    zoomInButton.className = 'map-control-button';
    zoomInButton.onclick = () => map.setZoom(map.getZoom()! + 1);

    const zoomOutButton = document.createElement('button');
    zoomOutButton.textContent = '-';
    zoomOutButton.className = 'map-control-button';
    zoomOutButton.onclick = () => map.setZoom(map.getZoom()! - 1);

    map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(zoomInButton);
    map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(zoomOutButton);

    return () => {
      if (mapInstanceRef.current) {
        google.maps.event.clearInstanceListeners(mapInstanceRef.current);
      }
    };
  }, [center, zoom, mapStyle]);

  // Update markers when properties change
  useEffect(() => {
    if (!mapInstanceRef.current) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    // Add new markers
    properties.forEach(property => {
      const marker = new google.maps.Marker({
        position: property.location,
        map: mapInstanceRef.current,
        title: property.title,
        icon: {
          url: getPropertyIcon(property.type, property.listingType),
          scaledSize: new google.maps.Size(40, 40),
          anchor: new google.maps.Point(20, 40)
        }
      });

      marker.addListener('click', () => {
        onPropertySelect(property);
        showInfoWindow(marker, property);
      });

      markersRef.current.push(marker);
    });
  }, [properties, onPropertySelect]);

  // Highlight selected property
  useEffect(() => {
    if (!selectedProperty || !mapInstanceRef.current) return;

    const marker = markersRef.current.find(m => 
      m.getTitle() === selectedProperty.title
    );

    if (marker) {
      mapInstanceRef.current.panTo(selectedProperty.location);
      mapInstanceRef.current.setZoom(15);
      showInfoWindow(marker, selectedProperty);
    }
  }, [selectedProperty]);

  const getPropertyIcon = (type: string, listingType: string) => {
    const color = listingType === 'sale' ? 'blue' : 'green';
    const iconType = type === 'apartment' ? 'building' : 
                    type === 'villa' ? 'home' : 
                    type === 'land' ? 'terrain' : 'home';
    
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
      <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
        <circle cx="20" cy="20" r="18" fill="${color}" stroke="white" stroke-width="2"/>
        <text x="20" y="26" text-anchor="middle" fill="white" font-size="12" font-weight="bold">
          ${type === 'apartment' ? '🏢' : type === 'villa' ? '🏡' : type === 'land' ? '🏞️' : '🏠'}
        </text>
      </svg>
    `)}`;
  };

  const showInfoWindow = (marker: google.maps.Marker, property: Property) => {
    if (!infoWindowRef.current) return;

    const content = `
      <div style="max-width: 250px; padding: 10px;">
        <img src="${property.image}" alt="${property.title}" style="width: 100%; height: 120px; object-fit: cover; border-radius: 8px; margin-bottom: 8px;" />
        <h3 style="margin: 0 0 8px 0; font-size: 16px; font-weight: bold;">${property.title}</h3>
        <p style="margin: 0 0 4px 0; color: #666; font-size: 14px;">${property.district}</p>
        <p style="margin: 0 0 8px 0; font-size: 18px; font-weight: bold; color: #16a34a;">
          Le ${property.price.toLocaleString()}
          ${property.listingType === 'rent' ? '/month' : ''}
        </p>
        <p style="margin: 0; font-size: 14px; color: #666;">
          ${property.bedrooms} bed • ${property.bathrooms} bath
        </p>
      </div>
    `;

    infoWindowRef.current.setContent(content);
    infoWindowRef.current.open(mapInstanceRef.current, marker);
  };

  const handleLocationSearch = () => {
    if (!searchLocation || !mapInstanceRef.current) return;

    const geocoder = new google.maps.Geocoder();
    geocoder.geocode(
      { address: `${searchLocation}, Freetown, Sierra Leone` },
      (results, status) => {
        if (status === 'OK' && results && results[0]) {
          const location = results[0].geometry.location;
          mapInstanceRef.current!.setCenter(location);
          mapInstanceRef.current!.setZoom(14);
        }
      }
    );
  };

  const handleZoomIn = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setZoom(mapInstanceRef.current.getZoom()! + 1);
    }
  };

  const handleZoomOut = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setZoom(mapInstanceRef.current.getZoom()! - 1);
    }
  };

  const toggleMapStyle = () => {
    const newStyle = mapStyle === 'roadmap' ? 'satellite' : 'roadmap';
    setMapStyle(newStyle);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setMapTypeId(newStyle);
    }
  };

  return (
    <div className="relative w-full h-96 bg-gray-100 rounded-xl overflow-hidden border border-gray-200">
      {/* Map Controls */}
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
        {/* Search Bar */}
        <div className="bg-white rounded-lg shadow-lg p-2 flex items-center gap-2 min-w-64">
          <Search className="h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search Freetown areas..."
            value={searchLocation}
            onChange={(e) => setSearchLocation(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleLocationSearch();
              }
            }}
            className="flex-1 outline-none text-sm"
          />
          <button
            onClick={handleLocationSearch}
            className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700"
          >
            Search
          </button>
        </div>

        {/* Quick Location Buttons */}
        <div className="flex flex-wrap gap-1">
          {['Hill Station', 'West End', 'Central Freetown', 'East End'].map((district) => (
            <button
              key={district}
              onClick={() => {
                setSearchLocation(district);
                handleLocationSearch();
              }}
              className="bg-white text-xs px-2 py-1 rounded shadow hover:bg-gray-50 transition-colors"
            >
              {district}
            </button>
          ))}
        </div>
      </div>

      {/* Zoom and Style Controls */}
      <div className="absolute top-4 right-4 z-10 flex flex-col gap-1">
        <button
          onClick={handleZoomIn}
          className="bg-white p-2 rounded shadow hover:bg-gray-50 transition-colors"
        >
          <ZoomIn className="h-4 w-4" />
        </button>
        <button
          onClick={handleZoomOut}
          className="bg-white p-2 rounded shadow hover:bg-gray-50 transition-colors"
        >
          <ZoomOut className="h-4 w-4" />
        </button>
        <button
          onClick={toggleMapStyle}
          className="bg-white p-2 rounded shadow hover:bg-gray-50 transition-colors"
        >
          <Layers className="h-4 w-4" />
        </button>
      </div>

      {/* Google Map Container */}
      <div ref={mapRef} className="w-full h-full" />

      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3 text-xs">
        <div className="font-semibold mb-2">Property Types</div>
        <div className="grid grid-cols-2 gap-1">
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
            <span>For Sale</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 bg-green-500 rounded-full"></div>
            <span>For Rent</span>
          </div>
        </div>
      </div>

      {/* Property Count */}
      <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-lg p-2 text-xs">
        <div className="flex items-center gap-1">
          <MapPin className="h-3 w-3" />
          {properties.length} Properties
        </div>
      </div>

      <style jsx>{`
        .map-control-button {
          background: white;
          border: none;
          width: 40px;
          height: 40px;
          margin: 5px;
          border-radius: 4px;
          box-shadow: 0 2px 6px rgba(0,0,0,0.3);
          cursor: pointer;
          font-size: 18px;
          font-weight: bold;
        }
        .map-control-button:hover {
          background: #f5f5f5;
        }
      `}</style>
    </div>
  );
};

export default GoogleMap;