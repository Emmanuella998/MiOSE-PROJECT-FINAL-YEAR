import React, { useState, useEffect } from 'react';
import { Heart, Trash2, Share2, Eye, MapPin, Home, Calendar, Filter, Tag, Download, Upload } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { favoritesService, FavoriteProperty } from '../services/favoritesService';
import FavoriteButton from './FavoriteButton';
import toast from 'react-hot-toast';

interface FavoritesSystemProps {
  onPropertySelect: (property: FavoriteProperty) => void;
}

const FavoritesSystem: React.FC<FavoritesSystemProps> = ({ onPropertySelect }) => {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState<FavoriteProperty[]>([]);
  const [sortBy, setSortBy] = useState<'date' | 'price' | 'title'>('date');
  const [filterBy, setFilterBy] = useState<'all' | 'rent' | 'sale'>('all');
  const [editingNote, setEditingNote] = useState<string | null>(null);
  const [newTag, setNewTag] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [stats, setStats] = useState<any>(null);

  // Load favorites and stats
  const loadFavorites = () => {
    if (user) {
      const userFavorites = favoritesService.getFavorites(user.id);
      setFavorites(userFavorites);
      
      const userStats = favoritesService.getFavoritesStats(user.id);
      setStats(userStats);
    }
  };

  useEffect(() => {
    loadFavorites();
  }, [user]);

  // Listen for favorites updates
  useEffect(() => {
    const handleFavoritesUpdate = () => {
      loadFavorites();
    };

    window.addEventListener('favoritesUpdated', handleFavoritesUpdate);
    
    return () => {
      window.removeEventListener('favoritesUpdated', handleFavoritesUpdate);
    };
  }, [user]);

  const removeFavorite = (propertyId: string) => {
    if (user) {
      const success = favoritesService.removeFromFavorites(user.id, propertyId);
      if (success) {
        toast.success('Removed from favorites');
      }
    }
  };

  const updateNote = (propertyId: string, note: string) => {
    if (user) {
      const success = favoritesService.updateNotes(user.id, propertyId, note);
      if (success) {
        setEditingNote(null);
        loadFavorites();
        toast.success('Note updated');
      }
    }
  };

  const addTag = (propertyId: string) => {
    if (user && newTag.trim()) {
      const success = favoritesService.addTags(user.id, propertyId, [newTag.trim()]);
      if (success) {
        setNewTag('');
        loadFavorites();
        toast.success('Tag added');
      }
    }
  };

  const shareProperty = (property: FavoriteProperty) => {
    if (navigator.share) {
      navigator.share({
        title: property.title,
        text: `Check out this property in ${property.district}`,
        url: `${window.location.origin}/property/${property.id}`
      });
    } else {
      // Fallback: copy to clipboard
      const url = `${window.location.origin}/property/${property.id}`;
      navigator.clipboard.writeText(url);
      toast.success('Property link copied to clipboard!');
    }
  };

  const exportFavorites = () => {
    if (user) {
      const data = favoritesService.exportFavorites(user.id);
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `miose-favorites-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Favorites exported');
    }
  };

  const importFavorites = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && user) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = e.target?.result as string;
          const success = favoritesService.importFavorites(user.id, data);
          if (success) {
            toast.success('Favorites imported successfully');
          }
        } catch (error) {
          toast.error('Invalid file format');
        }
      };
      reader.readAsText(file);
    }
  };

  const getSortedAndFilteredFavorites = () => {
    let filtered = favorites;
    
    if (filterBy !== 'all') {
      filtered = favorites.filter(fav => fav.listingType === filterBy);
    }

    if (selectedTags.length > 0) {
      filtered = filtered.filter(fav => 
        selectedTags.some(tag => fav.tags?.includes(tag))
      );
    }
    
    return filtered.sort((a, b) => {
      switch (sortBy) {
        case 'price':
          return b.price - a.price;
        case 'title':
          return a.title.localeCompare(b.title);
        case 'date':
        default:
          return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
      }
    });
  };

  const formatPrice = (price: number, currency: string) => {
    return `${currency === 'SLL' ? 'Le' : currency} ${price.toLocaleString()}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  // Get all unique tags
  const allTags = [...new Set(favorites.flatMap(fav => fav.tags || []))];

  if (!user) {
    return (
      <div className="text-center py-12">
        <Heart className="h-16 w-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 mb-2">Sign in to save favorites</h3>
        <p className="text-gray-600">Create an account to save and manage your favorite properties</p>
      </div>
    );
  }

  const sortedFavorites = getSortedAndFilteredFavorites();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <Heart className="h-6 w-6 mr-2 text-red-500" />
            My Favorites ({favorites.length})
          </h2>
          <p className="text-gray-600 mt-1">Properties you've saved for later</p>
          
          {/* Stats */}
          {stats && (
            <div className="flex flex-wrap gap-4 mt-2 text-sm text-gray-600">
              <span>Avg Price: Le {Math.round(stats.averagePrice).toLocaleString()}</span>
              <span>Range: Le {stats.priceRange.min.toLocaleString()} - Le {stats.priceRange.max.toLocaleString()}</span>
            </div>
          )}
        </div>
        
        <div className="flex flex-wrap gap-3">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'date' | 'price' | 'title')}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
          >
            <option value="date">Sort by Date</option>
            <option value="price">Sort by Price</option>
            <option value="title">Sort by Title</option>
          </select>
          
          <select
            value={filterBy}
            onChange={(e) => setFilterBy(e.target.value as 'all' | 'rent' | 'sale')}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
          >
            <option value="all">All Types</option>
            <option value="sale">For Sale</option>
            <option value="rent">For Rent</option>
          </select>

          <button
            onClick={exportFavorites}
            className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm flex items-center"
          >
            <Download className="h-4 w-4 mr-1" />
            Export
          </button>

          <label className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm flex items-center cursor-pointer">
            <Upload className="h-4 w-4 mr-1" />
            Import
            <input
              type="file"
              accept=".json"
              onChange={importFavorites}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Tags Filter */}
      {allTags.length > 0 && (
        <div className="bg-white rounded-xl shadow-lg p-4">
          <h4 className="font-semibold mb-3">Filter by Tags:</h4>
          <div className="flex flex-wrap gap-2">
            {allTags.map(tag => (
              <button
                key={tag}
                onClick={() => {
                  setSelectedTags(prev => 
                    prev.includes(tag) 
                      ? prev.filter(t => t !== tag)
                      : [...prev, tag]
                  );
                }}
                className={`px-3 py-1 rounded-full text-sm ${
                  selectedTags.includes(tag)
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                <Tag className="h-3 w-3 inline mr-1" />
                {tag}
              </button>
            ))}
            {selectedTags.length > 0 && (
              <button
                onClick={() => setSelectedTags([])}
                className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm hover:bg-red-200"
              >
                Clear Filters
              </button>
            )}
          </div>
        </div>
      )}

      {/* Favorites List */}
      {sortedFavorites.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-xl">
          <Heart className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            {filterBy === 'all' ? 'No favorites yet' : `No ${filterBy} properties in favorites`}
          </h3>
          <p className="text-gray-600">
            {filterBy === 'all' 
              ? 'Start browsing properties and click the heart icon to save them here'
              : `Try changing the filter or browse ${filterBy} properties to add some favorites`
            }
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {sortedFavorites.map((property) => (
            <div key={property.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
              {/* Property Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={property.image}
                  alt={property.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg';
                  }}
                />
                
                <div className="absolute top-3 left-3">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold text-white ${
                    property.listingType === 'sale' ? 'bg-blue-600' : 'bg-green-600'
                  }`}>
                    For {property.listingType === 'sale' ? 'Sale' : 'Rent'}
                  </span>
                </div>
                
                <div className="absolute top-3 right-3 flex gap-2">
                  <button
                    onClick={() => shareProperty(property)}
                    className="p-2 bg-white bg-opacity-80 rounded-full hover:bg-opacity-100 transition-all"
                  >
                    <Share2 className="h-4 w-4 text-gray-600" />
                  </button>
                  <button
                    onClick={() => removeFavorite(property.id)}
                    className="p-2 bg-white bg-opacity-80 rounded-full hover:bg-opacity-100 transition-all"
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </button>
                </div>
              </div>

              {/* Property Details */}
              <div className="p-6">
                <div className="mb-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
                    {property.title}
                  </h3>
                  
                  <div className="flex items-center text-gray-600 mb-2">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span className="text-sm">{property.district}</span>
                  </div>
                  
                  <div className="text-2xl font-bold text-green-600">
                    {formatPrice(property.price, property.currency)}
                    {property.listingType === 'rent' && (
                      <span className="text-sm text-gray-500 font-normal">/month</span>
                    )}
                  </div>
                </div>

                {/* Property Stats */}
                <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <Home className="h-4 w-4 mr-1" />
                      <span>{property.bedrooms} bed, {property.bathrooms} bath</span>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>{formatDate(property.addedAt)}</span>
                  </div>
                </div>

                {/* Tags */}
                {property.tags && property.tags.length > 0 && (
                  <div className="mb-4">
                    <div className="flex flex-wrap gap-1">
                      {property.tags.map((tag, tagIndex) => (
                        <span
                          key={tagIndex}
                          className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Notes Section */}
                <div className="mb-4">
                  {editingNote === property.id ? (
                    <div className="space-y-2">
                      <textarea
                        defaultValue={property.userNotes || ''}
                        placeholder="Add your notes about this property..."
                        className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                        rows={3}
                        onBlur={(e) => updateNote(property.id, e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && e.ctrlKey) {
                            updateNote(property.id, e.currentTarget.value);
                          }
                          if (e.key === 'Escape') {
                            setEditingNote(null);
                          }
                        }}
                        autoFocus
                      />
                      
                      {/* Add Tag Input */}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={newTag}
                          onChange={(e) => setNewTag(e.target.value)}
                          placeholder="Add tag..."
                          className="flex-1 p-2 border border-gray-300 rounded text-sm"
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              addTag(property.id);
                            }
                          }}
                        />
                        <button
                          onClick={() => addTag(property.id)}
                          className="px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700"
                        >
                          <Tag className="h-3 w-3" />
                        </button>
                      </div>
                      
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            const textarea = document.querySelector(`textarea`) as HTMLTextAreaElement;
                            updateNote(property.id, textarea.value);
                          }}
                          className="px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700"
                        >
                          Save
                        </button>
                        <button
                          onClick={() => setEditingNote(null)}
                          className="px-3 py-1 bg-gray-300 text-gray-700 text-xs rounded hover:bg-gray-400"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div
                      onClick={() => setEditingNote(property.id)}
                      className="min-h-12 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
                    >
                      <p className="text-sm text-gray-700">
                        {property.userNotes || 'Click to add notes...'}
                      </p>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={() => onPropertySelect(property)}
                    className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium text-center"
                  >
                    <Eye className="h-4 w-4 inline mr-2" />
                    View Details
                  </button>
                  <button
                    onClick={() => shareProperty(property)}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:border-green-600 hover:text-green-600 transition-colors duration-200"
                  >
                    <Share2 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => removeFavorite(property.id)}
                    className="px-4 py-2 border border-red-300 text-red-700 rounded-lg hover:bg-red-50 transition-colors duration-200"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FavoritesSystem;