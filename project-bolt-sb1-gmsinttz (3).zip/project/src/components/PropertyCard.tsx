import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Bed, Bath, Square, Eye, Star } from 'lucide-react';
import FavoriteButton from './FavoriteButton';

interface Property {
  id: string;
  title: string;
  price: number;
  currency: string;
  location: string;
  bedrooms: number;
  bathrooms: number;
  area: number;
  image: string;
  type: 'rent' | 'sale';
  featured?: boolean;
}

interface PropertyCardProps {
  property: Property;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property }) => {
  const formatPrice = (price: number, currency: string) => {
    if (currency === 'SLL') {
      return `Le ${price.toLocaleString()}`;
    }
    return `${currency} ${price.toLocaleString()}`;
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 group">
      {/* Image Container */}
      <div className="relative overflow-hidden">
        <img 
          src={property.image} 
          alt={property.title}
          className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Overlays */}
        <div className="absolute top-4 left-4 flex gap-2">
          {property.featured && (
            <span className="bg-yellow-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center">
              <Star className="h-3 w-3 mr-1" />
              Featured
            </span>
          )}
          <span className={`px-3 py-1 rounded-full text-sm font-semibold text-white ${
            property.type === 'rent' ? 'bg-green-600' : 'bg-blue-600'
          }`}>
            For {property.type === 'rent' ? 'Rent' : 'Sale'}
          </span>
        </div>
        
        <div className="absolute top-4 right-4">
          <FavoriteButton 
            property={{
              id: property.id,
              title: property.title,
              price: property.price,
              currency: property.currency,
              district: property.location,
              propertyType: 'house',
              bedrooms: property.bedrooms,
              bathrooms: property.bathrooms,
              squareMeters: property.area,
              image: property.image,
              listingType: property.type,
              dateAdded: new Date().toISOString()
            }}
            size="md"
          />
        </div>
        
        <div className="absolute bottom-4 right-4 bg-black bg-opacity-60 text-white px-2 py-1 rounded text-sm flex items-center">
          <Eye className="h-3 w-3 mr-1" />
          124
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Price */}
        <div className="mb-3">
          <div className="text-2xl font-bold text-gray-900">
            {formatPrice(property.price, property.currency)}
            {property.type === 'rent' && <span className="text-lg text-gray-600 font-normal">/month</span>}
          </div>
        </div>

        {/* Title */}
        <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-green-600 transition-colors">
          {property.title}
        </h3>

        {/* Location */}
        <div className="flex items-center text-gray-600 mb-4">
          <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
          <span className="text-sm">{property.location}</span>
        </div>

        {/* Property Details */}
        <div className="flex items-center justify-between text-gray-600 text-sm">
          <div className="flex items-center">
            <Bed className="h-4 w-4 mr-1" />
            <span>{property.bedrooms} bed{property.bedrooms !== 1 ? 's' : ''}</span>
          </div>
          <div className="flex items-center">
            <Bath className="h-4 w-4 mr-1" />
            <span>{property.bathrooms} bath{property.bathrooms !== 1 ? 's' : ''}</span>
          </div>
          <div className="flex items-center">
            <Square className="h-4 w-4 mr-1" />
            <span>{property.area}m²</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex gap-3">
          <Link 
            to={`/property/${property.id}`}
            className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium text-center transform hover:scale-105"
          >
            View Details
          </Link>
          <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:border-green-600 hover:text-green-600 transition-colors duration-200 transform hover:scale-105">
            Contact
          </button>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;