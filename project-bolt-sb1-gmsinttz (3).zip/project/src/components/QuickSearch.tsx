import React, { useState, useEffect, useRef } from 'react';
import { Search, Filter, MapPin, Home, DollarSign, Clock, X, ArrowRight } from 'lucide-react';

interface Property {
  id: string;
  title: string;
  price: number;
  currency: string;
  district: string;
  propertyType: string;
  bedrooms: number;
  bathrooms: number;
  squareMeters: number;
  image: string;
  listingType: 'rent' | 'sale';
}

interface QuickSearchProps {
  onPropertySelect: (property: Property) => void;
  onFiltersChange: (filters: any) => void;
}

const QuickSearch: React.FC<QuickSearchProps> = ({ onPropertySelect, onFiltersChange }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Property[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [quickFilters, setQuickFilters] = useState({
    priceRange: 'all',
    propertyType: 'all',
    district: 'all',
    listingType: 'all'
  });

  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Enhanced mock property data
  const mockProperties: Property[] = [
    {
      id: '1',
      title: 'Luxury 4BR Villa with Ornate Gates',
      price: 125000,
      currency: 'SLL',
      district: 'Hill Station',
      propertyType: 'villa',
      bedrooms: 4,
      bathrooms: 3,
      squareMeters: 280,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg',
      listingType: 'sale'
    },
    {
      id: '2',
      title: 'Modern 3BR House with Balcony',
      price: 85000,
      currency: 'SLL',
      district: 'Murray Town',
      propertyType: 'house',
      bedrooms: 3,
      bathrooms: 2,
      squareMeters: 180,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_49a9c835.jpg',
      listingType: 'rent'
    },
    {
      id: '3',
      title: 'Colonial Style Villa with Columns',
      price: 110000,
      currency: 'SLL',
      district: 'West End',
      propertyType: 'villa',
      bedrooms: 5,
      bathrooms: 4,
      squareMeters: 320,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.59_6aa66276.jpg',
      listingType: 'sale'
    },
    {
      id: '4',
      title: 'Central Freetown Apartment',
      price: 65000,
      currency: 'SLL',
      district: 'Central Freetown',
      propertyType: 'apartment',
      bedrooms: 2,
      bathrooms: 1,
      squareMeters: 120,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_a1834ec7.jpg',
      listingType: 'rent'
    },
    {
      id: '5',
      title: 'East End Family House',
      price: 75000,
      currency: 'SLL',
      district: 'East End',
      propertyType: 'house',
      bedrooms: 3,
      bathrooms: 2,
      squareMeters: 200,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.59_a05b109f.jpg',
      listingType: 'sale'
    },
    {
      id: '6',
      title: 'Kissy Affordable Apartment',
      price: 45000,
      currency: 'SLL',
      district: 'Kissy',
      propertyType: 'apartment',
      bedrooms: 1,
      bathrooms: 1,
      squareMeters: 80,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg',
      listingType: 'rent'
    },
    {
      id: '7',
      title: 'Wellington Commercial Space',
      price: 95000,
      currency: 'SLL',
      district: 'Wellington',
      propertyType: 'commercial',
      bedrooms: 0,
      bathrooms: 2,
      squareMeters: 150,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_49a9c835.jpg',
      listingType: 'rent'
    },
    {
      id: '8',
      title: 'Lumley Beach House',
      price: 135000,
      currency: 'SLL',
      district: 'Lumley',
      propertyType: 'house',
      bedrooms: 4,
      bathrooms: 3,
      squareMeters: 250,
      image: '/properties/WhatsApp Image 2025-07-20 at 15.42.59_6aa66276.jpg',
      listingType: 'sale'
    }
  ];

  // Debounced search function
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchQuery.trim()) {
        performSearch(searchQuery);
      } else {
        setSearchResults([]);
        setShowResults(false);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchQuery, quickFilters]);

  // Close search results when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const performSearch = async (query: string) => {
    setIsSearching(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const filtered = mockProperties.filter(property => {
      const matchesQuery = 
        property.title.toLowerCase().includes(query.toLowerCase()) ||
        property.district.toLowerCase().includes(query.toLowerCase()) ||
        property.propertyType.toLowerCase().includes(query.toLowerCase()) ||
        property.bedrooms.toString().includes(query) ||
        property.price.toString().includes(query.replace(/[,\s]/g, ''));
      
      const matchesFilters = 
        (quickFilters.propertyType === 'all' || property.propertyType === quickFilters.propertyType) &&
        (quickFilters.district === 'all' || property.district === quickFilters.district) &&
        (quickFilters.listingType === 'all' || property.listingType === quickFilters.listingType) &&
        (quickFilters.priceRange === 'all' || 
          (quickFilters.priceRange === 'low' && property.price < 70000) ||
          (quickFilters.priceRange === 'mid' && property.price >= 70000 && property.price < 100000) ||
          (quickFilters.priceRange === 'high' && property.price >= 100000));
      
      return matchesQuery && matchesFilters;
    });
    
    // Sort results by relevance
    const sortedResults = filtered.sort((a, b) => {
      // Prioritize exact matches in title
      const aExactMatch = a.title.toLowerCase().includes(query.toLowerCase()) ? 1 : 0;
      const bExactMatch = b.title.toLowerCase().includes(query.toLowerCase()) ? 1 : 0;
      
      if (aExactMatch !== bExactMatch) {
        return bExactMatch - aExactMatch;
      }
      
      // Then by price (ascending)
      return a.price - b.price;
    });
    
    setSearchResults(sortedResults);
    setShowResults(true);
    setIsSearching(false);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim() && !recentSearches.includes(query.trim())) {
      setRecentSearches(prev => [query.trim(), ...prev.slice(0, 4)]);
    }
  };

  const handlePropertyClick = (property: Property) => {
    onPropertySelect(property);
    setShowResults(false);
    setSearchQuery('');
  };

  const handleFilterChange = (filterType: string, value: string) => {
    const newFilters = { ...quickFilters, [filterType]: value };
    setQuickFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const clearSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
    setShowResults(false);
    inputRef.current?.focus();
  };

  const handleSearchSubmit = () => {
    if (searchQuery.trim()) {
      performSearch(searchQuery);
      onFiltersChange({ ...quickFilters, query: searchQuery });
    }
  };

  const formatPrice = (price: number, currency: string) => {
    return `${currency === 'SLL' ? 'Le' : currency} ${price.toLocaleString()}`;
  };

  return (
    <div ref={searchRef} className="relative w-full">
      {/* Main Search Input */}
      <div className="relative mb-4">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <Search className={`h-5 w-5 ${isSearching ? 'animate-pulse text-green-500' : 'text-gray-400'}`} />
        </div>
        
        <input
          ref={inputRef}
          type="text"
          placeholder="Search properties in Freetown... (e.g., 'Hill Station villa', '3 bedroom')"
          value={searchQuery}
          onChange={(e) => handleSearch(e.target.value)}
          onFocus={() => searchQuery && setShowResults(true)}
          onKeyPress={(e) => {
            if (e.key === 'Enter') {
              handleSearchSubmit();
            }
          }}
          className="w-full pl-12 pr-32 py-3 lg:py-4 text-base lg:text-lg border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 shadow-lg hover:shadow-xl"
        />
        
        <div className="absolute inset-y-0 right-0 flex items-center pr-2">
          {searchQuery && (
            <button
              onClick={clearSearch}
              className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 mr-1 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          )}
          <button
            onClick={handleSearchSubmit}
            disabled={!searchQuery.trim() || isSearching}
            className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-4 lg:px-6 py-2 lg:py-2.5 rounded-lg hover:from-green-700 hover:to-blue-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center transform hover:scale-105"
          >
            {isSearching ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            ) : (
              <>
                <Search className="h-4 w-4 mr-1 lg:mr-2" />
                <span className="hidden sm:inline font-medium">Search</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Quick Filters */}
      <div className="grid grid-cols-2 lg:flex lg:flex-wrap gap-2 lg:gap-3 mb-4">
        <select
          value={quickFilters.priceRange}
          onChange={(e) => handleFilterChange('priceRange', e.target.value)}
          className="px-2 lg:px-3 py-2 border border-gray-300 rounded-lg text-xs lg:text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent hover:border-green-400 transition-colors"
        >
          <option value="all">💰 All Prices</option>
          <option value="low">💵 Under Le 70,000</option>
          <option value="mid">💴 Le 70,000 - 100,000</option>
          <option value="high">💎 Above Le 100,000</option>
        </select>

        <select
          value={quickFilters.propertyType}
          onChange={(e) => handleFilterChange('propertyType', e.target.value)}
          className="px-2 lg:px-3 py-2 border border-gray-300 rounded-lg text-xs lg:text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent hover:border-green-400 transition-colors"
        >
          <option value="all">🏠 All Types</option>
          <option value="apartment">🏢 Apartment</option>
          <option value="house">🏠 House</option>
          <option value="villa">🏡 Villa</option>
          <option value="commercial">🏪 Commercial</option>
        </select>

        <select
          value={quickFilters.district}
          onChange={(e) => handleFilterChange('district', e.target.value)}
          className="px-2 lg:px-3 py-2 border border-gray-300 rounded-lg text-xs lg:text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent hover:border-green-400 transition-colors"
        >
          <option value="all">📍 All Districts</option>
          <option value="Hill Station">⛰️ Hill Station</option>
          <option value="West End">🌊 West End</option>
          <option value="Central Freetown">🏙️ Central Freetown</option>
          <option value="East End">🌅 East End</option>
          <option value="Murray Town">🏘️ Murray Town</option>
          <option value="Kissy">🏠 Kissy</option>
          <option value="Wellington">🌳 Wellington</option>
          <option value="Lumley">🏖️ Lumley</option>
        </select>

        <select
          value={quickFilters.listingType}
          onChange={(e) => handleFilterChange('listingType', e.target.value)}
          className="px-2 lg:px-3 py-2 border border-gray-300 rounded-lg text-xs lg:text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent col-span-2 lg:col-span-1 hover:border-green-400 transition-colors"
        >
          <option value="all">🔄 Buy & Rent</option>
          <option value="sale">💰 For Sale</option>
          <option value="rent">🏠 For Rent</option>
        </select>
      </div>

      {/* Mobile Search Button */}
      <div className="lg:hidden mb-4">
        <button
          onClick={handleSearchSubmit}
          disabled={!searchQuery.trim() || isSearching}
          className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white py-3 px-4 rounded-lg hover:from-green-700 hover:to-blue-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center transform hover:scale-105"
        >
          {isSearching ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              Searching Properties...
            </>
          ) : (
            <>
              <Search className="h-5 w-5 mr-2" />
              Search Properties in Freetown
              <ArrowRight className="h-4 w-4 ml-2" />
            </>
          )}
        </button>
      </div>

      {/* Search Results Dropdown */}
      {showResults && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-xl shadow-2xl z-50 max-h-80 lg:max-h-96 overflow-hidden">
          {isSearching ? (
            <div className="p-6 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-3"></div>
              <p className="text-gray-600 font-medium">Searching properties...</p>
              <p className="text-gray-500 text-sm mt-1">Finding the best matches for you</p>
            </div>
          ) : searchResults.length > 0 ? (
            <>
              <div className="p-4 border-b border-gray-100 bg-green-50">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-green-800">
                    🎯 Found {searchResults.length} properties matching "{searchQuery}"
                  </p>
                  <button
                    onClick={() => setShowResults(false)}
                    className="text-gray-400 hover:text-gray-600 text-sm p-1 rounded hover:bg-white transition-colors"
                  >
                    ✕
                  </button>
                </div>
              </div>
              
              <div className="max-h-80 overflow-y-auto">
                {searchResults.map((property) => (
                  <div
                    key={property.id}
                    onClick={() => handlePropertyClick(property)}
                    className="p-4 hover:bg-green-50 cursor-pointer border-b border-gray-100 last:border-b-0 transition-all duration-200 hover:shadow-sm group"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="relative">
                        <img
                          src={property.image}
                          alt={property.title}
                          className="w-16 h-16 lg:w-20 lg:h-20 object-cover rounded-lg border-2 border-transparent group-hover:border-green-300 transition-all duration-200"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg';
                          }}
                        />
                        <div className="absolute -top-1 -right-1 bg-green-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                          {property.propertyType === 'villa' ? '🏡' : 
                           property.propertyType === 'apartment' ? '🏢' : 
                           property.propertyType === 'house' ? '🏠' : 
                           property.propertyType === 'commercial' ? '🏪' : '🏠'}
                        </div>
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-gray-900 truncate text-sm lg:text-base group-hover:text-green-700 transition-colors">
                          {property.title}
                        </h4>
                        <div className="flex flex-col lg:flex-row lg:items-center lg:space-x-4 mt-1 text-xs lg:text-sm text-gray-600">
                          <div className="flex items-center">
                            <MapPin className="h-3 w-3 mr-1 text-green-500" />
                            <span className="font-medium">{property.district}</span>
                          </div>
                          <div className="flex items-center mt-1 lg:mt-0">
                            <Home className="h-3 w-3 mr-1 text-blue-500" />
                            <span>{property.bedrooms} bed, {property.bathrooms} bath</span>
                          </div>
                          <div className="flex items-center mt-1 lg:mt-0">
                            <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                              property.listingType === 'sale' 
                                ? 'bg-blue-100 text-blue-700' 
                                : 'bg-green-100 text-green-700'
                            }`}>
                              For {property.listingType}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="font-bold text-green-600 text-sm lg:text-base group-hover:text-green-700 transition-colors">
                          {formatPrice(property.price, property.currency)}
                        </div>
                        <div className="text-xs lg:text-sm text-gray-500">
                          {property.squareMeters}m²
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="p-3 bg-gray-50 border-t border-gray-200">
                <button
                  onClick={() => {
                    setShowResults(false);
                    onFiltersChange({ ...quickFilters, query: searchQuery });
                  }}
                  className="w-full text-center text-green-600 hover:text-green-700 font-medium text-sm py-2 hover:bg-green-50 rounded transition-colors"
                >
                  View all {searchResults.length} results →
                </button>
              </div>
            </>
          ) : searchQuery ? (
            <div className="p-6 text-center">
              <div className="text-gray-400 mb-3">
                <Search className="h-12 w-12 mx-auto" />
              </div>
              <p className="text-gray-600 font-medium mb-2">No properties found for "{searchQuery}"</p>
              <div className="space-y-3">
                <p className="text-sm text-gray-500">Try adjusting your search or filters</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  <button
                    onClick={() => handleSearch('villa')}
                    className="text-xs bg-green-100 hover:bg-green-200 text-green-700 px-3 py-1 rounded-full transition-colors"
                  >
                    🏡 Try "villa"
                  </button>
                  <button
                    onClick={() => handleSearch('Hill Station')}
                    className="text-xs bg-blue-100 hover:bg-blue-200 text-blue-700 px-3 py-1 rounded-full transition-colors"
                  >
                    ⛰️ Try "Hill Station"
                  </button>
                  <button
                    onClick={() => handleSearch('3 bedroom')}
                    className="text-xs bg-purple-100 hover:bg-purple-200 text-purple-700 px-3 py-1 rounded-full transition-colors"
                  >
                    🏠 Try "3 bedroom"
                  </button>
                  <button
                    onClick={() => handleSearch('apartment')}
                    className="text-xs bg-orange-100 hover:bg-orange-200 text-orange-700 px-3 py-1 rounded-full transition-colors"
                  >
                    🏢 Try "apartment"
                  </button>
                </div>
              </div>
            </div>
          ) : (
            recentSearches.length > 0 && (
              <div className="p-4">
                <p className="text-sm font-medium text-gray-700 mb-3 flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-gray-500" />
                  Recent Searches
                </p>
                {recentSearches.map((search, index) => (
                  <button
                    key={index}
                    onClick={() => handleSearch(search)}
                    className="block w-full text-left px-3 py-2 text-sm text-gray-600 hover:bg-green-50 hover:text-green-700 rounded transition-colors"
                  >
                    <Clock className="h-3 w-3 inline mr-2 text-gray-400" />
                    {search}
                  </button>
                ))}
              </div>
            )
          )}
        </div>
      )}

      {/* Popular Searches */}
      {!showResults && !searchQuery && (
        <div className="mt-4">
          <p className="text-sm font-medium text-gray-700 mb-3 flex items-center">
            <Filter className="h-4 w-4 mr-2 text-gray-500" />
            Popular Searches:
          </p>
          <div className="flex flex-wrap gap-2">
            {[
              { term: 'Hill Station villa', emoji: '🏡' },
              { term: 'Central Freetown apartment', emoji: '🏢' },
              { term: '3 bedroom house', emoji: '🏠' },
              { term: 'West End property', emoji: '🌊' },
              { term: 'furnished apartment', emoji: '🛋️' },
              { term: 'commercial space', emoji: '🏪' }
            ].map((item) => (
              <button
                key={item.term}
                onClick={() => handleSearch(item.term)}
                className="text-xs bg-gray-100 hover:bg-green-100 text-gray-700 hover:text-green-700 px-3 py-1.5 rounded-full transition-all duration-200 hover:scale-105 flex items-center"
              >
                <span className="mr-1">{item.emoji}</span>
                {item.term}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default QuickSearch;