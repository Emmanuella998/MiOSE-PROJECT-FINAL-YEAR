import React, { useState, useEffect } from 'react';
import { MapPin, Search, ZoomIn, ZoomOut, Layers, Navigation } from 'lucide-react';

interface Property {
  id: string;
  title: string;
  price: number;
  location: { lat: number; lng: number };
  district: string;
  type: string;
  bedrooms: number;
  bathrooms: number;
}

interface MapViewProps {
  properties: Property[];
  onPropertySelect: (property: Property) => void;
  selectedProperty?: Property | null;
}

const MapView: React.FC<MapViewProps> = ({ properties, onPropertySelect, selectedProperty }) => {
  const [mapCenter, setMapCenter] = useState({ lat: 8.4840, lng: -13.2299 }); // Freetown center
  const [zoomLevel, setZoomLevel] = useState(12);
  const [searchLocation, setSearchLocation] = useState('');
  const [mapStyle, setMapStyle] = useState('standard');

  // Freetown districts with coordinates
  const freetownDistricts = [
    { name: 'Central Freetown', lat: 8.4840, lng: -13.2299 },
    { name: 'East End', lat: 8.4900, lng: -13.2200 },
    { name: 'West End', lat: 8.4800, lng: -13.2400 },
    { name: 'Hill Station', lat: 8.4950, lng: -13.2350 },
    { name: 'Murray Town', lat: 8.4750, lng: -13.2450 },
    { name: 'Kissy', lat: 8.4650, lng: -13.2100 },
    { name: 'Wellington', lat: 8.4600, lng: -13.1900 },
    { name: 'Lumley', lat: 8.4500, lng: -13.2800 }
  ];

  const handleLocationSearch = (location: string) => {
    const district = freetownDistricts.find(d => 
      d.name.toLowerCase().includes(location.toLowerCase())
    );
    
    if (district) {
      setMapCenter({ lat: district.lat, lng: district.lng });
      setZoomLevel(14);
    }
  };

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev + 1, 18));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev - 1, 8));
  };

  const getPropertyIcon = (type: string) => {
    switch (type) {
      case 'apartment': return '🏢';
      case 'house': return '🏠';
      case 'villa': return '🏡';
      case 'land': return '🏞️';
      case 'commercial': return '🏪';
      default: return '📍';
    }
  };

  return (
    <div className="relative w-full h-96 bg-gray-100 rounded-xl overflow-hidden border border-gray-200">
      {/* Map Controls */}
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
        {/* Search Bar */}
        <div className="bg-white rounded-lg shadow-lg p-2 flex items-center gap-2 min-w-64">
          <Search className="h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search Freetown areas..."
            value={searchLocation}
            onChange={(e) => setSearchLocation(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleLocationSearch(searchLocation);
              }
            }}
            className="flex-1 outline-none text-sm"
          />
        </div>

        {/* Quick Location Buttons */}
        <div className="flex flex-wrap gap-1">
          {freetownDistricts.slice(0, 4).map((district) => (
            <button
              key={district.name}
              onClick={() => {
                setMapCenter({ lat: district.lat, lng: district.lng });
                setZoomLevel(14);
              }}
              className="bg-white text-xs px-2 py-1 rounded shadow hover:bg-gray-50 transition-colors"
            >
              {district.name}
            </button>
          ))}
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="absolute top-4 right-4 z-10 flex flex-col gap-1">
        <button
          onClick={handleZoomIn}
          className="bg-white p-2 rounded shadow hover:bg-gray-50 transition-colors"
        >
          <ZoomIn className="h-4 w-4" />
        </button>
        <button
          onClick={handleZoomOut}
          className="bg-white p-2 rounded shadow hover:bg-gray-50 transition-colors"
        >
          <ZoomOut className="h-4 w-4" />
        </button>
        <button
          onClick={() => setMapStyle(mapStyle === 'standard' ? 'satellite' : 'standard')}
          className="bg-white p-2 rounded shadow hover:bg-gray-50 transition-colors"
        >
          <Layers className="h-4 w-4" />
        </button>
      </div>

      {/* Map Container */}
      <div 
        className={`w-full h-full relative ${
          mapStyle === 'satellite' ? 'bg-green-800' : 'bg-green-50'
        }`}
        style={{
          backgroundImage: mapStyle === 'satellite' 
            ? 'radial-gradient(circle at 30% 70%, rgba(34, 197, 94, 0.3), rgba(22, 163, 74, 0.5))'
            : 'linear-gradient(45deg, rgba(34, 197, 94, 0.1), rgba(59, 130, 246, 0.1))'
        }}
      >
        {/* Freetown Coastline Simulation */}
        <div className="absolute bottom-0 left-0 w-full h-1/3 bg-blue-200 opacity-30 rounded-t-full"></div>
        
        {/* Property Markers */}
        {properties.map((property) => {
          const x = ((property.location.lng + 13.3) * 800) % 100;
          const y = ((8.6 - property.location.lat) * 600) % 100;
          
          return (
            <div
              key={property.id}
              className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200 ${
                selectedProperty?.id === property.id ? 'scale-125 z-20' : 'hover:scale-110 z-10'
              }`}
              style={{
                left: `${20 + x * 0.6}%`,
                top: `${20 + y * 0.6}%`
              }}
              onClick={() => onPropertySelect(property)}
            >
              <div className={`relative ${
                selectedProperty?.id === property.id 
                  ? 'animate-bounce' 
                  : ''
              }`}>
                <div className={`text-2xl ${
                  selectedProperty?.id === property.id 
                    ? 'filter drop-shadow-lg' 
                    : ''
                }`}>
                  {getPropertyIcon(property.type)}
                </div>
                
                {/* Price Label */}
                <div className={`absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded shadow text-xs font-semibold whitespace-nowrap ${
                  selectedProperty?.id === property.id ? 'bg-green-100 text-green-800' : 'text-gray-700'
                }`}>
                  Le {property.price.toLocaleString()}
                </div>
              </div>
            </div>
          );
        })}

        {/* District Labels */}
        {freetownDistricts.map((district, index) => (
          <div
            key={district.name}
            className="absolute text-xs font-semibold text-gray-600 pointer-events-none"
            style={{
              left: `${15 + (index % 3) * 30}%`,
              top: `${25 + Math.floor(index / 3) * 25}%`
            }}
          >
            {district.name}
          </div>
        ))}
      </div>

      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3 text-xs">
        <div className="font-semibold mb-2">Property Types</div>
        <div className="grid grid-cols-2 gap-1">
          <div className="flex items-center gap-1">
            <span>🏢</span> Apartment
          </div>
          <div className="flex items-center gap-1">
            <span>🏠</span> House
          </div>
          <div className="flex items-center gap-1">
            <span>🏡</span> Villa
          </div>
          <div className="flex items-center gap-1">
            <span>🏞️</span> Land
          </div>
        </div>
      </div>

      {/* Current Location Info */}
      <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-lg p-2 text-xs">
        <div className="flex items-center gap-1">
          <Navigation className="h-3 w-3" />
          Zoom: {zoomLevel}x
        </div>
      </div>
    </div>
  );
};

export default MapView;