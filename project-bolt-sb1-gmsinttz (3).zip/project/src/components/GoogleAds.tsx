import React, { useEffect, useRef } from 'react';

interface GoogleAdsProps {
  adSlot: string;
  adFormat?: 'auto' | 'rectangle' | 'vertical' | 'horizontal';
  adLayout?: string;
  className?: string;
  style?: React.CSSProperties;
}

const GoogleAds: React.FC<GoogleAdsProps> = ({
  adSlot,
  adFormat = 'auto',
  adLayout,
  className = '',
  style = {}
}) => {
  const adRef = useRef<HTMLElement>(null);
  const isAdPushed = useRef(false);

  useEffect(() => {
    // Skip if ad already pushed for this instance
    if (isAdPushed.current) return;

    try {
      // Ensure adsbygoogle is available and element exists
      if (window.adsbygoogle && adRef.current) {
        // Check if the element already has an ad
        const insElement = adRef.current.querySelector('.adsbygoogle');
        if (insElement && !insElement.getAttribute('data-adsbygoogle-status')) {
          // Push ad to AdSense
          (window.adsbygoogle = window.adsbygoogle || []).push({});
          isAdPushed.current = true;
        }
      }
    } catch (error) {
      console.error('Google Ads error:', error);
    }
  }, [adSlot]); // Only re-run if adSlot changes

  // Reset the pushed state when component unmounts
  useEffect(() => {
    return () => {
      isAdPushed.current = false;
    };
  }, []);

  // Don't render if container would have zero width
  const containerStyle = {
    minWidth: '300px',
    minHeight: '50px',
    ...style
  };

  return (
    <div ref={adRef} className={`google-ads-container ${className}`} style={containerStyle}>
      <ins
        className="adsbygoogle"
        style={{ display: 'block', ...style }}
        data-ad-client="ca-pub-YOUR_PUBLISHER_ID"
        data-ad-slot={adSlot}
        data-ad-format={adFormat}
        {...(adLayout && { 'data-ad-layout': adLayout })}
      />
    </div>
  );
};

// Banner Ad Component
export const BannerAd: React.FC<{ className?: string }> = ({ className = '' }) => (
  <GoogleAds
    adSlot="1234567890"
    adFormat="horizontal"
    className={`banner-ad ${className}`}
    style={{ width: '100%', height: '90px', minWidth: '320px' }}
  />
);

// Rectangle Ad Component
export const RectangleAd: React.FC<{ className?: string }> = ({ className = '' }) => (
  <GoogleAds
    adSlot="1234567891"
    adFormat="rectangle"
    className={`rectangle-ad ${className}`}
    style={{ width: '300px', height: '250px' }}
  />
);

// Responsive Ad Component
export const ResponsiveAd: React.FC<{ className?: string }> = ({ className = '' }) => (
  <GoogleAds
    adSlot="1234567892"
    adFormat="auto"
    className={`responsive-ad ${className}`}
    style={{ display: 'block', minWidth: '300px', minHeight: '100px' }}
  />
);

// In-feed Ad Component
export const InFeedAd: React.FC<{ className?: string }> = ({ className = '' }) => (
  <GoogleAds
    adSlot="1234567893"
    adFormat="auto"
    adLayout="in-article"
    className={`in-feed-ad ${className}`}
    style={{ display: 'block', textAlign: 'center', minWidth: '300px', minHeight: '100px' }}
  />
);

export default GoogleAds;