import React, { useState, useEffect } from 'react';
import { Heart } from 'lucide-react';
import { favoritesService } from '../services/favoritesService';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';

interface Property {
  id: string;
  title: string;
  price: number;
  currency: string;
  district: string;
  propertyType: string;
  bedrooms: number;
  bathrooms: number;
  squareMeters: number;
  image: string;
  listingType: 'rent' | 'sale';
  dateAdded?: string;
}

interface FavoriteButtonProps {
  property: Property;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

const FavoriteButton: React.FC<FavoriteButtonProps> = ({ 
  property, 
  size = 'md', 
  showText = false,
  className = '' 
}) => {
  const { user } = useAuth();
  const [isFavorite, setIsFavorite] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const sizeClasses = {
    sm: 'w-6 h-6 p-1',
    md: 'w-8 h-8 p-1.5',
    lg: 'w-10 h-10 p-2'
  };

  const iconSizes = {
    sm: 'h-4 w-4',
    md: 'h-5 w-5',
    lg: 'h-6 w-6'
  };

  // Check if property is in favorites on mount and when user changes
  useEffect(() => {
    if (user) {
      const favoriteStatus = favoritesService.isFavorite(user.id, property.id);
      setIsFavorite(favoriteStatus);
    } else {
      setIsFavorite(false);
    }
  }, [user, property.id]);

  // Listen for favorites updates
  useEffect(() => {
    const handleFavoritesUpdate = (event: CustomEvent) => {
      const { userId, action, propertyId } = event.detail;
      
      if (user && userId === user.id && propertyId === property.id) {
        if (action === 'add') {
          setIsFavorite(true);
        } else if (action === 'remove') {
          setIsFavorite(false);
        }
      }
    };

    window.addEventListener('favoritesUpdated', handleFavoritesUpdate as EventListener);
    
    return () => {
      window.removeEventListener('favoritesUpdated', handleFavoritesUpdate as EventListener);
    };
  }, [user, property.id]);

  const handleToggleFavorite = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!user) {
      toast.error('Please log in to save favorites');
      return;
    }

    setIsLoading(true);

    try {
      if (isFavorite) {
        const success = favoritesService.removeFromFavorites(user.id, property.id);
        if (success) {
          setIsFavorite(false);
          toast.success('Removed from favorites');
        } else {
          toast.error('Failed to remove from favorites');
        }
      } else {
        const success = favoritesService.addToFavorites(user.id, {
          ...property,
          dateAdded: property.dateAdded || new Date().toISOString()
        });
        if (success) {
          setIsFavorite(true);
          toast.success('Added to favorites');
        } else {
          toast.error('Already in favorites');
        }
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
      toast.error('Something went wrong');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      onClick={handleToggleFavorite}
      disabled={isLoading}
      className={`
        ${sizeClasses[size]}
        ${isFavorite 
          ? 'bg-red-500 text-white hover:bg-red-600' 
          : 'bg-white bg-opacity-80 text-gray-600 hover:bg-opacity-100 hover:text-red-500'
        }
        rounded-full transition-all duration-200 transform hover:scale-110
        disabled:opacity-50 disabled:cursor-not-allowed
        flex items-center justify-center
        ${showText ? 'px-3 py-2 space-x-2' : ''}
        ${className}
      `}
      title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
    >
      {isLoading ? (
        <div className={`animate-spin rounded-full border-2 border-current border-t-transparent ${iconSizes[size]}`} />
      ) : (
        <Heart 
          className={`${iconSizes[size]} ${isFavorite ? 'fill-current' : ''}`} 
        />
      )}
      {showText && (
        <span className="text-sm font-medium">
          {isFavorite ? 'Saved' : 'Save'}
        </span>
      )}
    </button>
  );
};

export default FavoriteButton;