import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Search, User, Heart, Bell } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

import { useNavigate } from 'react-router-dom';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const handleLogout = () => {
    logout().then(() => {
      navigate('/');
    });
    closeMenu();
  };

  return (
    <header className="bg-white shadow-lg border-b-4 border-green-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3" onClick={closeMenu}>
            <img 
              src="/WhatsApp Image 2025-07-20 at 15.40.21_5a21399f.jpg"
              alt="MiOse Logo"
              className="w-12 h-12 object-contain rounded-lg"
            />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">MiOse</h1>
              <p className="text-xs text-gray-600">Sierra Leone Real Estate</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-green-600 font-medium transition-colors duration-200">
              Home
            </Link>
            <Link to="/properties" className="text-gray-700 hover:text-green-600 font-medium transition-colors duration-200">
              Properties
            </Link>
            <Link to="/about" className="text-gray-700 hover:text-green-600 font-medium transition-colors duration-200">
              About
            </Link>
          </nav>

          {/* User Actions */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <>
                <button className="p-2 text-gray-600 hover:text-green-600 transition-colors duration-200 rounded-lg hover:bg-gray-100">
                  <Heart className="h-6 w-6" />
                </button>
                <button className="p-2 text-gray-600 hover:text-green-600 transition-colors duration-200 rounded-lg hover:bg-gray-100">
                  <Bell className="h-6 w-6" />
                </button>
                <Link to="/dashboard" className="p-2 text-gray-600 hover:text-green-600 transition-colors duration-200 rounded-lg hover:bg-gray-100">
                  <User className="h-6 w-6" />
                </Link>
                <button 
                  onClick={handleLogout}
                  className="text-gray-700 hover:text-red-600 font-medium transition-colors duration-200 px-4 py-2 rounded-lg hover:bg-gray-100"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/auth"
                  className="text-gray-700 hover:text-green-600 font-medium transition-colors duration-200 px-4 py-2 rounded-lg hover:bg-gray-100"
                >
                  Login
                </Link>
                <Link 
                  to="/auth"
                  className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium transform hover:scale-105"
                >
                  Sign Up
                </Link>
              </>
            )}
            <Link 
              to={user ? "/add-property" : "/auth"}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium transform hover:scale-105"
            >
              List Property
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-gray-600 hover:text-green-600 transition-colors"
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200 py-4 absolute left-0 right-0 top-20 z-50 shadow-lg">
            <nav className="flex flex-col space-y-4">
              <Link 
                to="/" 
                className="text-gray-700 hover:text-green-600 font-medium transition-colors duration-200 px-4 py-2 hover:bg-gray-50"
                onClick={closeMenu}
              >
                Home
              </Link>
              <Link 
                to="/properties" 
                className="text-gray-700 hover:text-green-600 font-medium transition-colors duration-200 px-4 py-2 hover:bg-gray-50"
                onClick={closeMenu}
              >
                Properties
              </Link>
              <Link 
                to="/about" 
                className="text-gray-700 hover:text-green-600 font-medium transition-colors duration-200 px-4 py-2 hover:bg-gray-50"
                onClick={closeMenu}
              >
                About
              </Link>
              <div className="border-t border-gray-200 pt-4 px-4 space-y-3">
                {user ? (
                  <>
                    <Link 
                      to="/dashboard" 
                      className="block text-gray-700 hover:text-green-600 font-medium transition-colors duration-200 py-2 hover:bg-gray-50"
                      onClick={closeMenu}
                    >
                      Dashboard
                    </Link>
                    <button 
                      onClick={handleLogout}
                      className="block w-full text-left text-gray-700 hover:text-red-600 font-medium transition-colors duration-200 py-2 hover:bg-gray-50"
                    >
                      Logout
                    </button>
                  </>
                ) : (
                  <>
                    <Link 
                      to="/auth"
                      className="block w-full text-left text-gray-700 hover:text-green-600 font-medium transition-colors duration-200 py-2 hover:bg-gray-50"
                      onClick={closeMenu}
                    >
                      Login
                    </Link>
                    <Link 
                      to="/auth"
                      className="block w-full bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium"
                      onClick={closeMenu}
                    >
                      Sign Up
                    </Link>
                  </>
                )}
                <Link 
                  to={user ? "/add-property" : "/auth"}
                  className="block w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium text-center"
                  onClick={closeMenu}
                >
                  List Property
                </Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;