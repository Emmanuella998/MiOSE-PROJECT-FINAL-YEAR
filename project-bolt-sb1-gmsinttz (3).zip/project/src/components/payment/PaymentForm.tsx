import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { CreditCard, Smartphone, DollarSign } from 'lucide-react';
import { PaymentType, PaymentIntent } from '../../types';
import { paymentService } from '../../services/paymentService';
import { PAYMENT_METHODS } from '../../config/constants';
import Button from '../ui/Button';
import Input from '../ui/Input';
import toast from 'react-hot-toast';

interface PaymentFormProps {
  amount: number;
  currency: string;
  onSuccess: (payment: PaymentIntent) => void;
  onError: (error: string) => void;
  propertyId?: string;
  subscriptionId?: string;
}

interface PaymentFormData {
  paymentMethod: PaymentType;
  // Stripe fields
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  cardholderName: string;
  // Orange Money fields
  phoneNumber: string;
  // Afrimoney fields
  accountNumber: string;
}

const PaymentForm: React.FC<PaymentFormProps> = ({
  amount,
  currency,
  onSuccess,
  onError,
  propertyId,
  subscriptionId
}) => {
  const [selectedMethod, setSelectedMethod] = useState<PaymentType>('stripe');
  const [isProcessing, setIsProcessing] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    reset
  } = useForm<PaymentFormData>({
    defaultValues: {
      paymentMethod: 'stripe'
    }
  });

  const watchedMethod = watch('paymentMethod');

  const onSubmit = async (data: PaymentFormData) => {
    setIsProcessing(true);

    try {
      // Validate payment data
      const validation = paymentService.validatePaymentData(selectedMethod, data);
      if (!validation.isValid) {
        onError(validation.errors.join(', '));
        return;
      }

      let paymentResult: PaymentIntent;

      switch (selectedMethod) {
        case 'stripe':
          // For demo purposes, we'll simulate Stripe payment
          // In production, you'd integrate with Stripe Elements
          paymentResult = await paymentService.processStripePayment({
            amount,
            currency,
            paymentMethodId: 'pm_demo_' + Date.now(),
            propertyId,
            subscriptionId
          });
          break;

        case 'orange_money':
          paymentResult = await paymentService.processOrangeMoneyPayment({
            amount,
            phoneNumber: data.phoneNumber,
            propertyId,
            subscriptionId
          });
          break;

        case 'afrimoney':
          paymentResult = await paymentService.processAfrimoneyPayment({
            amount,
            accountNumber: data.accountNumber,
            propertyId,
            subscriptionId
          });
          break;

        default:
          throw new Error('Invalid payment method');
      }

      toast.success('Payment processed successfully!');
      onSuccess(paymentResult);
      reset();
    } catch (error: any) {
      const errorMessage = error.message || 'Payment processing failed';
      toast.error(errorMessage);
      onError(errorMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  const formatAmount = (amount: number, currency: string) => {
    return paymentService.formatAmount(amount, currency);
  };

  const calculateFees = (amount: number, method: PaymentType) => {
    return paymentService.calculateFees(amount, method);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* Payment Method Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-4">
          Select Payment Method
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {PAYMENT_METHODS.filter(method => method.isActive).map((method) => (
            <motion.div
              key={method.id}
              className={`
                p-4 border-2 rounded-xl cursor-pointer transition-all duration-200
                ${selectedMethod === method.type
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 hover:border-gray-300'
                }
              `}
              onClick={() => setSelectedMethod(method.type)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="text-center">
                <div className="text-3xl mb-2">{method.icon}</div>
                <h4 className="font-semibold text-gray-900 mb-1">{method.name}</h4>
                <p className="text-sm text-gray-600">{method.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Payment Details */}
      <div className="bg-gray-50 rounded-xl p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Payment Details</h4>

        {selectedMethod === 'stripe' && (
          <div className="space-y-4">
            <Input
              label="Card Number"
              placeholder="1234 5678 9012 3456"
              leftIcon={<CreditCard className="h-5 w-5" />}
              {...register('cardNumber', {
                required: 'Card number is required',
                pattern: {
                  value: /^\d{13,19}$/,
                  message: 'Invalid card number'
                }
              })}
              error={errors.cardNumber?.message}
            />

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Expiry Date"
                placeholder="MM/YY"
                {...register('expiryDate', {
                  required: 'Expiry date is required',
                  pattern: {
                    value: /^\d{2}\/\d{2}$/,
                    message: 'Invalid format (MM/YY)'
                  }
                })}
                error={errors.expiryDate?.message}
              />

              <Input
                label="CVV"
                placeholder="123"
                {...register('cvv', {
                  required: 'CVV is required',
                  pattern: {
                    value: /^\d{3,4}$/,
                    message: 'Invalid CVV'
                  }
                })}
                error={errors.cvv?.message}
              />
            </div>

            <Input
              label="Cardholder Name"
              placeholder="John Doe"
              {...register('cardholderName', {
                required: 'Cardholder name is required',
                minLength: {
                  value: 2,
                  message: 'Name must be at least 2 characters'
                }
              })}
              error={errors.cardholderName?.message}
            />
          </div>
        )}

        {selectedMethod === 'orange_money' && (
          <Input
            label="Orange Money Phone Number"
            placeholder="+232 76 123 456"
            leftIcon={<Smartphone className="h-5 w-5" />}
            {...register('phoneNumber', {
              required: 'Phone number is required',
              pattern: {
                value: /^\+232\d{8}$/,
                message: 'Invalid Orange Money number (+232XXXXXXXX)'
              }
            })}
            error={errors.phoneNumber?.message}
          />
        )}

        {selectedMethod === 'afrimoney' && (
          <Input
            label="Afrimoney Account Number"
            placeholder="Enter your account number"
            leftIcon={<DollarSign className="h-5 w-5" />}
            {...register('accountNumber', {
              required: 'Account number is required',
              minLength: {
                value: 5,
                message: 'Account number must be at least 5 characters'
              }
            })}
            error={errors.accountNumber?.message}
          />
        )}
      </div>

      {/* Payment Summary */}
      <div className="bg-white border border-gray-200 rounded-xl p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Payment Summary</h4>
        
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600">Amount</span>
            <span className="font-semibold">{formatAmount(amount, currency)}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Processing Fee</span>
            <span className="font-semibold">
              {formatAmount(calculateFees(amount, selectedMethod), currency)}
            </span>
          </div>
          
          <div className="border-t pt-3">
            <div className="flex justify-between">
              <span className="text-lg font-semibold text-gray-900">Total</span>
              <span className="text-lg font-bold text-green-600">
                {formatAmount(amount + calculateFees(amount, selectedMethod), currency)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Submit Button */}
      <Button
        type="submit"
        variant="primary"
        size="lg"
        fullWidth
        isLoading={isProcessing}
        leftIcon={<CreditCard className="h-5 w-5" />}
      >
        {isProcessing ? 'Processing Payment...' : `Pay ${formatAmount(amount + calculateFees(amount, selectedMethod), currency)}`}
      </Button>

      {/* Security Notice */}
      <div className="text-center text-sm text-gray-500">
        <p>🔒 Your payment information is secure and encrypted</p>
      </div>
    </form>
  );
};

export default PaymentForm;