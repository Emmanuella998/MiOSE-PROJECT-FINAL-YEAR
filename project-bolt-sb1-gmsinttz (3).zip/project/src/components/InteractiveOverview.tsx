import React, { useState } from 'react';
import { 
  Home, TrendingUp, Users, MapPin, DollarSign, Eye, Heart, 
  Calendar, BarChart3, PieChart, Activity, ArrowRight, Star,
  Building, TreePine, Waves, Mountain
} from 'lucide-react';

interface OverviewCard {
  id: string;
  title: string;
  value: string | number;
  change: number;
  icon: React.ComponentType<any>;
  color: string;
  description: string;
  clickable: boolean;
  category: 'market' | 'properties' | 'activity' | 'location';
}

interface InteractiveOverviewProps {
  onCardClick: (cardId: string, data: any) => void;
}

const InteractiveOverview: React.FC<InteractiveOverviewProps> = ({ onCardClick }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  const overviewCards: OverviewCard[] = [
    {
      id: 'total-properties',
      title: 'Total Properties',
      value: '2,547',
      change: 12.5,
      icon: Home,
      color: 'blue',
      description: 'Active listings across Freetown',
      clickable: true,
      category: 'properties'
    },
    {
      id: 'market-value',
      title: 'Market Value',
      value: 'Le 2.8M',
      change: 5.2,
      icon: DollarSign,
      color: 'green',
      description: 'Average property price',
      clickable: true,
      category: 'market'
    },
    {
      id: 'monthly-views',
      title: 'Monthly Views',
      value: '45,230',
      change: 18.7,
      icon: Eye,
      color: 'purple',
      description: 'Property page visits this month',
      clickable: true,
      category: 'activity'
    },
    {
      id: 'active-users',
      title: 'Active Users',
      value: '8,945',
      change: 23.1,
      icon: Users,
      color: 'orange',
      description: 'Registered users this month',
      clickable: true,
      category: 'activity'
    },
    {
      id: 'hill-station',
      title: 'Hill Station',
      value: '342',
      change: 8.1,
      icon: Mountain,
      color: 'emerald',
      description: 'Premium properties available',
      clickable: true,
      category: 'location'
    },
    {
      id: 'west-end',
      title: 'West End',
      value: '267',
      change: 6.7,
      icon: Waves,
      color: 'cyan',
      description: 'Coastal properties',
      clickable: true,
      category: 'location'
    },
    {
      id: 'central-freetown',
      title: 'Central Freetown',
      value: '298',
      change: 3.4,
      icon: Building,
      color: 'indigo',
      description: 'Urban commercial & residential',
      clickable: true,
      category: 'location'
    },
    {
      id: 'favorites',
      title: 'Saved Properties',
      value: '1,234',
      change: 15.3,
      icon: Heart,
      color: 'red',
      description: 'Properties saved by users',
      clickable: true,
      category: 'activity'
    },
    {
      id: 'market-trend',
      title: 'Market Growth',
      value: '+5.2%',
      change: 2.1,
      icon: TrendingUp,
      color: 'green',
      description: 'Quarterly market growth',
      clickable: true,
      category: 'market'
    }
  ];

  const categories = [
    { id: 'all', name: 'All', icon: BarChart3 },
    { id: 'market', name: 'Market', icon: TrendingUp },
    { id: 'properties', name: 'Properties', icon: Home },
    { id: 'activity', name: 'Activity', icon: Activity },
    { id: 'location', name: 'Locations', icon: MapPin }
  ];

  const getColorClasses = (color: string, isHovered: boolean = false) => {
    const colors = {
      blue: {
        bg: isHovered ? 'bg-blue-600' : 'bg-blue-100',
        text: isHovered ? 'text-white' : 'text-blue-600',
        icon: isHovered ? 'text-white' : 'text-blue-600',
        border: 'border-blue-200'
      },
      green: {
        bg: isHovered ? 'bg-green-600' : 'bg-green-100',
        text: isHovered ? 'text-white' : 'text-green-600',
        icon: isHovered ? 'text-white' : 'text-green-600',
        border: 'border-green-200'
      },
      purple: {
        bg: isHovered ? 'bg-purple-600' : 'bg-purple-100',
        text: isHovered ? 'text-white' : 'text-purple-600',
        icon: isHovered ? 'text-white' : 'text-purple-600',
        border: 'border-purple-200'
      },
      orange: {
        bg: isHovered ? 'bg-orange-600' : 'bg-orange-100',
        text: isHovered ? 'text-white' : 'text-orange-600',
        icon: isHovered ? 'text-white' : 'text-orange-600',
        border: 'border-orange-200'
      },
      emerald: {
        bg: isHovered ? 'bg-emerald-600' : 'bg-emerald-100',
        text: isHovered ? 'text-white' : 'text-emerald-600',
        icon: isHovered ? 'text-white' : 'text-emerald-600',
        border: 'border-emerald-200'
      },
      cyan: {
        bg: isHovered ? 'bg-cyan-600' : 'bg-cyan-100',
        text: isHovered ? 'text-white' : 'text-cyan-600',
        icon: isHovered ? 'text-white' : 'text-cyan-600',
        border: 'border-cyan-200'
      },
      indigo: {
        bg: isHovered ? 'bg-indigo-600' : 'bg-indigo-100',
        text: isHovered ? 'text-white' : 'text-indigo-600',
        icon: isHovered ? 'text-white' : 'text-indigo-600',
        border: 'border-indigo-200'
      },
      red: {
        bg: isHovered ? 'bg-red-600' : 'bg-red-100',
        text: isHovered ? 'text-white' : 'text-red-600',
        icon: isHovered ? 'text-white' : 'text-red-600',
        border: 'border-red-200'
      }
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const filteredCards = selectedCategory === 'all' 
    ? overviewCards 
    : overviewCards.filter(card => card.category === selectedCategory);

  const handleCardClick = (card: OverviewCard) => {
    if (!card.clickable) return;
    
    // Generate relevant data based on card type
    const cardData = {
      id: card.id,
      title: card.title,
      value: card.value,
      category: card.category,
      description: card.description,
      trend: card.change,
      changeDirection: card.change > 0 ? 'up' : 'down',
      // Add specific data based on card type
      ...(card.category === 'location' && {
        district: card.title,
        coordinates: getDistrictCoordinates(card.title),
        properties: getDistrictProperties(card.title)
      }),
      ...(card.category === 'market' && {
        trend: card.change > 0 ? 'increasing' : 'decreasing',
        percentage: card.change,
        analysis: getMarketAnalysis(card.id)
      }),
      ...(card.category === 'properties' && {
        totalCount: card.value,
        breakdown: getPropertyBreakdown(),
        recentListings: getRecentListings()
      }),
      ...(card.category === 'activity' && {
        activityType: card.id,
        recentActivity: getRecentActivity(card.id)
      })
    };
    
    onCardClick(card.id, cardData);
  };

  const getDistrictCoordinates = (district: string) => {
    const coordinates = {
      'Hill Station': { lat: 8.4950, lng: -13.2350 },
      'West End': { lat: 8.4800, lng: -13.2400 },
      'Central Freetown': { lat: 8.4840, lng: -13.2299 }
    };
    return coordinates[district as keyof typeof coordinates] || { lat: 8.4840, lng: -13.2299 };
  };

  const getDistrictProperties = (district: string) => {
    return [];
  };

  const getMarketAnalysis = (cardId: string) => {
    return {};
  };

  const getPropertyBreakdown = () => ({
    apartments: 1245,
    houses: 687,
    villas: 324,
    commercial: 198,
    land: 93
  });

  const getRecentListings = () => {
    return [];
  };

  const getRecentActivity = (cardId: string) => {
    return [];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <BarChart3 className="h-6 w-6 mr-2 text-green-600" />
            Freetown Real Estate Overview
          </h2>
          <p className="text-gray-600 mt-1">Click on any card to explore detailed insights</p>
        </div>
        
        {/* Category Filter */}
        <div className="flex bg-gray-100 rounded-lg p-1">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedCategory === category.id
                  ? 'bg-white text-green-700 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <category.icon className="h-4 w-4 mr-2" />
              {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* Overview Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCards.map((card) => {
          const isHovered = hoveredCard === card.id;
          const colorClasses = getColorClasses(card.color, isHovered);
          const IconComponent = card.icon;
          
          return (
            <div
              key={card.id}
              onClick={() => handleCardClick(card)}
              onMouseEnter={() => setHoveredCard(card.id)}
              onMouseLeave={() => setHoveredCard(null)}
              className={`
                relative bg-white rounded-xl shadow-lg p-6 transition-all duration-300 border-2
                ${card.clickable ? 'cursor-pointer hover:shadow-xl hover:scale-105' : 'cursor-default'}
                ${isHovered ? colorClasses.bg : 'bg-white'}
                ${colorClasses.border}
              `}
            >
              {/* Card Header */}
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${colorClasses.bg}`}>
                  <IconComponent className={`h-6 w-6 ${colorClasses.icon}`} />
                </div>
                
                {card.clickable && (
                  <ArrowRight className={`h-5 w-5 transition-transform duration-300 ${
                    isHovered ? 'text-white translate-x-1' : 'text-gray-400'
                  }`} />
                )}
              </div>

              {/* Card Content */}
              <div className="space-y-2">
                <h3 className={`text-sm font-medium ${
                  isHovered ? 'text-white' : 'text-gray-600'
                }`}>
                  {card.title}
                </h3>
                
                <div className={`text-3xl font-bold ${
                  isHovered ? 'text-white' : 'text-gray-900'
                }`}>
                  {card.value}
                </div>
                
                <div className="flex items-center justify-between">
                  <p className={`text-sm ${
                    isHovered ? 'text-white opacity-90' : 'text-gray-600'
                  }`}>
                    {card.description}
                  </p>
                  
                  <div className={`flex items-center text-sm font-medium ${
                    card.change > 0 
                      ? (isHovered ? 'text-white' : 'text-green-600')
                      : (isHovered ? 'text-white' : 'text-red-600')
                  }`}>
                    {card.change > 0 ? (
                      <TrendingUp className="h-4 w-4 mr-1" />
                    ) : (
                      <TrendingUp className="h-4 w-4 mr-1 rotate-180" />
                    )}
                    {Math.abs(card.change)}%
                  </div>
                </div>
              </div>

              {/* Interactive Indicator */}
              {card.clickable && (
                <div className={`absolute top-2 right-2 w-2 h-2 rounded-full transition-colors ${
                  isHovered ? 'bg-white' : colorClasses.bg.replace('bg-', 'bg-').replace('-100', '-400')
                }`} />
              )}
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 border border-green-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Star className="h-5 w-5 mr-2 text-yellow-500" />
          Quick Actions
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => onCardClick('quick-search', { action: 'search' })}
            className="flex items-center p-4 bg-white rounded-lg hover:bg-gray-50 transition-colors text-left"
          >
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
              <Home className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h4 className="font-semibold text-gray-900">Browse Properties</h4>
              <p className="text-sm text-gray-600">Explore available listings</p>
            </div>
          </button>
          
          <button
            onClick={() => onCardClick('market-analysis', { action: 'analyze' })}
            className="flex items-center p-4 bg-white rounded-lg hover:bg-gray-50 transition-colors text-left"
          >
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
              <BarChart3 className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <h4 className="font-semibold text-gray-900">Market Analysis</h4>
              <p className="text-sm text-gray-600">View trends and insights</p>
            </div>
          </button>
          
          <button
            onClick={() => onCardClick('map-view', { action: 'map' })}
            className="flex items-center p-4 bg-white rounded-lg hover:bg-gray-50 transition-colors text-left"
          >
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
              <MapPin className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <h4 className="font-semibold text-gray-900">Map View</h4>
              <p className="text-sm text-gray-600">Explore locations</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default InteractiveOverview;