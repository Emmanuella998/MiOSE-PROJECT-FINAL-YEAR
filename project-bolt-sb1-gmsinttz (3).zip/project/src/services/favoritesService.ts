interface Property {
  id: string;
  title: string;
  price: number;
  currency: string;
  district: string;
  propertyType: string;
  bedrooms: number;
  bathrooms: number;
  squareMeters: number;
  image: string;
  listingType: 'rent' | 'sale';
  dateAdded: string;
  notes?: string;
  featured?: boolean;
}

interface FavoriteProperty extends Property {
  favoriteId: string;
  addedAt: string;
  userNotes: string;
  tags: string[];
}

class FavoritesService {
  private storageKey = 'miose_favorites';
  private featuredKey = 'miose_featured';

  // Get all favorites for current user
  getFavorites(userId: string): FavoriteProperty[] {
    try {
      const favorites = localStorage.getItem(`${this.storageKey}_${userId}`);
      return favorites ? JSON.parse(favorites) : [];
    } catch (error) {
      console.error('Error loading favorites:', error);
      return [];
    }
  }

  // Add property to favorites
  addToFavorites(userId: string, property: Property, notes: string = ''): boolean {
    try {
      const favorites = this.getFavorites(userId);
      
      // Check if already in favorites
      if (favorites.some(fav => fav.id === property.id)) {
        return false; // Already in favorites
      }

      const favoriteProperty: FavoriteProperty = {
        ...property,
        favoriteId: `fav_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        addedAt: new Date().toISOString(),
        userNotes: notes,
        tags: [],
        dateAdded: property.dateAdded || new Date().toISOString()
      };

      favorites.push(favoriteProperty);
      localStorage.setItem(`${this.storageKey}_${userId}`, JSON.stringify(favorites));
      
      // Trigger custom event for UI updates
      window.dispatchEvent(new CustomEvent('favoritesUpdated', { 
        detail: { userId, action: 'add', propertyId: property.id } 
      }));
      
      return true;
    } catch (error) {
      console.error('Error adding to favorites:', error);
      return false;
    }
  }

  // Remove property from favorites
  removeFromFavorites(userId: string, propertyId: string): boolean {
    try {
      const favorites = this.getFavorites(userId);
      const updatedFavorites = favorites.filter(fav => fav.id !== propertyId);
      
      localStorage.setItem(`${this.storageKey}_${userId}`, JSON.stringify(updatedFavorites));
      
      // Trigger custom event for UI updates
      window.dispatchEvent(new CustomEvent('favoritesUpdated', { 
        detail: { userId, action: 'remove', propertyId } 
      }));
      
      return true;
    } catch (error) {
      console.error('Error removing from favorites:', error);
      return false;
    }
  }

  // Check if property is in favorites
  isFavorite(userId: string, propertyId: string): boolean {
    const favorites = this.getFavorites(userId);
    return favorites.some(fav => fav.id === propertyId);
  }

  // Update notes for a favorite property
  updateNotes(userId: string, propertyId: string, notes: string): boolean {
    try {
      const favorites = this.getFavorites(userId);
      const favoriteIndex = favorites.findIndex(fav => fav.id === propertyId);
      
      if (favoriteIndex === -1) return false;
      
      favorites[favoriteIndex].userNotes = notes;
      localStorage.setItem(`${this.storageKey}_${userId}`, JSON.stringify(favorites));
      
      return true;
    } catch (error) {
      console.error('Error updating notes:', error);
      return false;
    }
  }

  // Add tags to favorite property
  addTags(userId: string, propertyId: string, tags: string[]): boolean {
    try {
      const favorites = this.getFavorites(userId);
      const favoriteIndex = favorites.findIndex(fav => fav.id === propertyId);
      
      if (favoriteIndex === -1) return false;
      
      const existingTags = favorites[favoriteIndex].tags || [];
      const newTags = [...new Set([...existingTags, ...tags])]; // Remove duplicates
      favorites[favoriteIndex].tags = newTags;
      
      localStorage.setItem(`${this.storageKey}_${userId}`, JSON.stringify(favorites));
      return true;
    } catch (error) {
      console.error('Error adding tags:', error);
      return false;
    }
  }

  // Get favorites by tags
  getFavoritesByTags(userId: string, tags: string[]): FavoriteProperty[] {
    const favorites = this.getFavorites(userId);
    return favorites.filter(fav => 
      tags.some(tag => fav.tags?.includes(tag))
    );
  }

  // Get featured properties
  getFeaturedProperties(): Property[] {
    try {
      const featured = localStorage.getItem(this.featuredKey);
      return featured ? JSON.parse(featured) : this.getDefaultFeatured();
    } catch (error) {
      console.error('Error loading featured properties:', error);
      return this.getDefaultFeatured();
    }
  }

  // Set featured properties
  setFeaturedProperties(properties: Property[]): boolean {
    try {
      localStorage.setItem(this.featuredKey, JSON.stringify(properties));
      
      // Trigger custom event for UI updates
      window.dispatchEvent(new CustomEvent('featuredUpdated', { 
        detail: { properties } 
      }));
      
      return true;
    } catch (error) {
      console.error('Error setting featured properties:', error);
      return false;
    }
  }

  // Toggle featured status
  toggleFeatured(propertyId: string): boolean {
    try {
      const featured = this.getFeaturedProperties();
      const isCurrentlyFeatured = featured.some(prop => prop.id === propertyId);
      
      if (isCurrentlyFeatured) {
        const updatedFeatured = featured.filter(prop => prop.id !== propertyId);
        return this.setFeaturedProperties(updatedFeatured);
      } else {
        // Add to featured (you'd need the full property object)
        // This would typically come from your main properties data
        return true;
      }
    } catch (error) {
      console.error('Error toggling featured status:', error);
      return false;
    }
  }

  // Get default featured properties
  private getDefaultFeatured(): Property[] {
    return [
      {
        id: '1',
        title: 'Luxury 4BR Villa with Ornate Gates',
        price: 4500000,
        currency: 'SLL',
        district: 'Hill Station',
        propertyType: 'villa',
        bedrooms: 4,
        bathrooms: 3,
        squareMeters: 280,
        image: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg',
        listingType: 'sale',
        dateAdded: '2024-01-15',
        featured: true
      },
      {
        id: '2',
        title: 'Modern 3BR House with Balcony',
        price: 3200000,
        currency: 'SLL',
        district: 'Murray Town',
        propertyType: 'house',
        bedrooms: 3,
        bathrooms: 2,
        squareMeters: 180,
        image: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_49a9c835.jpg',
        listingType: 'rent',
        dateAdded: '2024-01-14',
        featured: true
      },
      {
        id: '3',
        title: 'Colonial Style Villa with Columns',
        price: 5200000,
        currency: 'SLL',
        district: 'West End',
        propertyType: 'villa',
        bedrooms: 5,
        bathrooms: 4,
        squareMeters: 320,
        image: '/properties/WhatsApp Image 2025-07-20 at 15.42.59_6aa66276.jpg',
        listingType: 'sale',
        dateAdded: '2024-01-13',
        featured: true
      }
    ];
  }

  // Export favorites data
  exportFavorites(userId: string): string {
    const favorites = this.getFavorites(userId);
    return JSON.stringify(favorites, null, 2);
  }

  // Import favorites data
  importFavorites(userId: string, data: string): boolean {
    try {
      const favorites = JSON.parse(data);
      localStorage.setItem(`${this.storageKey}_${userId}`, JSON.stringify(favorites));
      
      window.dispatchEvent(new CustomEvent('favoritesUpdated', { 
        detail: { userId, action: 'import' } 
      }));
      
      return true;
    } catch (error) {
      console.error('Error importing favorites:', error);
      return false;
    }
  }

  // Clear all favorites
  clearFavorites(userId: string): boolean {
    try {
      localStorage.removeItem(`${this.storageKey}_${userId}`);
      
      window.dispatchEvent(new CustomEvent('favoritesUpdated', { 
        detail: { userId, action: 'clear' } 
      }));
      
      return true;
    } catch (error) {
      console.error('Error clearing favorites:', error);
      return false;
    }
  }

  // Get favorites statistics
  getFavoritesStats(userId: string) {
    const favorites = this.getFavorites(userId);
    
    return {
      total: favorites.length,
      byType: favorites.reduce((acc, fav) => {
        acc[fav.propertyType] = (acc[fav.propertyType] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      byDistrict: favorites.reduce((acc, fav) => {
        acc[fav.district] = (acc[fav.district] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      byListingType: favorites.reduce((acc, fav) => {
        acc[fav.listingType] = (acc[fav.listingType] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      averagePrice: favorites.length > 0 
        ? favorites.reduce((sum, fav) => sum + fav.price, 0) / favorites.length 
        : 0,
      priceRange: favorites.length > 0 
        ? {
            min: Math.min(...favorites.map(fav => fav.price)),
            max: Math.max(...favorites.map(fav => fav.price))
          }
        : { min: 0, max: 0 }
    };
  }
}

export const favoritesService = new FavoritesService();
export type { FavoriteProperty, Property };