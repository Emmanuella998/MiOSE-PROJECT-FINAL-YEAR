import { loadStripe, Stripe } from '@stripe/stripe-js';
import { STRIPE_CONFIG } from '../config/constants';
import { PaymentIntent, PaymentType, PaymentStatus } from '../types';
import { apiClient } from './apiClient';

class PaymentService {
  private stripe: Stripe | null = null;
  private isInitialized = false;

  /**
   * Initialize Stripe
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      this.stripe = await loadStripe(STRIPE_CONFIG.publishableKey);
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize Stripe:', error);
      throw new Error('Payment system initialization failed');
    }
  }

  /**
   * Process Stripe payment
   */
  async processStripePayment(params: {
    amount: number;
    currency: string;
    paymentMethodId: string;
    propertyId?: string;
    subscriptionId?: string;
  }): Promise<PaymentIntent> {
    await this.initialize();

    if (!this.stripe) {
      throw new Error('Stripe not initialized');
    }

    try {
      // Create payment intent on server
      const response = await apiClient.post('/payments/stripe/create-intent', {
        amount: params.amount,
        currency: params.currency,
        payment_method: params.paymentMethodId,
        property_id: params.propertyId,
        subscription_id: params.subscriptionId
      });

      if (!response.data.success) {
        throw new Error(response.data.error || 'Payment creation failed');
      }

      const { client_secret, payment_intent_id } = response.data.data;

      // Confirm payment with Stripe
      const result = await this.stripe.confirmCardPayment(client_secret);

      if (result.error) {
        throw new Error(result.error.message || 'Payment confirmation failed');
      }

      // Return payment intent
      return {
        id: payment_intent_id,
        amount: params.amount,
        currency: params.currency as any,
        status: result.paymentIntent.status as PaymentStatus,
        paymentMethod: 'stripe',
        propertyId: params.propertyId,
        subscriptionId: params.subscriptionId,
        createdAt: new Date().toISOString()
      };
    } catch (error) {
      console.error('Stripe payment error:', error);
      throw error;
    }
  }

  /**
   * Process Orange Money payment
   */
  async processOrangeMoneyPayment(params: {
    amount: number;
    phoneNumber: string;
    propertyId?: string;
    subscriptionId?: string;
  }): Promise<PaymentIntent> {
    try {
      const response = await apiClient.post('/payments/orange-money', {
        amount: params.amount,
        phone_number: params.phoneNumber,
        property_id: params.propertyId,
        subscription_id: params.subscriptionId
      });

      if (!response.data.success) {
        throw new Error(response.data.error || 'Orange Money payment failed');
      }

      return response.data.data;
    } catch (error) {
      console.error('Orange Money payment error:', error);
      throw error;
    }
  }

  /**
   * Process Afrimoney payment
   */
  async processAfrimoneyPayment(params: {
    amount: number;
    accountNumber: string;
    propertyId?: string;
    subscriptionId?: string;
  }): Promise<PaymentIntent> {
    try {
      const response = await apiClient.post('/payments/afrimoney', {
        amount: params.amount,
        account_number: params.accountNumber,
        property_id: params.propertyId,
        subscription_id: params.subscriptionId
      });

      if (!response.data.success) {
        throw new Error(response.data.error || 'Afrimoney payment failed');
      }

      return response.data.data;
    } catch (error) {
      console.error('Afrimoney payment error:', error);
      throw error;
    }
  }

  /**
   * Get payment status
   */
  async getPaymentStatus(paymentId: string): Promise<PaymentIntent> {
    try {
      const response = await apiClient.get(`/payments/status/${paymentId}`);

      if (!response.data.success) {
        throw new Error(response.data.error || 'Failed to get payment status');
      }

      return response.data.data;
    } catch (error) {
      console.error('Get payment status error:', error);
      throw error;
    }
  }

  /**
   * Create Stripe payment method
   */
  async createPaymentMethod(cardElement: any): Promise<string> {
    await this.initialize();

    if (!this.stripe) {
      throw new Error('Stripe not initialized');
    }

    try {
      const result = await this.stripe.createPaymentMethod({
        type: 'card',
        card: cardElement
      });

      if (result.error) {
        throw new Error(result.error.message || 'Failed to create payment method');
      }

      return result.paymentMethod.id;
    } catch (error) {
      console.error('Create payment method error:', error);
      throw error;
    }
  }

  /**
   * Validate payment data
   */
  validatePaymentData(type: PaymentType, data: any): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    switch (type) {
      case 'stripe':
        if (!data.cardNumber || data.cardNumber.length < 13) {
          errors.push('Invalid card number');
        }
        if (!data.expiryDate || !/^\d{2}\/\d{2}$/.test(data.expiryDate)) {
          errors.push('Invalid expiry date (MM/YY)');
        }
        if (!data.cvv || data.cvv.length < 3) {
          errors.push('Invalid CVV');
        }
        if (!data.cardholderName || data.cardholderName.trim().length < 2) {
          errors.push('Invalid cardholder name');
        }
        break;

      case 'orange_money':
        if (!data.phoneNumber || !/^\+232\d{8}$/.test(data.phoneNumber)) {
          errors.push('Invalid Orange Money phone number (+232XXXXXXXX)');
        }
        break;

      case 'afrimoney':
        if (!data.accountNumber || data.accountNumber.length < 5) {
          errors.push('Invalid Afrimoney account number');
        }
        break;

      default:
        errors.push('Invalid payment method');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Format amount for display
   */
  formatAmount(amount: number, currency: string): string {
    const formatter = new Intl.NumberFormat('en-SL', {
      style: 'currency',
      currency: currency === 'SLL' ? 'SLL' : 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    });

    return formatter.format(amount);
  }

  /**
   * Calculate fees
   */
  calculateFees(amount: number, paymentType: PaymentType): number {
    const feeRates = {
      stripe: 0.029, // 2.9%
      orange_money: 0.02, // 2%
      afrimoney: 0.015 // 1.5%
    };

    return Math.round(amount * feeRates[paymentType]);
  }
}

export const paymentService = new PaymentService();