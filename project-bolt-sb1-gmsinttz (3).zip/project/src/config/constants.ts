// Application Constants
export const APP_CONFIG = {
  name: 'MiOse',
  tagline: 'Find Your House',
  description: 'Sierra Leone\'s Premier Real Estate Platform',
  version: '1.0.0',
  author: 'MiOse Team',
  website: 'https://miose.sl',
  supportEmail: 'support@miose.sl',
  phone: '+232 76 123 456',
  address: '15 Siaka Stevens Street, Central Freetown, Sierra Leone'
} as const;

export const API_CONFIG = {
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000/api/v1',
  timeout: 30000,
  retryAttempts: 3,
  retryDelay: 1000
} as const;

export const STRIPE_CONFIG = {
  publishableKey: import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || '',
  currency: 'usd',
  country: 'SL'
} as const;

export const DISTRICTS = [
  'Central Freetown',
  'East End',
  'West End',
  'Hill Station',
  'Murray Town',
  'Kissy',
  'Wellington',
  'Lumley'
] as const;

export const PROPERTY_TYPES = [
  { value: 'apartment', label: 'Apartment' },
  { value: 'house', label: 'House' },
  { value: 'villa', label: 'Villa' },
  { value: 'land', label: 'Land' },
  { value: 'commercial', label: 'Commercial' }
] as const;

export const AMENITIES = [
  'Air Conditioning',
  'Furnished',
  'Parking Space',
  'Security System',
  'Generator Backup',
  'Water Tank',
  'High-Speed Internet',
  'Kitchen Appliances',
  'Balcony View',
  'Swimming Pool',
  'Garden',
  'Garage',
  'Elevator',
  'Gym',
  'Laundry Room',
  'Storage Room'
] as const;

export const SUBSCRIPTION_PLANS = [
  {
    id: 'free',
    name: 'Free Plan',
    price: 0,
    currency: 'SLL',
    interval: 'month',
    maxProperties: 2,
    maxImages: 5,
    features: [
      'List up to 2 properties',
      'Basic property photos (up to 5)',
      'Standard listing visibility',
      'Email support',
      'Ads supported',
      'Mobile app access'
    ],
    isPopular: false
  },
  {
    id: 'basic',
    name: 'Basic Listing',
    price: 50,
    currency: 'SLL',
    interval: 'month',
    maxProperties: 5,
    maxImages: 10,
    features: [
      'List up to 5 properties',
      'Basic property photos (up to 10)',
      'Standard listing visibility',
      'Email support',
      'Basic analytics',
      'Mobile app access'
    ],
    isPopular: false
  },
  {
    id: 'pro',
    name: 'Pro Listing',
    price: 150,
    currency: 'SLL',
    interval: 'month',
    maxProperties: -1, // unlimited
    maxImages: 30,
    features: [
      'Unlimited property listings',
      'Premium photo gallery (up to 30)',
      'Featured listing placement',
      'Priority customer support',
      'Advanced analytics & insights',
      'Social media promotion',
      'Virtual tour integration',
      'Lead management tools'
    ],
    isPopular: true
  }
] as const;

export const PAYMENT_METHODS = [
  {
    id: 'stripe',
    type: 'stripe',
    name: 'Credit/Debit Card',
    icon: '💳',
    description: 'Visa, Mastercard, or other cards',
    isActive: true
  },
  {
    id: 'orange_money',
    type: 'orange_money',
    name: 'Orange Money',
    icon: '🟠',
    description: 'Pay with your Orange Money wallet',
    isActive: true
  },
  {
    id: 'afrimoney',
    type: 'afrimoney',
    name: 'Afrimoney',
    icon: '🔵',
    description: 'Pay with your Afrimoney account',
    isActive: true
  }
] as const;

export const ROUTES = {
  HOME: '/',
  PROPERTIES: '/properties',
  PROPERTY_DETAIL: '/property/:id',
  DASHBOARD: '/dashboard',
  ADD_PROPERTY: '/add-property',
  SUBSCRIPTION: '/subscription',
  AUTH: '/auth',
  ABOUT: '/about',
  CONTACT: '/contact',
  PRIVACY: '/privacy',
  TERMS: '/terms'
} as const;

export const STORAGE_KEYS = {
  AUTH_TOKEN: 'miose_auth_token',
  USER_DATA: 'miose_user_data',
  SEARCH_FILTERS: 'miose_search_filters',
  THEME: 'miose_theme',
  LANGUAGE: 'miose_language'
} as const;

export const VALIDATION_RULES = {
  PASSWORD_MIN_LENGTH: 8,
  PHONE_PATTERN: /^\+232\d{8}$/,
  EMAIL_PATTERN: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/png', 'image/webp'],
  MAX_IMAGES_PER_PROPERTY: 20
} as const;

export const UI_CONFIG = {
  ANIMATION_DURATION: 300,
  DEBOUNCE_DELAY: 500,
  PAGINATION_LIMIT: 20,
  MOBILE_BREAKPOINT: 768,
  TABLET_BREAKPOINT: 1024,
  DESKTOP_BREAKPOINT: 1280
} as const;

export const COLORS = {
  PRIMARY: {
    50: '#f0fdf4',
    100: '#dcfce7',
    500: '#22c55e',
    600: '#16a34a',
    700: '#15803d',
    900: '#14532d'
  },
  SECONDARY: {
    50: '#eff6ff',
    100: '#dbeafe',
    500: '#3b82f6',
    600: '#2563eb',
    700: '#1d4ed8',
    900: '#1e3a8a'
  },
  SIERRA_LEONE: {
    GREEN: '#1eb53a',
    BLUE: '#0072ce',
    WHITE: '#ffffff'
  }
} as const;