// API utility functions for MiOse platform
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api/v1';

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

// Generic API request function
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const token = localStorage.getItem('authToken');
    
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers,
      },
      ...options,
    };

    // For demo purposes, simulate successful responses
    if (endpoint.includes('/auth/login')) {
      return {
        success: true,
        data: {
          user: {
            id: '1',
            email: 'user@example.com',
            firstName: 'John',
            lastName: 'Doe',
            userType: 'buyer',
            isVerified: true
          },
          token: 'demo_token_' + Date.now()
        }
      } as ApiResponse<T>;
    }
    
    if (endpoint.includes('/auth/register')) {
      return {
        success: true,
        data: {
          user: {
            id: '1',
            email: 'user@example.com',
            firstName: 'John',
            lastName: 'Doe',
            userType: 'buyer',
            isVerified: true
          },
          token: 'demo_token_' + Date.now()
        }
      } as ApiResponse<T>;
    }

    if (endpoint.includes('/properties')) {
      // Mock properties data
      const mockProperties = [
        {
          id: '1',
          title: 'Modern 3-Bedroom House in Hill Station',
          price: 85000,
          currency: 'SLL',
          district: 'Hill Station',
          propertyType: 'House',
          listingType: 'sale',
          bedrooms: 3,
          bathrooms: 2,
          squareMeters: 120,
          featured: true,
          images: [{ url: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg' }],
          description: 'Beautiful modern house with great views',
          amenities: ['Parking', 'Garden', 'Security'],
          createdAt: new Date().toISOString()
        },
        {
          id: '2',
          title: 'Cozy Apartment in Central Freetown',
          price: 65000,
          currency: 'SLL',
          district: 'Central Freetown',
          propertyType: 'Apartment',
          listingType: 'rent',
          bedrooms: 2,
          bathrooms: 1,
          squareMeters: 80,
          featured: false,
          images: [{ url: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg' }],
          description: 'Comfortable apartment in the city center',
          amenities: ['Air Conditioning', 'Internet'],
          createdAt: new Date().toISOString()
        },
        {
          id: '3',
          title: 'Luxury Villa in West End',
          price: 145000,
          currency: 'SLL',
          district: 'West End',
          propertyType: 'Villa',
          listingType: 'sale',
          bedrooms: 4,
          bathrooms: 3,
          squareMeters: 200,
          featured: true,
          images: [{ url: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg' }],
          description: 'Stunning luxury villa with ocean views',
          amenities: ['Pool', 'Garden', 'Security', 'Parking'],
          createdAt: new Date().toISOString()
        }
      ];

      if (endpoint.includes('/properties/') && !endpoint.includes('/properties?')) {
        // Single property request
        const propertyId = endpoint.split('/properties/')[1];
        const property = mockProperties.find(p => p.id === propertyId);
        return {
          success: true,
          data: property || mockProperties[0]
        } as ApiResponse<T>;
      }

      // Properties list request
      return {
        success: true,
        data: mockProperties
      } as ApiResponse<T>;
    }

    if (endpoint.includes('/price-prediction')) {
      return {
        success: true,
        data: {
          predictedPrice: 95000,
          priceRange: { min: 85000, max: 105000 },
          confidenceScore: 0.85,
          marketAnalysis: {
            averagePrice: 90000,
            pricePerSqm: 750,
            marketTrend: 'stable'
          }
        }
      } as ApiResponse<T>;
    }

    // For any other endpoints, try to make the actual request
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    
    return {
      success: true,
      data: {} as T
    };
  } catch (error) {
    console.error('API Error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
}

// Authentication API
export const authAPI = {
  login: async (email: string, password: string) => {
    const response = await apiRequest<{ user: any; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    
    if (response.success && response.data) {
      localStorage.setItem('authToken', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    
    return response;
  },

  register: async (userData: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    password: string;
    userType: string;
  }) => {
    const response = await apiRequest<{ user: any; token: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
    
    if (response.success && response.data) {
      localStorage.setItem('authToken', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    
    return response;
  },

  logout: async () => {
    await apiRequest('/auth/logout', { method: 'POST' });
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
  },

  refreshToken: async () => {
    return apiRequest<{ token: string }>('/auth/refresh-token', {
      method: 'POST',
    });
  },
};

// Properties API
export const propertiesAPI = {
  getProperties: async (filters: any = {}) => {
    return apiRequest<any[]>('/properties');
  },

  getProperty: async (id: string) => {
    return apiRequest<any>(`/properties/${id}`);
  },

  createProperty: async (propertyData: any) => {
    return apiRequest<any>('/properties', {
      method: 'POST',
      body: JSON.stringify(propertyData),
    });
  },

  updateProperty: async (id: string, propertyData: any) => {
    return apiRequest<any>(`/properties/${id}`, {
      method: 'PUT',
      body: JSON.stringify(propertyData),
    });
  },

  deleteProperty: async (id: string) => {
    return apiRequest(`/properties/${id}`, {
      method: 'DELETE',
    });
  },

  favoriteProperty: async (id: string) => {
    return apiRequest(`/properties/${id}/favorite`, {
      method: 'POST',
    });
  },

  unfavoriteProperty: async (id: string) => {
    return apiRequest(`/properties/${id}/favorite`, {
      method: 'DELETE',
    });
  },

  recordView: async (id: string) => {
    return apiRequest(`/properties/${id}/view`, {
      method: 'POST',
    });
  },
};

// User API
export const userAPI = {
  getProfile: async () => {
    return apiRequest<any>('/users/profile');
  },

  updateProfile: async (profileData: any) => {
    return apiRequest<any>('/users/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    });
  },

  getUserProperties: async (userId: string) => {
    return apiRequest<any[]>(`/users/${userId}/properties`);
  },

  getFavorites: async () => {
    return apiRequest<any[]>('/users/favorites');
  },
};

// Recommendations API
export const recommendationsAPI = {
  getRecommendations: async (userId: string, limit: number = 10) => {
    return apiRequest<any[]>(`/recommendations/${userId}?limit=${limit}`);
  },

  getPricePrediction: async (propertyData: {
    propertyType: string;
    district: string;
    bedrooms: number;
    bathrooms: number;
    squareMeters: number;
    amenities: string[];
  }) => {
    return apiRequest<{
      predictedPrice: number;
      priceRange: { min: number; max: number };
      confidenceScore: number;
      marketAnalysis: any;
    }>('/price-prediction', {
      method: 'POST',
      body: JSON.stringify(propertyData),
    });
  },
};

// Upload API
export const uploadAPI = {
  uploadImage: async (file: File) => {
    // Simulate upload
    return {
      success: true,
      data: {
        url: URL.createObjectURL(file)
      }
    };
  },
};