import { useState, useEffect } from 'react';
import { useAuth } from './useAuth';

interface SubscriptionStatus {
  isActive: boolean;
  planType: 'free' | 'basic' | 'pro';
  expiresAt?: string;
  features: {
    maxProperties: number;
    maxImages: number;
    showAds: boolean;
    featuredListings: boolean;
    analytics: boolean;
    prioritySupport: boolean;
  };
}

export const useSubscription = () => {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<SubscriptionStatus>({
    isActive: true,
    planType: 'free',
    features: {
      maxProperties: 2,
      maxImages: 5,
      showAds: true,
      featuredListings: false,
      analytics: false,
      prioritySupport: false
    }
  });

  useEffect(() => {
    if (user) {
      // Check user's subscription status
      // This would typically come from your backend API
      const userSubscription = getUserSubscription(user.id);
      setSubscription(userSubscription);
    }
  }, [user]);

  const getUserSubscription = (userId: string): SubscriptionStatus => {
    // Mock subscription logic - replace with actual API call
    const savedPlan = localStorage.getItem(`subscription_${userId}`);
    
    if (savedPlan) {
      const plan = JSON.parse(savedPlan);
      return {
        isActive: true,
        planType: plan.type,
        expiresAt: plan.expiresAt,
        features: getFeaturesByPlan(plan.type)
      };
    }

    // Default to free plan
    return {
      isActive: true,
      planType: 'free',
      features: getFeaturesByPlan('free')
    };
  };

  const getFeaturesByPlan = (planType: string) => {
    switch (planType) {
      case 'basic':
        return {
          maxProperties: 5,
          maxImages: 10,
          showAds: true,
          featuredListings: false,
          analytics: true,
          prioritySupport: false
        };
      case 'pro':
        return {
          maxProperties: -1, // unlimited
          maxImages: 30,
          showAds: false,
          featuredListings: true,
          analytics: true,
          prioritySupport: true
        };
      default: // free
        return {
          maxProperties: 2,
          maxImages: 5,
          showAds: true,
          featuredListings: false,
          analytics: false,
          prioritySupport: false
        };
    }
  };

  const upgradePlan = (planType: 'basic' | 'pro') => {
    if (user) {
      const newSubscription = {
        type: planType,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days
      };
      
      localStorage.setItem(`subscription_${user.id}`, JSON.stringify(newSubscription));
      
      setSubscription({
        isActive: true,
        planType,
        expiresAt: newSubscription.expiresAt,
        features: getFeaturesByPlan(planType)
      });
    }
  };

  const shouldShowAds = () => {
    return subscription.features.showAds;
  };

  const canAddProperty = (currentCount: number) => {
    return subscription.features.maxProperties === -1 || currentCount < subscription.features.maxProperties;
  };

  const canAddImages = (currentCount: number) => {
    return currentCount < subscription.features.maxImages;
  };

  return {
    subscription,
    shouldShowAds,
    canAddProperty,
    canAddImages,
    upgradePlan
  };
};