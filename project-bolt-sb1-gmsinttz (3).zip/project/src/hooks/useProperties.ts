import { useState, useEffect } from 'react';
import { propertiesAPI } from '../utils/api';

interface Property {
  id: string;
  title: string;
  description: string;
  propertyType: string;
  listingType: string;
  price: number;
  currency: string;
  address: string;
  district: string;
  latitude?: number;
  longitude?: number;
  bedrooms: number;
  bathrooms: number;
  squareMeters: number;
  amenities: string[];
  images: Array<{ url: string; caption?: string; isPrimary?: boolean }>;
  status: string;
  featured: boolean;
  viewsCount: number;
  owner: {
    id: string;
    firstName: string;
    lastName: string;
    phone: string;
    isVerified: boolean;
  };
  createdAt: string;
  updatedAt: string;
}

interface PropertyFilters {
  page?: number;
  limit?: number;
  district?: string;
  propertyType?: string;
  listingType?: string;
  minPrice?: number;
  maxPrice?: number;
  bedrooms?: number;
  bathrooms?: number;
  amenities?: string[];
  featured?: boolean;
  sortBy?: string;
  sortOrder?: string;
}

// Mock data for demonstration
const mockProperties: Property[] = [
  {
    id: '1',
    title: 'Luxury 4BR Villa with Ornate Gates',
    description: 'Beautiful luxury villa in Hill Station with modern amenities',
    propertyType: 'villa',
    listingType: 'sale',
    price: 4500000,
    currency: 'SLL',
    address: '15 Hill Station Road',
    district: 'Hill Station',
    bedrooms: 4,
    bathrooms: 3,
    squareMeters: 280,
    amenities: ['parking', 'generator', 'security'],
    images: [{ url: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_09e51c79.jpg', isPrimary: true }],
    status: 'active',
    featured: true,
    viewsCount: 156,
    owner: {
      id: '1',
      firstName: 'John',
      lastName: 'Doe',
      phone: '+23276123456',
      isVerified: true
    },
    createdAt: '2024-01-15T10:30:00Z',
    updatedAt: '2024-01-15T10:30:00Z'
  },
  {
    id: '2',
    title: 'Modern 3BR House with Balcony',
    description: 'Contemporary house in Murray Town with great views',
    propertyType: 'house',
    listingType: 'rent',
    price: 3200000,
    currency: 'SLL',
    address: '22 Murray Town Street',
    district: 'Murray Town',
    bedrooms: 3,
    bathrooms: 2,
    squareMeters: 180,
    amenities: ['furnished', 'balcony', 'internet'],
    images: [{ url: '/properties/WhatsApp Image 2025-07-20 at 15.42.58_49a9c835.jpg', isPrimary: true }],
    status: 'active',
    featured: false,
    viewsCount: 134,
    owner: {
      id: '2',
      firstName: 'Jane',
      lastName: 'Smith',
      phone: '+23276654321',
      isVerified: true
    },
    createdAt: '2024-01-14T09:15:00Z',
    updatedAt: '2024-01-14T09:15:00Z'
  },
  {
    id: '3',
    title: 'Colonial Style Villa with Columns',
    description: 'Elegant colonial villa in West End with classic architecture',
    propertyType: 'villa',
    listingType: 'sale',
    price: 5200000,
    currency: 'SLL',
    address: '8 West End Avenue',
    district: 'West End',
    bedrooms: 5,
    bathrooms: 4,
    squareMeters: 320,
    amenities: ['swimming_pool', 'garden', 'garage'],
    images: [{ url: '/properties/WhatsApp Image 2025-07-20 at 15.42.59_6aa66276.jpg', isPrimary: true }],
    status: 'active',
    featured: true,
    viewsCount: 187,
    owner: {
      id: '3',
      firstName: 'Ahmed',
      lastName: 'Kamara',
      phone: '+23276789012',
      isVerified: true
    },
    createdAt: '2024-01-13T14:20:00Z',
    updatedAt: '2024-01-13T14:20:00Z'
  }
];

export const useProperties = (filters: PropertyFilters = {}) => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    total: 0,
    totalPages: 0,
  });

  const fetchProperties = async (newFilters: PropertyFilters = {}) => {
    try {
      setLoading(true);
      setError(null);
      
      // Simulate API call with mock data
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      let filteredProperties = [...mockProperties];
      
      // Apply filters
      if (newFilters.district) {
        filteredProperties = filteredProperties.filter(p => 
          p.district.toLowerCase().includes(newFilters.district!.toLowerCase())
        );
      }
      
      if (newFilters.propertyType && newFilters.propertyType !== 'all') {
        filteredProperties = filteredProperties.filter(p => 
          p.propertyType === newFilters.propertyType
        );
      }
      
      if (newFilters.listingType && newFilters.listingType !== 'all') {
        filteredProperties = filteredProperties.filter(p => 
          p.listingType === newFilters.listingType
        );
      }
      
      setProperties(filteredProperties);
      setPagination({
        page: newFilters.page || 1,
        limit: newFilters.limit || 20,
        total: filteredProperties.length,
        totalPages: Math.ceil(filteredProperties.length / (newFilters.limit || 20)),
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties(filters);
  }, [JSON.stringify(filters)]);

  const refetch = (newFilters?: PropertyFilters) => {
    fetchProperties(newFilters || filters);
  };

  return {
    properties,
    loading,
    error,
    pagination,
    refetch,
  };
};

export const useProperty = (id: string) => {
  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProperty = async () => {
      if (!id) return;
      
      try {
        setLoading(true);
        setError(null);
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const foundProperty = mockProperties.find(p => p.id === id);
        
        if (foundProperty) {
          setProperty(foundProperty);
        } else {
          setError('Property not found');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchProperty();
  }, [id]);

  return { property, loading, error };
};